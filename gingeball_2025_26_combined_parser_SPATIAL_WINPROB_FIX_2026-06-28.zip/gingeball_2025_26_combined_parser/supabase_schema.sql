-- Optional Supabase schema for Gingeball 2025-26 combined parser outputs.
-- The parser writes CSVs locally first. Upload after QC passes.

create table if not exists clean_game_events_202526 (
  bbref_game_id text not null,
  event_id text not null,
  event_index int,
  season int,
  date text,
  is_playoff boolean,
  period int,
  clock text,
  game_elapsed_seconds float,
  away_team text,
  home_team text,
  event_side text,
  event_team text,
  player text,
  player_id_bbref text,
  player2 text,
  player2_id_bbref text,
  assist_id_bbref text,
  block_id_bbref text,
  steal_id_bbref text,
  event_text text,
  points int,
  shot_zone_bbref text,
  shot_dist_bbref float,
  true_possession_id text,
  true_possession_attach_method text,
  nba_game_id text,
  nba_action_number int,
  nba_alignment_confidence float,
  nba_description_aligned text,
  nba_alignment_method text,
  home_win_probability float,
  away_win_probability float,
  official_leverage_index_score float,
  custom_leverage_index_score float default 1.0,
  flag_is_low_leverage_garbage_time int default 0,
  win_probability_available int default 0,
  win_probability_source text,
  win_probability_confidence float default 0.0,
  win_probability_event_num int,
  win_probability_alignment_method text,
  win_probability_seconds_delta float,
  leverage_model_version text,
  extracted_steal_type text default 'No_Steal',
  extracted_rebound_type text default 'No_Rebound',
  extracted_cut_type text default 'No_Cut_Detected',
  extracted_miss_type text default 'No_Miss_Or_Shot_Made',
  extracted_contest_type text default 'Unspecified_Contest',
  extracted_off_ball_screen text default 'No_Off_Ball_Screen_Noted',
  semantic_subtype_confidence float default 0.0,
  inferred_actor_x float,
  inferred_actor_y float,
  inferred_floor_zone text,
  estimated_shot_distance_ft float,
  kinematic_velocity_fps float,
  spatial_inference_source text,
  spatial_inference_confidence float default 0.0,
  tactical_switch_network_state text default 'No_Switch_Detected',
  playbook_preset_detected text default 'None_Executed',
  tracking_inference_confidence float default 0.0,
  event_semantic_version text,
  source text,
  created_at timestamptz default now(),
  primary key (bbref_game_id, event_id)
);


create table if not exists event_advanced_context_202526 (
  bbref_game_id text not null,
  event_id text not null,
  event_index int,
  true_possession_id text,
  period int,
  clock text,
  game_elapsed_seconds float,
  event_team text,
  player text,
  player_id_bbref text,
  event_text text,
  nba_game_id text,
  nba_action_number int,
  nba_alignment_confidence float,
  nba_description_aligned text,
  home_win_probability float,
  away_win_probability float,
  official_leverage_index_score float,
  custom_leverage_index_score float default 1.0,
  flag_is_low_leverage_garbage_time int default 0,
  win_probability_available int default 0,
  win_probability_source text,
  win_probability_confidence float default 0.0,
  win_probability_event_num int,
  win_probability_alignment_method text,
  win_probability_seconds_delta float,
  leverage_model_version text,
  extracted_steal_type text default 'No_Steal',
  extracted_rebound_type text default 'No_Rebound',
  extracted_cut_type text default 'No_Cut_Detected',
  extracted_miss_type text default 'No_Miss_Or_Shot_Made',
  extracted_contest_type text default 'Unspecified_Contest',
  extracted_off_ball_screen text default 'No_Off_Ball_Screen_Noted',
  semantic_subtype_confidence float default 0.0,
  inferred_actor_x float,
  inferred_actor_y float,
  inferred_floor_zone text,
  estimated_shot_distance_ft float,
  kinematic_velocity_fps float,
  spatial_inference_source text,
  spatial_inference_confidence float default 0.0,
  tactical_switch_network_state text default 'No_Switch_Detected',
  playbook_preset_detected text default 'None_Executed',
  tracking_inference_confidence float default 0.0,
  event_semantic_version text,
  created_at timestamptz default now(),
  primary key (bbref_game_id, event_id)
);

create table if not exists nba_winprobabilitypbp_sidecar_202526 (
  nba_game_id text not null,
  winprob_row_index int not null,
  winprob_event_num int,
  period int,
  winprob_seconds_remaining float,
  winprob_clock text,
  winprob_game_elapsed_seconds float,
  winprob_time_basis text,
  home_win_probability float,
  away_win_probability float,
  official_leverage_index_score float,
  win_probability_description text,
  win_probability_source text,
  created_at timestamptz default now(),
  primary key (nba_game_id, winprob_row_index)
);

create index if not exists nba_winprobabilitypbp_sidecar_202526_event_idx
on nba_winprobabilitypbp_sidecar_202526(nba_game_id, winprob_event_num);

create index if not exists clean_game_events_202526_leverage_idx
on clean_game_events_202526(custom_leverage_index_score, flag_is_low_leverage_garbage_time);

create index if not exists event_advanced_context_202526_possession_idx
on event_advanced_context_202526(bbref_game_id, true_possession_id);

create index if not exists event_advanced_context_202526_playbook_idx
on event_advanced_context_202526(playbook_preset_detected, tactical_switch_network_state);

create table if not exists possession_frames_202526 (
  bbref_game_id text not null,
  possession_id text not null,
  season int,
  period int,
  offense_team text,
  defense_team text,
  start_clock text,
  end_clock text,
  start_elapsed float,
  end_elapsed float,
  duration_seconds float,
  points_scored int,
  standard_possessions_inside int,
  advantage_count int,
  end_type text,
  source text,
  created_at timestamptz default now(),
  primary key (bbref_game_id, possession_id)
);

create table if not exists event_lineups_202526 (
  bbref_game_id text not null,
  event_id text not null,
  event_index int,
  period int,
  clock text,
  game_elapsed_seconds float,
  away_team text,
  home_team text,
  away_player_ids_bbref jsonb,
  home_player_ids_bbref jsonb,
  away_player_names jsonb,
  home_player_names jsonb,
  lineup_source text,
  created_at timestamptz default now(),
  primary key (bbref_game_id, event_id)
);

create table if not exists possession_lineups_202526 (
  bbref_game_id text not null,
  possession_id text not null,
  period int,
  start_clock text,
  end_clock text,
  offense_team text,
  defense_team text,
  offense_player_ids_bbref jsonb,
  defense_player_ids_bbref jsonb,
  offense_player_names jsonb,
  defense_player_names jsonb,
  lineup_source text,
  created_at timestamptz default now(),
  primary key (bbref_game_id, possession_id)
);

create table if not exists event_tactical_labels_202526 (
  id bigserial primary key,
  bbref_game_id text not null,
  nba_game_id text,
  event_id text,
  event_index int,
  true_possession_id text,
  period int,
  clock text,
  source_id text,
  source_type text,
  label_family text,
  label_value text,
  confidence float,
  evidence_text text,
  evidence_start_seconds float,
  evidence_end_seconds float,
  label_version text,
  created_at timestamptz default now()
);

create index if not exists event_tactical_labels_202526_gid_event_idx
on event_tactical_labels_202526(bbref_game_id, event_id);

create index if not exists event_tactical_labels_202526_family_idx
on event_tactical_labels_202526(label_family, label_value);
