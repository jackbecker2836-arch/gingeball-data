# Gingeball 2025-26 Combined Master Parser

This package combines your existing `pbp_scraper.py` BBRef authority layer with the Gingeball enrichment/parser layer.

## What it does

### Path A — BBRef authority scrape for 2025-26
Uses your existing scraper logic for:

- raw Basketball-Reference PBP
- raw HTML cache
- FT-aware true possessions
- complete lineup stints
- player ids/names
- assist/block/steal actors
- shot distance / BBRef shot-zone approximation
- QC manifests / failures

### Path B — normalized master tables
Builds:

- `clean_game_events.csv`
- `possession_frames.csv`
- `event_lineups.csv`
- `possession_lineups.csv`
- `observed_touch_chain.csv`
- `possession_proxy_labels.csv`
- `event_advanced_context.csv`

### Path C — modern enrichment sidecars
When NBA game ID can be resolved:

- `nba_playbyplayv3_sidecar.csv`
- `nba_shotchartdetail_sidecar.csv`
- `nba_videoevents_sidecar.csv` if `--videoevents` is used
- `public_tracking_aggregates_leaguedashptstats.csv` if `--fetch-tracking` is used

### Path D — coverage/tactical labels
Optional sources:

- alternate/data broadcasts
- closed captions/subtitles
- broadcast/radio transcripts
- written live blogs/recaps
- postgame film breakdowns

Each label has source, evidence text, confidence, event/possession link when possible.

### Path E — advanced event-context features
Adds conservative, auditable columns to `clean_game_events.csv` and writes a slim `event_advanced_context.csv`:

- steal/rebound/cut/miss/contest sub-types
- off-ball screen family tags
- switch-network and playbook-preset cues
- real NBA shot/event coordinates when sidecars provide them
- coarse/null spatial hints when exact coordinates are unavailable
- source + confidence columns so downstream models can avoid fake precision

## Install

```bash
pip install -r requirements.txt
```

You also need `ffmpeg` in PATH for audio/video workflows.

## First safe test

```bash
python gingeball_2025_26_combined_parser.py --scrape-bbref --enrich --limit 5 --bbref-data-dir ./data_2025_26_bbref --out ./data_2025_26_master
```

## Full 2025-26 BBRef scrape

```bash
python gingeball_2025_26_combined_parser.py --scrape-bbref --season-year 2026 --bbref-data-dir ./data_2025_26_bbref
```

This is resume-safe. It will skip games already present in `raw_pbp`, `possessions/*_tp.csv`, and `possessions/*_lineups.csv`.

## Enrich after scrape

```bash
python gingeball_2025_26_combined_parser.py --enrich-only --bbref-data-dir ./data_2025_26_bbref --out ./data_2025_26_master
```

## Use coverage sources

Edit `sources.example.json`, then run:

```bash
python gingeball_2025_26_combined_parser.py --enrich-only --sources sources.example.json --bbref-data-dir ./data_2025_26_bbref --out ./data_2025_26_master
```

## Optional ML trainer

The parser itself does **not** require LightGBM or Supabase. To train the optional shot-quality model after events are generated:

```bash
pip install -r requirements-ml.txt
python shot_predictor_ml.py --events-csv ./data_2025_26_master/202510220LAL/clean_game_events.csv
```

For Supabase pulls, set `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`, then pass `--supabase-table clean_game_events_202526`.

## Output layout

Each game writes to:

```text
data_2025_26_master/<bbref_game_id>/
```

Season summary writes to:

```text
data_2025_26_master/season_report.csv
```

## Important caveats

1. BBRef IDs and NBA GameIDs are different. The script tries to resolve NBA GameID automatically by date + home team via NBA ScoreboardV2.
2. NBA event alignment is time-based and confidence-scored. Treat NBA x/y and clip metadata as sidecar enrichment until you manually validate enough games.
3. Coverage/video/audio ingestion should only use content you have rights or authorization to process.
4. Run a five-game test first. Do not launch the full enrichment/video pass blind.
5. The inferred coordinate layer is intentionally conservative. It uses NBA sidecar x/y when available; otherwise it stores coarse zones/null coordinates plus confidence/source tags. Text-only anchors never write fabricated x/y into coordinate fields and never feed kinematic velocity.

## Add-on: win probability + leverage filter

When an NBA GameID resolves and the endpoint responds, the parser now writes:

- `nba_winprobabilitypbp_sidecar.csv`
- `home_win_probability`
- `away_win_probability`
- `official_leverage_index_score` when the upstream payload includes one
- `custom_leverage_index_score`
- `flag_is_low_leverage_garbage_time`
- `win_probability_available`
- `win_probability_source`
- `win_probability_confidence`
- `win_probability_alignment_method`
- `win_probability_seconds_delta` for nearest-time fallback QC

Calibration note: the current `nba_api` docs expose `HOME_PCT`, `VISITOR_PCT`, `EVENT_NUM`, `PERIOD`, `SECONDS_REMAINING`, and `PCTIMESTRING`. The parser supports those names plus common fallback aliases, prefers the period clock string for elapsed-time mapping when present, and only falls back to `SECONDS_REMAINING` after detecting whether it behaves like a period clock or regulation game clock. If the WinProbabilityPBP endpoint fails, the official probability fields remain blank and the parser falls back to a lower-confidence score/time leverage heuristic instead of pretending every event was 50/50.

The optional LightGBM trainer now excludes garbage-time / low-leverage shots by default when those columns exist:

```bash
python shot_predictor_ml.py --events-csv ./data_2025_26_master/202510220LAL/clean_game_events.csv --min-leverage 0.25
```

To deliberately include all rows:

```bash
python shot_predictor_ml.py --events-csv ./data_2025_26_master/202510220LAL/clean_game_events.csv --include-low-leverage
```
