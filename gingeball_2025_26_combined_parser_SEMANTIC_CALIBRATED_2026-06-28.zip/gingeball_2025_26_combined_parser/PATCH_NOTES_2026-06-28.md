# Gingeball 2025-26 Combined Parser Patch Notes — 2026-06-28

## Highest-risk correctness fixes

1. **Possession boundary assignment is now half-open.**
   - Replaced the inclusive event-to-possession scan with a start-keyed `merge_asof` assignment.
   - Primary rule is now `[start_elapsed, end_elapsed)`, with a final-window exception for the last possession in a period.
   - Added `true_possession_attach_method` so bad/unmatched/tolerance assignments are auditable instead of silent.
   - Team matching is retained as a fallback/tie-breaker; it does not pull exact end-boundary events backward into the closing possession.

2. **Period-opening offense is no longer hardcoded to away.**
   - `parse_true_possessions` now derives each period's opening offense from the first non-admin team action in that period.
   - Subs/timeouts are ignored for this inference.
   - If no usable period action exists, it falls back to the prior known offense instead of blindly resetting to away.

3. **Lineup stints are now half-open.**
   - `stint_for_elapsed` now uses `[secs_on, secs_off)` as the primary membership rule.
   - Boundary fallback uses event player IDs to choose the stint that actually contains the player(s), rather than choosing the shortest stint.
   - `build_event_lineups` now passes the event row into `stint_for_elapsed` so boundary ties can use player evidence.

## Speed / scale fixes

4. **Event-to-possession assignment is no longer `events × possessions`.**
   - Replaced the chronological nested scan with period-level `merge_asof`.

5. **BBRef-to-NBA event alignment is no longer a per-event full scan.**
   - Replaced row-by-row period filtering with period/kind grouped `merge_asof` nearest alignment.
   - Event-type filtering now covers shots, turnovers, rebounds, fouls, substitutions, timeouts, and jump balls.
   - Added `nba_game_id` consistently to aligned clean events; the prior non-empty path added action/confidence but not the game id.

## Coverage / tactical label fixes

6. **Timed tactical labels no longer fan out to every nearby event.**
   - Each label from a timed segment now attaches to one nearest compatible event inside the window.
   - Compatibility prioritizes high-value event types by label family, e.g. rebounding labels prefer rebounds, rim/closeout/deception labels prefer shots/fouls/turnovers.
   - Confidence is lightly distance-weighted inside the window.

7. **Whisper confidence is now clearly a source prior.**
   - Replaced the magic `0.64` literal with `WHISPER_SEGMENT_SOURCE_PRIOR` and a comment explaining it is not measured ASR confidence.

8. **Article extraction is less boilerplate-heavy.**
   - Removes nav/header/footer/aside/form/button elements.
   - Uses the densest `<article>` / `<main>` paragraph block instead of concatenating every wrapper.

## Crosswalk fixes

9. **NBA game-id resolution is more robust and auditable.**
   - Scoreboard matching now supports home/visitor columns, `HTM`/`VTM`, `GAMECODE`, and line-score team-set fallback.
   - Matching can use both away and home teams from BBRef.
   - Unresolved or ambiguous matches are logged to `nba_game_id_failures.csv` next to the game output folders.

## Additional silent bug caught during audit

10. **CSV boolean round-trip guard.**
    - Added `is_true()` and normalized BBRef boolean columns after CSV load.
    - This prevents strings like `"False"` from becoming truthy in touch-chain creation and NBA event-type filters.

## Smoke tests run

- `python -m py_compile gingeball_2025_26_combined_parser.py bbref_pbp_scraper.py`
- Toy possession-boundary test: event at exact shared boundary attaches to the new half-open window.
- Toy stint-boundary test: event just before boundary stays with old lineup; event at boundary moves to new lineup.
- Toy CSV boolean test: string `"False"` normalizes to actual `False` and does not create fake touch rows.
- Toy tactical-label test: one caption segment with multiple labels attaches each label to one event, not every event in the ±8s window.

## Add-on calibration patch: event semantics + conservative spatial context

Added from the requested expansion set, but calibrated to avoid fake precision:

- Added `extract_granular_action_sub_types()` for steal, rebound, cut, miss, and contest sub-types.
- Added `extract_off_ball_screen_variations()` for pin-down, flare, back-screen/UCLA, staggered, STS, elevator, and generic off-ball screen tags.
- Added `infer_switching_networks_and_playbooks()` for blown-switch, late-rotation, clean-switch, horns, Spain PnR, pistol, Iverson, elevator, zoom, and hammer cues.
- Added `add_advanced_event_features()` to append these columns directly onto `clean_game_events.csv`.
- Added `event_advanced_context.csv`, a slim export containing just the new event-context layer and event keys.
- Added real-coordinate priority: `nba_shotchartdetail` first, then `nba_playbyplayv3` x/y when aligned.
- Added conservative fallback zones: BBRef shot zone, shot distance, restricted-area/free-throw text anchors. If coordinates are not reliable, x/y remain null rather than invented.
- Added per-actor `kinematic_velocity_fps` only when consecutive known coordinates exist for the same player in the same period.
- Added source/confidence columns: `semantic_subtype_confidence`, `spatial_inference_source`, `spatial_inference_confidence`, and `tracking_inference_confidence`.
- Updated `supabase_schema.sql` with the expanded columns and a separate `event_advanced_context_202526` table.
- Added optional `shot_predictor_ml.py` plus `requirements-ml.txt`; the base parser remains installable without ML dependencies.

Validation:

- `python -m py_compile gingeball_2025_26_combined_parser.py bbref_pbp_scraper.py shot_predictor_ml.py`
- Synthetic smoke test for: back-iron miss, late contest, pin-down screen, Spain PnR, and passing-lane steal.

Additional calibration fix caught during this add-on pass:

- Forced `merge_asof` clock keys to float in possession attachment and NBA alignment. This prevents pandas dtype crashes when one input arrives as integer seconds and the other arrives as float seconds.
