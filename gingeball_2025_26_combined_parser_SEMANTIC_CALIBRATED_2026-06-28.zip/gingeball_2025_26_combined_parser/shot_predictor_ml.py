"""
Optional Gingeball shot-quality trainer for the expanded event-context columns.

This file is intentionally separate from the parser so the base scrape/enrich path
does not require LightGBM, scikit-learn, joblib, or Supabase packages.

CSV example:
    python shot_predictor_ml.py --events-csv ./data_2025_26_master/202510220LAL/clean_game_events.csv

Supabase example:
    set SUPABASE_URL=https://YOURPROJECT.supabase.co
    set SUPABASE_SERVICE_ROLE_KEY=YOUR_SERVICE_ROLE_KEY
    python shot_predictor_ml.py --supabase-table clean_game_events_202526
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Iterable, List, Optional

import numpy as np
import pandas as pd


DEFAULT_FEATURES = [
    "game_elapsed_seconds",
    "estimated_shot_distance_ft",
    "shot_dist_bbref",
    "period",
    "points",
    "shot_zone_bbref",
    "extracted_off_ball_screen",
    "extracted_cut_type",
    "extracted_miss_type",
    "extracted_contest_type",
    "tactical_switch_network_state",
    "playbook_preset_detected",
    "inferred_floor_zone",
    "spatial_inference_source",
    "semantic_subtype_confidence",
    "spatial_inference_confidence",
    "tracking_inference_confidence",
]


def _lazy_ml_imports():
    try:
        import lightgbm as lgb
        import joblib
        from sklearn.metrics import brier_score_loss, log_loss, roc_auc_score
        from sklearn.model_selection import train_test_split
    except Exception as exc:
        raise RuntimeError(
            "Missing optional ML dependencies. Install them with: "
            "pip install -r requirements-ml.txt"
        ) from exc
    return lgb, joblib, train_test_split, roc_auc_score, brier_score_loss, log_loss


def load_from_supabase(table: str) -> pd.DataFrame:
    try:
        from supabase import create_client
    except Exception as exc:
        raise RuntimeError("Install supabase first: pip install supabase") from exc

    url = os.getenv("SUPABASE_URL")
    key = os.getenv("SUPABASE_SERVICE_ROLE_KEY") or os.getenv("SUPABASE_ANON_KEY")
    if not url or not key:
        raise RuntimeError("Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY before using --supabase-table.")

    supabase = create_client(url, key)
    rows = []
    start = 0
    page = 1000
    while True:
        res = supabase.table(table).select("*").range(start, start + page - 1).execute()
        chunk = list(res.data or [])
        rows.extend(chunk)
        if len(chunk) < page:
            break
        start += page
    return pd.DataFrame(rows)


def build_shot_training_frame(df: pd.DataFrame, feature_names: Iterable[str] = DEFAULT_FEATURES):
    if df.empty:
        raise ValueError("Input dataframe is empty.")
    if "is_shot" in df.columns:
        shot_df = df[df["is_shot"].astype(str).str.lower().isin(["true", "1", "yes"])].copy()
    else:
        text = df.get("event_text", pd.Series([""] * len(df))).astype(str).str.lower()
        shot_df = df[text.str.contains("makes|misses|no good|dunk|layup|jumper|shot", na=False)].copy()
    if shot_df.empty:
        raise ValueError("No shot rows found. Make sure the events CSV includes shot rows.")

    if "shot_made" in shot_df.columns:
        y = shot_df["shot_made"].astype(str).str.lower().isin(["true", "1", "yes"]).astype(int)
    else:
        y = shot_df.get("event_text", pd.Series([""] * len(shot_df))).astype(str).str.lower().str.contains("makes|made", na=False).astype(int)

    active_features: List[str] = [f for f in feature_names if f in shot_df.columns]
    if not active_features:
        raise ValueError("None of the requested features exist in the input dataframe.")

    X = shot_df[active_features].copy()
    for col in X.columns:
        if X[col].dtype == "object":
            X[col] = X[col].fillna("Unknown").astype("category")
        else:
            X[col] = pd.to_numeric(X[col], errors="coerce").fillna(0.0)
    return X, y, shot_df


def train_shot_quality_model(df: pd.DataFrame, output_model: str = "nba_gb_shot_quality_model.pkl"):
    lgb, joblib, train_test_split, roc_auc_score, brier_score_loss, log_loss = _lazy_ml_imports()
    X, y, shot_df = build_shot_training_frame(df)
    if y.nunique() < 2:
        raise ValueError("Need both made and missed shots to train a classifier.")

    stratify = y if y.value_counts().min() >= 2 else None
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=stratify
    )

    categorical_cols = [c for c in X.columns if str(X[c].dtype) == "category"]
    model = lgb.LGBMClassifier(
        n_estimators=400,
        learning_rate=0.025,
        num_leaves=31,
        max_depth=-1,
        min_child_samples=40,
        subsample=0.85,
        colsample_bytree=0.85,
        reg_alpha=0.05,
        reg_lambda=0.20,
        random_state=42,
        objective="binary",
    )
    model.fit(
        X_train,
        y_train,
        categorical_feature=categorical_cols or "auto",
        eval_set=[(X_test, y_test)],
        callbacks=[lgb.early_stopping(stopping_rounds=35, verbose=False)],
    )

    probs = model.predict_proba(X_test)[:, 1]
    metrics = {
        "rows": int(len(shot_df)),
        "features_used": list(X.columns),
        "roc_auc": float(roc_auc_score(y_test, probs)) if y_test.nunique() > 1 else None,
        "brier": float(brier_score_loss(y_test, probs)),
        "log_loss": float(log_loss(y_test, probs, labels=[0, 1])),
    }

    output_path = Path(output_model)
    joblib.dump({"model": model, "features": list(X.columns), "metrics": metrics}, output_path)
    return model, metrics, output_path


def extract_and_rank_feature_importance(trained_lightgbm_model, feature_names_list: List[str]) -> pd.DataFrame:
    booster = getattr(trained_lightgbm_model, "booster_", None)
    if booster is not None:
        scores = booster.feature_importance(importance_type="gain")
    else:
        scores = trained_lightgbm_model.feature_importances_
    out = pd.DataFrame({
        "feature": feature_names_list,
        "gain_importance": scores,
    }).sort_values("gain_importance", ascending=False).reset_index(drop=True)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--events-csv", help="Path to clean_game_events.csv or a concatenated season events CSV")
    ap.add_argument("--supabase-table", help="Supabase table to pull, e.g. clean_game_events_202526")
    ap.add_argument("--output-model", default="nba_gb_shot_quality_model.pkl")
    ap.add_argument("--importance-csv", default="shot_quality_feature_importance.csv")
    args = ap.parse_args()

    if args.events_csv:
        df = pd.read_csv(args.events_csv)
    elif args.supabase_table:
        df = load_from_supabase(args.supabase_table)
    else:
        raise SystemExit("Pass --events-csv or --supabase-table.")

    model, metrics, output_path = train_shot_quality_model(df, output_model=args.output_model)
    importance = extract_and_rank_feature_importance(model, metrics["features_used"])
    importance.to_csv(args.importance_csv, index=False)

    print("Shot-quality model saved:", output_path)
    print("Metrics:", metrics)
    print("Feature importance saved:", args.importance_csv)


if __name__ == "__main__":
    main()
