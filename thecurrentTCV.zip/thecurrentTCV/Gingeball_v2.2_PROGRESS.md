# Gingeball v2.2 — Progress Snapshot
_Updated through load-adjusted TCV assembly (locked) + defensive-coverage fix. MIV v2 + offensive load adjustment in. See "Known gaps & discrepancies"._

## Where the model stands
The full **obs → obs-clean → SE → cascade → TCV** stack is built for **all 7 weighted components across all 5 seasons (2021–2025)**, run through the real `build_cascade.py` and assembled into a first end-to-end **TCV**. Every weighted component calibrates **w_ref = r exactly**. MIV was rebuilt this arc (v2, gravity-based — see below). TCV validates at **corr 0.41 / Spearman 0.33** vs multiseason RAPM. One assembly decision remains open: the **offense/defense balance** (see end).

## The 10 components
| Component | Meaning | Role |
|---|---|---|
| PVA | Passing Value Added | weighted |
| SGV | Shot Generation Value (generation + shotmaking) | weighted |
| COV | Contextual Opportunity Value | weighted |
| MIV | Movement / Interaction Value | weighted |
| DSV | Defensive Stopper Value | weighted |
| DPC | Defensive Positioning Created | weighted |
| RPV | Rim Protection Value | weighted |
| IIB | Individual Impact on Basket (= shrunk RAPM) | **measuring stick — excluded from TCV sum** |
| SAV | Scheme Adaptability Value | descriptive (wt 0) |
| PTV | Playoff Translation Value | descriptive (wt 0) |

## Pipeline (locked)
`role-on-team → esf confidence (n_eff = esf·poss)` · `role-on-court → proof profile` · per-component shrinkage cell · `posterior = w·obs + (1−w)·mu_hook`, where `mu_hook = prior + obs_clean`, `SE = SE_evidence · se_mult`, `w = priorSD²/(priorSD²+SE²)`.
IIB bright line: RAPM (offensive & defensive) is the measuring stick and is **never** used inside any component's obs/obs-clean/SE — it only serves as the assembly deviation diagnostic.

## Layer status
**obs (value)** — built 5 seasons for PVA/SGV/COV/MIV/DSV/DPC (RPV 4 seasons; no 2020-21 rim D). SGV shotmaking now uses **true per-shot bbref data** (dunk separated from layup; zone-conflation limitation retired).

**obs-clean (bias corrections)** — all wired, now multi-season:
- PVA: −0.20·z(assisted-shot ease) — `teammate_fg_over_exp`, 5-season from full bbref per-assist parse
- SGV: +z(initiator − finisher) ownership
- COV: −z(inherited / pre-created advantage share)
- DSV: −z(OpponentShotLuck) − z(foul rate)
- DPC: +z(deflection/steal→outcome quality) − z(gamble); poss floor 1000
- RPV: −z(foul) + z(rim contest) [2025] + z(interior expected-vs-actual, 5-season from RSMATCHUP)

**SE (trust/instability)** — evidence/possession SE × **survivor multiplier, now 5-season**: se_mult = clip(exp(0.15·Σ widen), 0.6, 1.8); widen = +entanglement_depth −elite_resilience −sieve_z −recovery_rate +down_elasticity (per-component subsets).

## Calibration (all hold w_ref = r)
SGV .903 · PVA .842 · DSV .807 · COV .765 · RPV .688 · IIB .576 · SAV .536 · DPC .501 · MIV .305 · PTV 1.0

## MIV v2 — gravity rebuild (this arc)
**Problem:** original MIV measured off-ball *volume* (synergy Cut/Handoff/OffScreen/Spotup poss% × ppp) — near-zero for high-usage on-ball stars by definition, so it scored their *rarity of being off-ball* as negative value (Jokić 4th pctile, SGA 0th, Giannis 0th).
**Fix:** MIV now measures off-ball *value*, usage-aware:
`MIV_obs = z( 0.55·gravity_z + 0.45·offball_eff_z )`
- **gravity** = defender respect when off-ball. 2024-25 = −z(LowestThreatSpacer) (tracking gold); 2021-24 = z(spot-up shooting threat, shrunk) proxy.
- **offball_eff** = shrunk poss-weighted ppp on {Cut, Handoff, OffScreen, Spotup} (quality, K=25 toward league) — no volume penalty.
**Result:** Jokić 4th→100th, SGA 0th→100th, Giannis 0th→93rd, Curry 92nd; movement shooters high (Hauser 97, Beasley 98, Klay 89); non-threat bigs low (Adams 43rd). Calibration held w_ref = .305.

## TCV assembly (first end-to-end checkpoint)
`TCV = Σ Rᵢ · z(component_posteriorᵢ)` within season, over the 7 weighted components. `o_tcv = PVA+SGV+MIV+COV`, `d_tcv = DSV+DPC+RPV`, `TCV = o_tcv + d_tcv`. Weights = reliability R (provisional).
- **Validation:** corr(career TCV, multiseason netRAPM) = **0.41**, Spearman **0.33** (n=562, poss≥3000). Up from 0.26 (pre-MIV-fix, single-season stick). Multiseason stick has Jokić correctly #1 (11.28).
- **Rejected weightings:** NNLS / ridge fit vs single-season RAPM both degenerate (offensive-component collinearity collapses to one term per side; single-season RAPM too noisy — LeBron −3.89). Reliability weighting chosen as cleanest provisional.
- **2024-25 top (poss≥1000):** Durant, Haliburton, Kawhi, Brunson, SGA, Garland, Giannis, Kyrie, Mitchell, Embiid, LeBron, Murray, Tatum, Edwards…
- **Deviation diagnostic:** `Validation_vs_RAPM` tab sorts by z(TCV) − z(RAPM) — where TCV over/under-rates vs the stick.

## Offensive load adjustment (locked this arc)
**Problem:** offensive components are per-possession *efficiency* z-scores; the assembly summed them with no load gate, so low-usage safe role players ranked far too high (backup PGs CP3/Tyus/Tre/Kolek/Simmons via PVA; low-leverage bench scorers Sasser/Dowtin/B.Williams via SGV). The same gap held efficient high-load bigs (Jokić) down.
**Fix:** difficulty-adjust the offensive efficiency components by the load they're produced under:
`z_adj = z + 0.45 · LOAD · sat(z)`  applied to PVA, SGV, COV (MIV untouched — already gravity/attention based).
- **LOAD = z(0.6·usage + 0.4·attention)** per season.
  - usage = real `usg_pct` (2024-25) / **proxy `(FGA+TOV)/poss`, validated r=0.90 vs real** (2021-24).
  - attention = −z(closest-defender-distance bucket, FGA-weighted) from tracking (2023-24, 2024-25); neutral earlier.
- **Placement = ASSEMBLY, not obs-clean.** Shrinkage mutes obs-clean for exactly the high-sample role players (Tyus 9.0k poss, CP3 9.7k) who are the problem, so an obs-clean term wouldn't move them. Applied as a post-cascade transform on the component z-scores. *(This is a deliberate departure from the obs→obs-clean→SE architecture — documented as a known structural note.)*
**Result (2024-25, after defensive-coverage fix):** top of board SGA, Durant, Giannis, Kawhi, Brunson; low-load role players pushed down (CP3, Tyus, Tre, Dowtin, Simmons, Kolek). corr 0.41→0.429.

## Data foundations built this arc
- **bbref pbp parse** (`data.zip`, 6,450 games, 2020-12→2025-06): per-shot shotmaking + per-assist xPTS, keyed bbref_id. → `bbref_shotmaking.csv`, `bbref_assisted.csv`.
- **Uniform player ridge o/d RAPM**, all 5 seasons (`rapm_uniform_*.csv`); consistency gate vs prior file: net corr +0.90.
- **Survivor signals rebuilt for all 5 seasons**: ramanujan_sieve, cascade_family, opp_robustness, topology_a, position_elasticity (+ resid_field, player_positions).
- **RSMATCHUP** (RS matchups) → multi-season interior rim-difficulty for RPV.
- **master_player_table_2425** → LowestThreatSpacer (MIV gravity), rim_contest_det, + many prebuilt signals.

## Reproducible build scripts (re-saved; had been lost)
`build_cascade.py` (the real cascade) · `build_rapm.py` · `build_resid.py` · `build_survivor_a.py` · `build_survivor_b.py` · `build_positions.py` · `build_pos_elastic.py`

## Deliverables
- `Gingeball_v2.2_Calculations.xlsx` — 9 tabs: Overview, TCV_Leaderboard_2025, TCV_AllSeasons, Validation_vs_RAPM, Cascade_All, Posteriors_Wide, Calibration, Survivor_Signals, Uniform_RAPM
- `Gingeball_v2.2_PROGRESS.md` — this file
- `BUILD_LOG_PROXIES_AND_LIMITATIONS.md` — running proxy/limitation/decision log
- `COMPONENT_FORMULAS_v2_CLEANED.md` — formula source of truth

## Defensive-coverage fix (this pass)
A latent cascade bug was found while sanity-checking the leaderboard: a cluster of full-time guards (SGA 14.7k poss, Brunson, Edwards, Garland, Cade — 119 of 566 players in 2024-25) had **exactly 0.00 d_tcv**. Root cause: the survivor **SE multiplier (`se_mult`) was NaN** for those players (their bbref didn't map in one of the survivor-signal files), and the cascade's `se_mult = r.get('se_mult',1.0) or 1.0` guard did not catch NaN (NaN is truthy in Python, so `NaN or 1.0` → NaN). The NaN propagated into SE → weight → posterior, dropping DSV/DPC/RPV entirely; assembly's `fillna(0)` then handed those players a free neutral-defense grade, inflating their TCV. **Fix:** coalesce NaN `se_mult`→1.0 (neutral trust) and NaN `obs_clean`→0.0 explicitly. Result: all 566 players now carry defense (all-zero-defense 119→0); SGA grades −0.04 on D, Brunson −0.59; corr 0.416→0.429. Assembly is now a reproducible `build_assembly.py` (was an un-versioned inline step).

## Known gaps, discrepancies & limitations
**Ranking discrepancies (validated against eye/RAPM):**
- **Offense/defense balance unresolved.** Jokić sits #23 — load lifted his offense but his (fairly graded) weak defense caps him. Reliability weights give offense ~58% / defense ~42%. Whether to fit the o_tcv-vs-d_tcv balance to RAPM (raises efficient bigs, slightly circular) or hold theory weights is the one deferred design decision.
- **No team-outcome / winning signal — by design.** Efficient *high-usage* scorers on non-winning teams (LaVine #25, Herro #18) rank high because the components reward real efficiency + volume and load doesn't dock them. "Losing player" is a team-result signal deliberately excluded from individual components (would leak team outcomes into player value).
- **Minor relative-movement artifact:** Cole Anthony nudged 92→80 after the load pass (others fell around him), not a real climb.

**Measuring-stick / validation:**
- corr(career TCV, multiseason netRAPM) = **0.429** — modest. Heavy-shrinkage compression is the main driver; refinement possible.
- Single-season RAPM too noisy to fit assembly weights (NNLS/ridge degenerate; LeBron −3.89). Reliability weighting is provisional.

**Data-coverage / proxy discrepancies (labeled):**
- **usage proxy** `(FGA+TOV)/poss` omits FTA → r=0.90 vs real usg_pct (used real for 2024-25, proxy 2021-24).
- **attention** (closest-defender) is tracking-gold for 2023-24 & 2024-25 only; neutral for 2021-23 → LOAD is usage-only those years.
- **MIV gravity** is 2024-25 gold (LowestThreatSpacer) vs spot-up-threat proxy 2021-24 (season inconsistency, muted by r=.305).
- **RPV** 2020-21 rim D missing (season 5).
- **DSV** perimeter matchup-FG ceiling (audited via dRAPM diagnostic, not a fitted input).

**Architecture notes:**
- **Load adjustment lives at assembly, not obs-clean** (shrinkage-muting reason above) — the one place TCV departs from the obs→obs-clean→SE→cascade flow.
- **MIV teammate-shot-quality-lift core** (0.36 wt) still deferred — needs xPTS-teammate-after-movement pbp build.
- Low-w small-sample tail handled by a poss≥1,000 leaderboard display filter (not a model change).
