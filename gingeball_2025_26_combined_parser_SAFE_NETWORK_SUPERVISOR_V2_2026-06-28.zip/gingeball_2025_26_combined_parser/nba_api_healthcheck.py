"""
Gingeball NBA network health check
=================================

Safe checks only: documented NBA live-data CDN fallback, static schedule CDN,
local cache behavior, bring-your-own proxy wiring, and request-budget settings.
No public proxy scraping, Tor rotation, or headless browser bypassing is used.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import gingeball_2025_26_combined_parser as g


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--game-id", default="0022500001", help="NBA game id to test, e.g. 0022500001")
    ap.add_argument("--cache-dir", default="./data/nba_network_cache")
    ap.add_argument("--json", action="store_true", help="Print machine-readable JSON only.")
    args = ap.parse_args()

    cache_dir = Path(args.cache_dir)
    g.set_nba_network_cache_dir(cache_dir)
    g.set_nba_api_failure_log(cache_dir.parent / "nba_api_failures.csv")

    result = g.run_nba_endpoint_healthcheck(args.game_id)
    result["cache_dir"] = str(cache_dir)
    result["cache_mode"] = os.getenv("GINGEBALL_NBA_CACHE_MODE", "readwrite")
    result["transport"] = os.getenv("GINGEBALL_NBA_TRANSPORT", "auto")
    result["byo_proxy_configured"] = bool(g._configured_proxy_dict())
    result["max_calls_per_minute"] = os.getenv("GINGEBALL_NBA_MAX_CALLS_PER_MINUTE", "40")
    result["max_calls_per_game"] = os.getenv("GINGEBALL_NBA_MAX_CALLS_PER_GAME", "120")

    if args.json:
        print(json.dumps(result, indent=2))
        return 0 if result.get("ok") else 2

    print(json.dumps(result, indent=2))
    if result.get("ok"):
        print("NBA safe-route healthcheck OK.")
        return 0
    print("NBA safe-route healthcheck returned no usable rows. See nba_api_failures.csv.")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
