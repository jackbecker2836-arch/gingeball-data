# Gingeball 2025-26 Combined Master Parser

This package combines your existing `pbp_scraper.py` BBRef authority layer with the Gingeball enrichment/parser layer.

## What it does

### Path A — BBRef authority scrape for 2025-26
Uses your existing scraper logic for:

- raw Basketball-Reference PBP
- raw HTML cache
- FT-aware true possessions
- complete lineup stints
- player ids/names
- assist/block/steal actors
- shot distance / BBRef shot-zone approximation
- QC manifests / failures

### Path B — normalized master tables
Builds:

- `clean_game_events.csv`
- `possession_frames.csv`
- `event_lineups.csv`
- `possession_lineups.csv`
- `observed_touch_chain.csv`
- `possession_proxy_labels.csv`
- `event_advanced_context.csv`

### Path C — modern enrichment sidecars
When NBA game ID can be resolved:

- `nba_playbyplayv3_sidecar.csv`
- `nba_shotchartdetail_sidecar.csv`
- `nba_videoevents_sidecar.csv` if `--videoevents` is used
- `public_tracking_aggregates_leaguedashptstats.csv` if `--fetch-tracking` is used

### Path D — coverage/tactical labels
Optional sources:

- alternate/data broadcasts
- closed captions/subtitles
- broadcast/radio transcripts
- written live blogs/recaps
- postgame film breakdowns

Each label has source, evidence text, confidence, event/possession link when possible.

### Path E — advanced event-context features
Adds conservative, auditable columns to `clean_game_events.csv` and writes a slim `event_advanced_context.csv`:

- steal/rebound/cut/miss/contest sub-types
- off-ball screen family tags
- switch-network and playbook-preset cues
- real NBA shot/event coordinates when sidecars provide them
- coarse/null spatial hints when exact coordinates are unavailable
- source + confidence columns so downstream models can avoid fake precision

## Install

```bash
pip install -r requirements.txt
```

You also need `ffmpeg` in PATH for audio/video workflows.

## First safe test

```bash
python gingeball_2025_26_combined_parser.py --scrape-bbref --enrich --limit 5 --bbref-data-dir ./data_2025_26_bbref --out ./data_2025_26_master
```

## Full 2025-26 BBRef scrape

```bash
python gingeball_2025_26_combined_parser.py --scrape-bbref --season-year 2026 --bbref-data-dir ./data_2025_26_bbref
```

This is resume-safe. It will skip games already present in `raw_pbp`, `possessions/*_tp.csv`, and `possessions/*_lineups.csv`.

## Enrich after scrape

```bash
python gingeball_2025_26_combined_parser.py --enrich-only --bbref-data-dir ./data_2025_26_bbref --out ./data_2025_26_master
```

## Use coverage sources

Edit `sources.example.json`, then run:

```bash
python gingeball_2025_26_combined_parser.py --enrich-only --sources sources.example.json --bbref-data-dir ./data_2025_26_bbref --out ./data_2025_26_master
```

## Optional ML trainer

The parser itself does **not** require LightGBM or Supabase. To train the optional shot-quality model after events are generated:

```bash
pip install -r requirements-ml.txt
python shot_predictor_ml.py --events-csv ./data_2025_26_master/202510220LAL/clean_game_events.csv
```

For Supabase pulls, set `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`, then pass `--supabase-table clean_game_events_202526`.

## Output layout

Each game writes to:

```text
data_2025_26_master/<bbref_game_id>/
```

Season summary writes to:

```text
data_2025_26_master/season_report.csv
```

## Important caveats

1. BBRef IDs and NBA GameIDs are different. The script tries to resolve NBA GameID automatically by date + home team via NBA ScoreboardV2.
2. NBA event alignment is time-based and confidence-scored. Treat NBA x/y and clip metadata as sidecar enrichment until you manually validate enough games.
3. Coverage/video/audio ingestion should only use content you have rights or authorization to process.
4. Run a five-game test first. Do not launch the full enrichment/video pass blind.
5. The inferred coordinate layer is intentionally conservative. It uses NBA sidecar x/y when available; otherwise it stores coarse zones/null coordinates plus confidence/source tags. Text-only anchors never write fabricated x/y into coordinate fields and never feed kinematic velocity.


## NBA Stats 403 hardening

The parser now configures `nba_api` through its supported session hook instead of monkey-patching endpoint methods. `requirements.txt` includes `curl_cffi`; when it is installed, the parser uses a Chrome-like transport profile with the normal NBA Stats headers, slow randomized request spacing, and limited retry/backoff. If `curl_cffi` is unavailable, it falls back to normal `requests`.

Environment knobs for Windows CMD:

```cmd
set GINGEBALL_NBA_TRANSPORT=auto
set GINGEBALL_NBA_MIN_DELAY_SECONDS=1.25
set GINGEBALL_NBA_MAX_DELAY_SECONDS=3.75
set GINGEBALL_NBA_MAX_RETRIES=3
set GINGEBALL_NBA_HTTP_DEBUG=1
```

`GINGEBALL_NBA_HTTP_DEBUG=1` is optional and prints endpoint status codes. NBA endpoint failures are also appended to `nba_api_failures.csv` next to the master output folder. The parser does not use proxy rotation or reverse-proxy evasion; if NBA refuses a request, official sidecars stay blank and the BBRef/local fallback layers continue.

## Add-on: win probability + leverage filter

When an NBA GameID resolves and the endpoint responds, the parser now writes:

- `nba_winprobabilitypbp_sidecar.csv`
- `home_win_probability`
- `away_win_probability`
- `official_leverage_index_score` when the upstream payload includes one
- `custom_leverage_index_score`
- `flag_is_low_leverage_garbage_time`
- `win_probability_available`
- `win_probability_source`
- `win_probability_confidence`
- `win_probability_alignment_method`
- `win_probability_seconds_delta` for nearest-time fallback QC

Calibration note: the current `nba_api` docs expose `HOME_PCT`, `VISITOR_PCT`, `EVENT_NUM`, `PERIOD`, `SECONDS_REMAINING`, and `PCTIMESTRING`. The parser supports those names plus common fallback aliases, prefers the period clock string for elapsed-time mapping when present, and only falls back to `SECONDS_REMAINING` after detecting whether it behaves like a period clock or regulation game clock. If the WinProbabilityPBP endpoint fails, the official probability fields remain blank and the parser falls back to a lower-confidence score/time leverage heuristic instead of pretending every event was 50/50.

The optional LightGBM trainer now excludes garbage-time / low-leverage shots by default when those columns exist:

```bash
python shot_predictor_ml.py --events-csv ./data_2025_26_master/202510220LAL/clean_game_events.csv --min-leverage 0.25
```

To deliberately include all rows:

```bash
python shot_predictor_ml.py --events-csv ./data_2025_26_master/202510220LAL/clean_game_events.csv --include-low-leverage
```

### NBA API 403 survival layer

The parser now has a safe fallback path for common `stats.nba.com` failures:

1. Try `nba_api` stats endpoints using the polite `curl_cffi`/requests session.
2. If PlayByPlayV3 fails, fall back to the official NBA live-data CDN play-by-play JSON.
3. If ScoreboardV2 fails during BBRef -> NBA GameID resolution, fall back to the static NBA schedule CDN.
4. Cache CDN JSON in `nba_network_cache/` so reruns can operate from cache.
5. Log blocked/failed NBA routes to `nba_api_failures.csv` and crosswalk failures to `nba_game_id_failures.csv`.

Useful environment knobs:

```bat
set GINGEBALL_NBA_CACHE_MODE=readwrite
set GINGEBALL_NBA_MIN_DELAY_SECONDS=1.25
set GINGEBALL_NBA_MAX_DELAY_SECONDS=3.75
set GINGEBALL_NBA_MAX_RETRIES=3
```

Run a quick network/cache check:

```bat
python nba_api_healthcheck.py --game-id 0022500001
```

This project does not scrape public proxy lists, route through Tor, or use headless browsers to bypass firewall rules. If NBA blocks an endpoint, the pipeline logs the failure and keeps the base BBRef/local pipeline intact.

## Safe network supervisor v2

This build adds the stronger, allowed network architecture:

- **Bring-your-own proxy support** through environment variables. Use only a proxy you control or are authorized to use.
- **Hard request budgets** across all NBA calls.
- **Cooldown after 403/429** so the parser stops hammering when NBA refuses requests.
- **Cache-first sidecar reuse** so once a game has NBA sidecars, reruns do not re-hit NBA for that game unless you change cache mode.
- **Official live-data CDN fallback** for play-by-play.
- **Static schedule CDN fallback** for BBRef → NBA GameID resolution.
- **Local failed-game queue** for resume runs.
- **Endpoint healthcheck** before long enrichment runs.
- **Normalized provenance** with `stats_api`, `live_cdn`, `cache`, `bbref_only`, or `missing` labels.

### Environment knobs

Windows CMD:

```bat
REM Optional authorized proxy. Leave unset if you are not using one.
set GINGEBALL_NBA_PROXY=http://username:password@proxy-host:port
REM or split it:
set GINGEBALL_NBA_HTTP_PROXY=http://username:password@proxy-host:port
set GINGEBALL_NBA_HTTPS_PROXY=http://username:password@proxy-host:port

REM Transport / retry / pacing.
set GINGEBALL_NBA_TRANSPORT=auto
set GINGEBALL_NBA_MAX_CALLS_PER_MINUTE=40
set GINGEBALL_NBA_MAX_CALLS_PER_GAME=120
set GINGEBALL_NBA_MIN_DELAY_SECONDS=1.25
set GINGEBALL_NBA_MAX_DELAY_SECONDS=3.75
set GINGEBALL_NBA_MAX_RETRIES=3
set GINGEBALL_NBA_COOLDOWN_AFTER_BLOCK_SECONDS=90

REM Cache modes:
REM readwrite = default cache-first behavior; read existing sidecars/JSON, fetch missing ones, then write cache.
REM read = offline/cache-only; never make NBA network calls.
REM write = fetch fresh where needed and write cache.
set GINGEBALL_NBA_CACHE_MODE=readwrite
```

PowerShell equivalent:

```powershell
$env:GINGEBALL_NBA_CACHE_MODE="readwrite"
$env:GINGEBALL_NBA_MAX_CALLS_PER_MINUTE="40"
$env:GINGEBALL_NBA_MAX_CALLS_PER_GAME="120"
```

### Healthcheck before a full run

```bat
python gingeball_2025_26_combined_parser.py --nba-healthcheck-only --healthcheck-game-id 0022500001 --out .\data_2025_26_master
```

Abort a long enrichment run if the safe NBA routes are unavailable:

```bat
python gingeball_2025_26_combined_parser.py --enrich-only --require-nba-healthcheck --bbref-data-dir .\data_2025_26_bbref --out .\data_2025_26_master
```

### Resume failed games

Every processing failure is upserted into:

```text
data_2025_26_master/failed_games_queue.csv
```

After fixing the issue or changing cache/network settings, run only the failed games:

```bat
python gingeball_2025_26_combined_parser.py --enrich-only --resume-failed --bbref-data-dir .\data_2025_26_bbref --out .\data_2025_26_master
```

A game is removed from the queue after it processes successfully.

### Provenance columns

`clean_game_events.csv` and `event_advanced_context.csv` now include normalized provenance columns:

- `event_data_provenance`
- `nba_enrichment_provenance`
- `win_probability_data_provenance`

Sidecars include matching route-level provenance where relevant:

- `nba_pbp_provenance`
- `shotchart_provenance`
- `win_probability_provenance`
- `videoevents_provenance`
- `data_provenance`

The vocabulary is intentionally small: `stats_api`, `live_cdn`, `cache`, `bbref_only`, or `missing`.
