# Gingeball 2025-26 Combined Parser Patch Notes — 2026-06-28

## Highest-risk correctness fixes

1. **Possession boundary assignment is now half-open.**
   - Replaced the inclusive event-to-possession scan with a start-keyed `merge_asof` assignment.
   - Primary rule is now `[start_elapsed, end_elapsed)`, with a final-window exception for the last possession in a period.
   - Added `true_possession_attach_method` so bad/unmatched/tolerance assignments are auditable instead of silent.
   - Team matching is retained as a fallback/tie-breaker; it does not pull exact end-boundary events backward into the closing possession.

2. **Period-opening offense is no longer hardcoded to away.**
   - `parse_true_possessions` now derives each period's opening offense from the first non-admin team action in that period.
   - Subs/timeouts are ignored for this inference.
   - If no usable period action exists, it falls back to the prior known offense instead of blindly resetting to away.

3. **Lineup stints are now half-open.**
   - `stint_for_elapsed` now uses `[secs_on, secs_off)` as the primary membership rule.
   - Boundary fallback uses event player IDs to choose the stint that actually contains the player(s), rather than choosing the shortest stint.
   - `build_event_lineups` now passes the event row into `stint_for_elapsed` so boundary ties can use player evidence.

## Speed / scale fixes

4. **Event-to-possession assignment is no longer `events × possessions`.**
   - Replaced the chronological nested scan with period-level `merge_asof`.

5. **BBRef-to-NBA event alignment is no longer a per-event full scan.**
   - Replaced row-by-row period filtering with period/kind grouped `merge_asof` nearest alignment.
   - Event-type filtering now covers shots, turnovers, rebounds, fouls, substitutions, timeouts, and jump balls.
   - Added `nba_game_id` consistently to aligned clean events; the prior non-empty path added action/confidence but not the game id.

## Coverage / tactical label fixes

6. **Timed tactical labels no longer fan out to every nearby event.**
   - Each label from a timed segment now attaches to one nearest compatible event inside the window.
   - Compatibility prioritizes high-value event types by label family, e.g. rebounding labels prefer rebounds, rim/closeout/deception labels prefer shots/fouls/turnovers.
   - Confidence is lightly distance-weighted inside the window.

7. **Whisper confidence is now clearly a source prior.**
   - Replaced the magic `0.64` literal with `WHISPER_SEGMENT_SOURCE_PRIOR` and a comment explaining it is not measured ASR confidence.

8. **Article extraction is less boilerplate-heavy.**
   - Removes nav/header/footer/aside/form/button elements.
   - Uses the densest `<article>` / `<main>` paragraph block instead of concatenating every wrapper.

## Crosswalk fixes

9. **NBA game-id resolution is more robust and auditable.**
   - Scoreboard matching now supports home/visitor columns, `HTM`/`VTM`, `GAMECODE`, and line-score team-set fallback.
   - Matching can use both away and home teams from BBRef.
   - Unresolved or ambiguous matches are logged to `nba_game_id_failures.csv` next to the game output folders.

## Additional silent bug caught during audit

10. **CSV boolean round-trip guard.**
    - Added `is_true()` and normalized BBRef boolean columns after CSV load.
    - This prevents strings like `"False"` from becoming truthy in touch-chain creation and NBA event-type filters.

## Smoke tests run

- `python -m py_compile gingeball_2025_26_combined_parser.py bbref_pbp_scraper.py`
- Toy possession-boundary test: event at exact shared boundary attaches to the new half-open window.
- Toy stint-boundary test: event just before boundary stays with old lineup; event at boundary moves to new lineup.
- Toy CSV boolean test: string `"False"` normalizes to actual `False` and does not create fake touch rows.
- Toy tactical-label test: one caption segment with multiple labels attaches each label to one event, not every event in the ±8s window.

## Add-on calibration patch: event semantics + conservative spatial context

Added from the requested expansion set, but calibrated to avoid fake precision:

- Added `extract_granular_action_sub_types()` for steal, rebound, cut, miss, and contest sub-types.
- Added `extract_off_ball_screen_variations()` for pin-down, flare, back-screen/UCLA, staggered, STS, elevator, and generic off-ball screen tags.
- Added `infer_switching_networks_and_playbooks()` for blown-switch, late-rotation, clean-switch, horns, Spain PnR, pistol, Iverson, elevator, zoom, and hammer cues.
- Added `add_advanced_event_features()` to append these columns directly onto `clean_game_events.csv`.
- Added `event_advanced_context.csv`, a slim export containing just the new event-context layer and event keys.
- Added real-coordinate priority: `nba_shotchartdetail` first, then `nba_playbyplayv3` x/y when aligned.
- Added conservative fallback zones: BBRef shot zone, shot distance, restricted-area/free-throw text anchors. If coordinates are not reliable, x/y remain null rather than invented.
- Added per-actor `kinematic_velocity_fps` only when consecutive reliable NBA coordinate sources exist for the same player in the same possession/period within a short event-log hop. Text anchors and zone-only fallbacks cannot feed velocity.
- Added source/confidence columns: `semantic_subtype_confidence`, `spatial_inference_source`, `spatial_inference_confidence`, and `tracking_inference_confidence`.
- Updated `supabase_schema.sql` with the expanded columns and a separate `event_advanced_context_202526` table.
- Added optional `shot_predictor_ml.py` plus `requirements-ml.txt`; the base parser remains installable without ML dependencies.

Validation:

- `python -m py_compile gingeball_2025_26_combined_parser.py bbref_pbp_scraper.py shot_predictor_ml.py`
- Synthetic smoke test for: back-iron miss, late contest, pin-down screen, Spain PnR, and passing-lane steal.

Additional calibration fix caught during this add-on pass:

- Forced `merge_asof` clock keys to float in possession attachment and NBA alignment. This prevents pandas dtype crashes when one input arrives as integer seconds and the other arrives as float seconds.

## Add-on calibration patch: WinProbabilityPBP + leverage filtering

Added the requested win-probability / leverage layer, but calibrated around the actual endpoint shape and endpoint fragility:

- Added optional `winprobabilitypbp` import.
- Added `fetch_nba_win_probability_pbp()` and `nba_winprobabilitypbp_sidecar.csv`.
- Normalizes NBA docs-style columns: `EVENT_NUM`, `HOME_PCT`, `VISITOR_PCT`, `PERIOD`, `SECONDS_REMAINING`, `PCTIMESTRING`, and common aliases.
- Does not assume `HOME_WP`, `VISITOR_WP`, or `LEVERAGE_INDEX` exist. If an official leverage column appears, it is stored as `official_leverage_index_score`; otherwise it remains null.
- Adds direct `EVENT_NUM` / `nba_action_number` matching first, then nearest elapsed-time fallback within three seconds.
- Adds calibrated event columns: `home_win_probability`, `away_win_probability`, `official_leverage_index_score`, `custom_leverage_index_score`, `flag_is_low_leverage_garbage_time`, `win_probability_available`, `win_probability_source`, `win_probability_confidence`, `win_probability_event_num`, `win_probability_alignment_method`, `win_probability_seconds_delta`, and `leverage_model_version`.
- If the endpoint fails, official WP columns remain blank. The parser still computes a lower-confidence score/time leverage fallback so downstream code has a usable pressure filter without fake 0.50 probabilities.
- Updated `event_advanced_context.csv` and `supabase_schema.sql` with the leverage fields and sidecar table.
- Updated `shot_predictor_ml.py` to filter low-leverage / garbage-time shots by default when leverage columns are available. Use `--include-low-leverage` to override.

Validation added:

- `python -m py_compile gingeball_2025_26_combined_parser.py bbref_pbp_scraper.py shot_predictor_ml.py`
- Synthetic win-prob direct-event match.
- Synthetic win-prob nearest-elapsed fallback.
- Synthetic 4th-quarter 98% WP garbage-time flag.
- Synthetic broken/unavailable endpoint fallback using score margin and time.


## Calibration patch: fake-precision leak + WinProbabilityPBP audit

Fixed issues caught after the leverage build:

- Text-only restricted-area and free-throw anchors now remain zone-only. They no longer emit fabricated `(0,0)` or `(0,189)` into `inferred_actor_x/y`.
- `kinematic_velocity_fps` now requires measured coordinate sources (`nba_shotchartdetail` or aligned `nba_playbyplayv3_xy`) on both sides. NLP/text anchors, BBRef zones, and distance-only hints cannot feed velocity.
- Velocity is additionally constrained to same player, same period, same possession, and a short event-log hop (`<=14s`) so two sparse shots minutes apart are not framed as continuous tracking.
- Spain/action spatial validation now only uses reliable coordinate sources, not text anchors.
- Elevator screen detection now catches broadcast-common phrasing like “elevator doors close/shut” even when the word “screen” is omitted.
- WinProbabilityPBP time mapping now prefers `PCTIMESTRING` and records `winprob_time_basis`; if only `SECONDS_REMAINING` is available, it detects period-clock versus regulation-game-clock basis.
- Win probability alignment now stores `win_probability_seconds_delta` for nearest-time fallbacks, and it can infer the missing side of the probability pair from the other side instead of dropping the row.

Additional smoke tests added:

- Text-anchored layup followed by real shotchart coordinate produces no velocity.
- Two real shotchart coordinates in the same possession can produce velocity; long gaps and possession changes do not.
- “Elevator doors close/shut” screen/playbook phrases are detected.
- WinProbabilityPBP elapsed-time normalization handles both `PCTIMESTRING` and regulation-total `SECONDS_REMAINING`.
- Direct event-number WP matching, nearest elapsed fallback, complement probability inference, and seconds-delta QC all pass synthetic tests.

---

## NBA Stats 403 hardening patch

Added a defensive NBA Stats transport layer without changing the possession/semantic logic.

### Changed

- Added `curl_cffi` to `requirements.txt` as an optional browser-like transport used through nba_api's supported `NBAStatsHTTP.set_session(...)` hook.
- Did **not** monkey-patch `NBAStatsHTTP.request`; current nba_api routes endpoint calls through `NBAHTTP.send_api_request()` and `get_session().get(...)`, so replacing `request` is the wrong integration point.
- Corrected and expanded NBA Stats headers:
  - `Host` remains exactly `stats.nba.com`.
  - `Origin` / `Referer` use `https://www.nba.com`.
  - `x-nba-stats-origin` and `x-nba-stats-token` remain present.
  - added browser fetch/client-hint headers.
- Added slow randomized request spacing and bounded retry/backoff for 403/408/425/429/5xx.
- Added environment controls:
  - `GINGEBALL_NBA_TRANSPORT=auto|requests|curl_cffi`
  - `GINGEBALL_NBA_MIN_DELAY_SECONDS`
  - `GINGEBALL_NBA_MAX_DELAY_SECONDS`
  - `GINGEBALL_NBA_MAX_RETRIES`
  - `GINGEBALL_NBA_HTTP_DEBUG`
- Added `nba_api_failures.csv` logging for ScoreboardV2, PlayByPlayV3, ShotChartDetail, and WinProbabilityPBP failures.

### Not added

- No proxy rotation.
- No reverse-proxy/firewall evasion service.
- No fake win-prob defaults when official endpoints fail.

The parser remains fallback-safe: if NBA Stats refuses a request, BBRef/local features continue and official NBA sidecars remain blank/auditable.

## 2026-06-28 network fallback supervisor calibration

Added a stronger NBA network survival layer without adding public proxy scraping, Tor routing, or browser-bypass automation.

Implemented:
- Official NBA live-data CDN fallback for play-by-play: `https://cdn.nba.com/static/json/liveData/playbyplay/playbyplay_{game_id}.json`.
- Static schedule CDN fallback for BBRef -> NBA GameID crosswalk when ScoreboardV2 403s/fails.
- Cache-first/read-write JSON fetch helper for documented NBA CDN routes.
- `nba_network_cache/` directory support plus `GINGEBALL_NBA_CACHE_DIR` and `GINGEBALL_NBA_CACHE_MODE`.
- `nba_api_healthcheck.py` to test the documented CDN routes and cache behavior.
- `nba_pbp_source` column in the NBA PBP sidecar so you can audit whether the sidecar came from stats PBP or CDN fallback.

Rejected from the pasted design on purpose:
- automated public free-proxy scraping/validation;
- Tor tunneling / IP rotation;
- Playwright or Node bridges framed as firewall-bypass layers;
- the fake `https://nba.com_{game_id}.json` CDN path;
- monkey-patching `NBAStatsHTTP.request`.

Reason: those were either unreliable/broken in the submitted code or were designed to evade access controls. The parser now uses documented NBA data routes, rate-limits politely, caches aggressively, logs failures, and continues parsing from BBRef/local layers when an NBA endpoint blocks.
