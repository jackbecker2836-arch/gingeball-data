"""
Gingeball 2025-26 Combined Master Parser
========================================

This combines Jack's Basketball-Reference PBP / true-possession / lineup-stint scraper
with the Gingeball modern enrichment layer:

A. BBRef authority layer for 2025-26
   - schedule discovery
   - raw HTML cache
   - raw PBP events
   - FT-aware true possessions
   - complete lineup stints
   - QC manifests / failures

B. Master normalized tables
   - clean_game_events
   - possession_frames
   - event_lineups
   - possession_lineups
   - observed_touch_chain

C. NBA Stats enrichment, when NBA game IDs are resolvable
   - automatic BBRef -> NBA game_id crosswalk through ScoreboardV2
   - PlayByPlayV3 sidecar
   - ShotChartDetail exact shot x/y sidecar
   - VideoEvents metadata sidecar
   - LeagueDashPtStats public tracking aggregate attempts

D. Coverage/tactical label layer
   - alternate/data broadcast text/captions/audio
   - closed captions/subtitles
   - broadcast/radio transcript
   - written live blog / recap
   - postgame film breakdown transcript/notes
   - tactical regex labels with source/evidence/confidence

Run examples:
    python gingeball_2025_26_combined_parser.py --scrape-bbref --season-year 2026
    python gingeball_2025_26_combined_parser.py --scrape-bbref --enrich --season-year 2026 --limit 5
    python gingeball_2025_26_combined_parser.py --game 202510220LAL --scrape-bbref --enrich
    python gingeball_2025_26_combined_parser.py --enrich-only --bbref-data-dir ./data_2025_26_bbref --out ./data_2025_26_master

Notes:
- Use only coverage/video/audio you have rights or authorization to process.
- BBRef game IDs look like YYYYMMDDHOM. NBA GameIDs look like 00225xxxxx.
- Automatic crosswalk uses NBA ScoreboardV2 by date + home team abbreviation.
"""

from __future__ import annotations

import argparse
import dataclasses
import gzip
import hashlib
import json
import math
import os
import random
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from collections import defaultdict, deque
import threading
from urllib.parse import urlparse, parse_qs

import requests
import pandas as pd

try:
    from bs4 import BeautifulSoup
except Exception:
    BeautifulSoup = None

try:
    import whisper
except Exception:
    whisper = None

# Local copy of Jack's scraper. Keep it in this same folder.
import bbref_pbp_scraper as bbref

try:
    from nba_api.stats.library.http import NBAStatsHTTP
    from nba_api.stats.endpoints import (
        scoreboardv2,
        playbyplayv3,
        shotchartdetail,
        videoevents,
        leaguedashptstats,
        winprobabilitypbp,
    )
except Exception:
    NBAStatsHTTP = None
    scoreboardv2 = None
    playbyplayv3 = None
    shotchartdetail = None
    videoevents = None
    leaguedashptstats = None
    winprobabilitypbp = None


# =============================================================================
# Constants / headers
# =============================================================================

NBA_HEADERS = {
    # Keep Host exact.  A bad value here can create instant 403s.
    "Host": "stats.nba.com",
    "Connection": "keep-alive",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.9",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/122.0.0.0 Safari/537.36"
    ),
    "Origin": "https://www.nba.com",
    "Referer": "https://www.nba.com/",
    "Sec-Fetch-Site": "same-site",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Dest": "empty",
    "sec-ch-ua": '"Chromium";v="122", "Google Chrome";v="122", "Not:A-Brand";v="99"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "x-nba-stats-origin": "stats",
    "x-nba-stats-token": "true",
}

NBA_API_TRANSPORT_MODE = "requests"
NBA_API_FAILURE_LOG_PATH: Optional[Path] = None
NBA_NETWORK_CACHE_DIR: Optional[Path] = None
NBA_LIVE_PBP_CDN_URL = "https://cdn.nba.com/static/json/liveData/playbyplay/playbyplay_{game_id}.json"
NBA_STATIC_SCHEDULE_URL = "https://cdn.nba.com/static/json/staticData/scheduleLeagueV2_1.json"

NBA_CDN_HEADERS = {
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.9",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "User-Agent": NBA_HEADERS["User-Agent"],
    "Origin": "https://www.nba.com",
    "Referer": "https://www.nba.com/",
}


def _cache_mode() -> str:
    return os.getenv("GINGEBALL_NBA_CACHE_MODE", "readwrite").strip().lower().replace("-", "_")


def _cache_read_enabled() -> bool:
    return _cache_mode() in {"read", "readwrite", "cache", "cache_first", "cacheonly", "cache_only"}


def _cache_network_disabled() -> bool:
    return _cache_mode() in {"read", "offline", "cacheonly", "cache_only"}


def _env_bool(name: str, default: bool = False) -> bool:
    val = os.getenv(name)
    if val is None:
        return default
    return val.strip().lower() in {"1", "true", "yes", "y", "on"}


def normalize_nba_provenance(source: Any) -> str:
    """Normalize a route/source label to the small provenance vocabulary.

    User-facing downstream rows should be auditable with one of:
    stats_api, live_cdn, cache, bbref_only, or missing.
    """
    s = str(source or "").strip().lower()
    if not s or s in {"none", "nan", "null"}:
        return "missing"
    if "cache" in s:
        return "cache"
    if "live_cdn" in s or "cdn" in s or "schedule" in s:
        return "live_cdn"
    if "stats" in s or "shotchart" in s or "winprobability" in s or "videoevents" in s or "playbyplayv3" in s:
        return "stats_api"
    if "bbref" in s or "fallback" in s or "score_time" in s or "neutral" in s:
        return "bbref_only"
    return "missing"


def _configured_proxy_dict() -> Optional[Dict[str, str]]:
    """Return bring-your-own authorized proxy settings from env vars.

    This intentionally does not scrape public proxies or rotate through unknown
    infrastructure. Use a proxy you control/are authorized to use.
    """
    single = os.getenv("GINGEBALL_NBA_PROXY")
    http = os.getenv("GINGEBALL_NBA_HTTP_PROXY") or single
    https = os.getenv("GINGEBALL_NBA_HTTPS_PROXY") or single
    proxies: Dict[str, str] = {}
    if http:
        proxies["http"] = http.strip()
    if https:
        proxies["https"] = https.strip()
    return proxies or None


def _extract_game_id_from_params_url(params: Any = None, url: Optional[str] = None) -> Optional[str]:
    keys = [
        "GameID", "game_id", "gameId", "GAME_ID", "game_id_nullable",
        "GameIDNullable", "gameid", "GameId", "gameID",
    ]
    if isinstance(params, dict):
        for k in keys:
            if k in params and params[k] not in {None, ""}:
                return str(params[k])
    if url:
        try:
            qs = parse_qs(urlparse(url).query)
            for k in keys:
                if k in qs and qs[k]:
                    return str(qs[k][0])
            m = re.search(r"(?:playbyplay|boxscore|winprobabilitypbp|shotchart|videoevents)[_/](\d{10})", url, re.I)
            if m:
                return m.group(1)
            m = re.search(r"(?:playbyplay_|boxscore_)(\d{10})\.json", url, re.I)
            if m:
                return m.group(1)
        except Exception:
            pass
    return None


class NBARequestBudgetExceeded(RuntimeError):
    pass


class NBARequestBudget:
    """Shared hard budget for all NBA network calls.

    - Max calls/minute is enforced by sleeping until the window clears.
    - Max calls/game is enforced by raising, so a single game cannot burn an
      unlimited number of endpoint attempts.
    - 403/429 responses trigger a cooldown before the next attempt.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._minute_calls: deque[float] = deque()
        self._game_calls: Dict[str, int] = defaultdict(int)

    def reset_game(self, game_id: Optional[str]) -> None:
        if not game_id:
            return
        with self._lock:
            self._game_calls.pop(str(game_id), None)

    def before_request(self, endpoint: str, game_id: Optional[str] = None) -> None:
        max_per_min = _env_int("GINGEBALL_NBA_MAX_CALLS_PER_MINUTE", 40)
        max_per_game = _env_int("GINGEBALL_NBA_MAX_CALLS_PER_GAME", 120)
        now = time.monotonic()
        sleep_for = 0.0
        with self._lock:
            while self._minute_calls and now - self._minute_calls[0] >= 60.0:
                self._minute_calls.popleft()
            if max_per_min > 0 and len(self._minute_calls) >= max_per_min:
                sleep_for = max(0.0, 60.0 - (now - self._minute_calls[0]))
            gid = str(game_id) if game_id else None
            if gid and max_per_game > 0 and self._game_calls[gid] >= max_per_game:
                raise NBARequestBudgetExceeded(
                    f"NBA request budget exceeded for game {gid}: "
                    f"{self._game_calls[gid]} >= {max_per_game} calls"
                )
        if sleep_for > 0:
            if _env_bool("GINGEBALL_NBA_HTTP_DEBUG", False):
                print(f"NBA budget: sleeping {sleep_for:.2f}s to respect calls/minute limit")
            time.sleep(sleep_for)
        with self._lock:
            ts = time.monotonic()
            self._minute_calls.append(ts)
            if game_id:
                self._game_calls[str(game_id)] += 1

    def after_response(self, status_code: Any, endpoint: str, game_id: Optional[str] = None) -> None:
        try:
            status = int(status_code)
        except Exception:
            return
        if status in {403, 429}:
            cooldown = max(0.0, _env_float("GINGEBALL_NBA_COOLDOWN_AFTER_BLOCK_SECONDS", 90.0))
            if cooldown > 0:
                print(f"NBA {status} on {endpoint}; cooling down {cooldown:.1f}s before more NBA calls.")
                time.sleep(cooldown)


NBA_REQUEST_BUDGET = NBARequestBudget()


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)))
    except Exception:
        return default


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except Exception:
        return default


def set_nba_api_failure_log(path: Optional[str | Path]) -> None:
    global NBA_API_FAILURE_LOG_PATH
    NBA_API_FAILURE_LOG_PATH = Path(path) if path else None


def set_nba_network_cache_dir(path: Optional[str | Path]) -> None:
    global NBA_NETWORK_CACHE_DIR
    NBA_NETWORK_CACHE_DIR = Path(path) if path else None


def _nba_network_cache_dir() -> Path:
    env_path = os.getenv("GINGEBALL_NBA_CACHE_DIR")
    if env_path:
        return ensure_dir(Path(env_path))
    if NBA_NETWORK_CACHE_DIR is not None:
        return ensure_dir(NBA_NETWORK_CACHE_DIR)
    if NBA_API_FAILURE_LOG_PATH is not None:
        return ensure_dir(NBA_API_FAILURE_LOG_PATH.parent / "nba_network_cache")
    return ensure_dir(Path("data") / "nba_network_cache")


def _cache_path_for_url(url: str, params: Optional[Dict[str, Any]] = None) -> Path:
    key = url
    if params:
        key += "?" + "&".join(f"{k}={params[k]}" for k in sorted(params))
    digest = hashlib.sha1(key.encode("utf-8")).hexdigest()
    return _nba_network_cache_dir() / f"{digest}.json"


def _raw_get_json_with_cache(
    endpoint: str,
    game_id: Optional[str],
    url: str,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: int = 30,
) -> Tuple[Optional[Dict[str, Any]], str]:
    """Polite JSON fetch with cache and audit logging.

    This is for documented/static NBA routes such as cdn.nba.com live-data JSON.
    It intentionally does not scrape public proxies, use Tor, or tunnel around
    access controls.  If the route fails, callers get None and keep parsing from
    BBRef/local layers.
    """
    cache_path = _cache_path_for_url(url, params)
    cache_mode = _cache_mode()
    if _cache_read_enabled() and cache_path.exists():
        try:
            return json.loads(cache_path.read_text(encoding="utf-8")), "cache"
        except Exception as e:
            log_nba_api_failure(endpoint, game_id, f"cache_read_failed: {e}", {"url": url})

    if _cache_network_disabled():
        log_nba_api_failure(endpoint, game_id, "cache_miss_offline_read_mode", {"url": url})
        return None, "cache_miss"

    min_delay = max(0.0, _env_float("GINGEBALL_NBA_MIN_DELAY_SECONDS", 1.25))
    max_delay = max(min_delay, _env_float("GINGEBALL_NBA_MAX_DELAY_SECONDS", 3.75))
    if max_delay > 0:
        time.sleep(random.uniform(min_delay, max_delay))

    req_headers = dict(headers or NBA_CDN_HEADERS)
    max_retries = max(1, _env_int("GINGEBALL_NBA_MAX_RETRIES", 3))
    last_error: Any = None
    resolved_game_id = game_id or _extract_game_id_from_params_url(params=params, url=url)
    proxy_cfg = _configured_proxy_dict()
    for attempt in range(max_retries):
        try:
            NBA_REQUEST_BUDGET.before_request(endpoint, resolved_game_id)
            try:
                from curl_cffi import requests as cffi_requests  # type: ignore
                kwargs = dict(
                    url=url, params=params, headers=req_headers, timeout=timeout,
                    impersonate=os.getenv("GINGEBALL_CURL_CFFI_IMPERSONATE", "chrome"),
                )
                if proxy_cfg:
                    kwargs["proxies"] = proxy_cfg
                response = cffi_requests.get(**kwargs)
                route = "curl_cffi_direct" if not proxy_cfg else "curl_cffi_byo_proxy"
            except Exception:
                kwargs = dict(url=url, params=params, headers=req_headers, timeout=timeout)
                if proxy_cfg:
                    kwargs["proxies"] = proxy_cfg
                response = requests.get(**kwargs)
                route = "requests_direct" if not proxy_cfg else "requests_byo_proxy"
            status = int(getattr(response, "status_code", 0) or 0)
            NBA_REQUEST_BUDGET.after_response(status, endpoint, resolved_game_id)
            if status == 200:
                data = response.json() if hasattr(response, "json") else json.loads(response.text)
                if cache_mode in {"write", "readwrite", "cache", "cache_first"}:
                    try:
                        ensure_dir(cache_path.parent)
                        cache_path.write_text(json.dumps(data), encoding="utf-8")
                    except Exception as e:
                        log_nba_api_failure(endpoint, resolved_game_id, f"cache_write_failed: {e}", {"url": url})
                return data, route
            last_error = f"HTTP {status}"
            log_nba_api_failure(endpoint, resolved_game_id, last_error, {"url": url, "route": route, "attempt": attempt + 1})
            if status not in {403, 408, 425, 429, 500, 502, 503, 504}:
                break
        except NBARequestBudgetExceeded as e:
            last_error = e
            log_nba_api_failure(endpoint, resolved_game_id, e, {"url": url, "attempt": attempt + 1, "budget_exceeded": True})
            break
        except Exception as e:
            last_error = e
            log_nba_api_failure(endpoint, resolved_game_id, e, {"url": url, "attempt": attempt + 1})
        time.sleep(max(0.0, _env_float("GINGEBALL_NBA_BACKOFF_BASE_SECONDS", 2.0)) * (attempt + 1))
    return None, f"failed:{last_error}"


def log_nba_api_failure(endpoint: str, game_id: Optional[str], error: Any, context: Optional[Dict[str, Any]] = None) -> None:
    """Append NBA endpoint failures to a CSV so 403/timeouts are auditable."""
    if NBA_API_FAILURE_LOG_PATH is None:
        return
    try:
        ensure_dir(NBA_API_FAILURE_LOG_PATH.parent)
        row = {
            "timestamp_utc": pd.Timestamp.utcnow().isoformat(),
            "endpoint": endpoint,
            "game_id": game_id,
            "transport": NBA_API_TRANSPORT_MODE,
            "error": str(error)[:1000],
        }
        if context:
            row.update({k: v for k, v in context.items() if k not in row})
        exists = NBA_API_FAILURE_LOG_PATH.exists()
        pd.DataFrame([row]).to_csv(NBA_API_FAILURE_LOG_PATH, mode="a", header=not exists, index=False)
    except Exception:
        pass


class PoliteNBAStatsSession:
    """Session object compatible with nba_api's NBAHTTP.get_session().

    It keeps NBA requests slow, header-complete, retried, and optionally served
    through curl_cffi when that package is installed.  It does not rotate proxies
    or try to evade account/IP bans; if the endpoint still refuses a request, the
    parser logs the failure and falls back to BBRef/local features.
    """

    def __init__(self) -> None:
        global NBA_API_TRANSPORT_MODE
        requested = os.getenv("GINGEBALL_NBA_TRANSPORT", "auto").strip().lower()
        self.max_retries = max(1, _env_int("GINGEBALL_NBA_MAX_RETRIES", 3))
        self.min_delay = max(0.0, _env_float("GINGEBALL_NBA_MIN_DELAY_SECONDS", 1.25))
        self.max_delay = max(self.min_delay, _env_float("GINGEBALL_NBA_MAX_DELAY_SECONDS", 3.75))
        self.backoff_base = max(0.0, _env_float("GINGEBALL_NBA_BACKOFF_BASE_SECONDS", 2.0))
        self.debug = os.getenv("GINGEBALL_NBA_HTTP_DEBUG", "0").strip().lower() in {"1", "true", "yes"}
        self.retry_statuses = {403, 408, 425, 429, 500, 502, 503, 504}
        self.mode = "requests"
        self.session: Any = requests.Session()
        self.proxy_cfg = _configured_proxy_dict()

        if requested in {"auto", "curl_cffi", "curl-cffi", "curl"}:
            try:
                from curl_cffi.requests import Session as CurlCffiSession  # type: ignore
                impersonate = os.getenv("GINGEBALL_CURL_CFFI_IMPERSONATE", "chrome")
                self.session = CurlCffiSession(impersonate=impersonate, timeout=30)
                self.mode = "curl_cffi"
            except Exception as e:
                if requested not in {"auto", ""}:
                    print(f"WARN: curl_cffi transport requested but unavailable ({e}); falling back to requests.")

        NBA_API_TRANSPORT_MODE = self.mode

    def _delay(self, attempt: int) -> None:
        if self.max_delay <= 0:
            return
        base = random.uniform(self.min_delay, self.max_delay)
        if attempt > 0 and self.backoff_base > 0:
            base += self.backoff_base * (2 ** (attempt - 1))
        time.sleep(base)

    def get(self, url: str, params: Any = None, headers: Optional[Dict[str, str]] = None, proxies: Any = None, timeout: Any = None, **kwargs: Any) -> Any:
        req_headers = dict(NBA_HEADERS)
        if headers:
            req_headers.update({k: v for k, v in headers.items() if v is not None})

        last_response = None
        last_error = None
        for attempt in range(self.max_retries):
            self._delay(attempt)
            try:
                game_id = _extract_game_id_from_params_url(params=params, url=url)
                NBA_REQUEST_BUDGET.before_request("NBAStatsHTTP", game_id)
                request_kwargs = {
                    "url": url,
                    "params": params,
                    "headers": req_headers,
                    "timeout": timeout or 30,
                }
                active_proxies = proxies or self.proxy_cfg
                if active_proxies:
                    request_kwargs["proxies"] = active_proxies
                response = self.session.get(**request_kwargs)
                last_response = response
                status = int(getattr(response, "status_code", 0) or 0)
                NBA_REQUEST_BUDGET.after_response(status, "NBAStatsHTTP", game_id)
                if self.debug:
                    proxy_note = " via BYO proxy" if active_proxies else ""
                    print(f"NBA HTTP {status} via {self.mode}{proxy_note}: {getattr(response, 'url', url)}")
                if status not in self.retry_statuses:
                    return response
            except NBARequestBudgetExceeded as e:
                last_error = e
                if self.debug:
                    print(f"NBA budget stop via {self.mode}: {e}")
                raise
            except Exception as e:
                last_error = e
                if self.debug:
                    print(f"NBA HTTP error via {self.mode}: {e}")

        if last_response is not None:
            return last_response
        raise last_error or RuntimeError("NBA stats request failed before receiving a response")


def configure_nba_stats_http() -> None:
    if NBAStatsHTTP is None:
        return
    NBAStatsHTTP.headers = dict(NBA_HEADERS)
    # nba_api routes all endpoint classes through NBAHTTP.get_session(). Setting
    # the session here is safer than monkey-patching request/send_api_request.
    try:
        NBAStatsHTTP.set_session(PoliteNBAStatsSession())
    except Exception as e:
        print(f"WARN: could not configure NBAStatsHTTP session: {e}")


configure_nba_stats_http()

BBREF_TO_NBA_TEAM = {
    "ATL": "ATL", "BOS": "BOS", "BRK": "BKN", "BKN": "BKN", "CHO": "CHA", "CHA": "CHA",
    "CHI": "CHI", "CLE": "CLE", "DAL": "DAL", "DEN": "DEN", "DET": "DET", "GSW": "GSW",
    "HOU": "HOU", "IND": "IND", "LAC": "LAC", "LAL": "LAL", "MEM": "MEM", "MIA": "MIA",
    "MIL": "MIL", "MIN": "MIN", "NOP": "NOP", "NOH": "NOP", "NYK": "NYK", "OKC": "OKC",
    "ORL": "ORL", "PHI": "PHI", "PHO": "PHX", "PHX": "PHX", "POR": "POR", "SAC": "SAC",
    "SAS": "SAS", "TOR": "TOR", "UTA": "UTA", "WAS": "WAS",
}

SOURCE_ALT_BROADCAST = "alternate_data_broadcast"              # 6
SOURCE_CLOSED_CAPTIONS = "closed_captions_subtitles"           # 7
SOURCE_BROADCAST_TRANSCRIPT = "broadcast_radio_transcript"     # 8
SOURCE_WRITTEN_COVERAGE = "written_live_blog_recap"            # 10
SOURCE_FILM_BREAKDOWN = "postgame_film_breakdown"              # 11
SOURCE_PBP_DESCRIPTION = "pbp_description"

# Whisper does not expose reliable per-segment confidence here; this is a
# source-trust prior, not measured ASR certainty.
WHISPER_SEGMENT_SOURCE_PRIOR = 0.64

SEMANTIC_FEATURE_VERSION = "event_semantics_v2_2026_06_28"
LEVERAGE_FEATURE_VERSION = "winprob_leverage_v2_2026_06_28"

REAL_COORDINATE_SOURCES = {"nba_shotchartdetail", "nba_playbyplayv3_xy"}


# =============================================================================
# Coverage source data classes
# =============================================================================

@dataclass
class CoverageSource:
    source_id: str
    source_type: str
    label: str
    bbref_game_id: Optional[str] = None
    nba_game_id: Optional[str] = None
    url: Optional[str] = None
    local_path: Optional[str] = None
    notes: Optional[str] = None
    trusted: bool = False
    # If a video/audio/caption starts before tipoff, set this to seconds from source start to game start.
    broadcast_offset_seconds: float = 0.0

@dataclass
class TranscriptSegment:
    source_id: str
    source_type: str
    start_seconds: Optional[float]
    end_seconds: Optional[float]
    text: str
    confidence: float = 0.60

@dataclass
class TacticalLabel:
    bbref_game_id: str
    nba_game_id: Optional[str]
    event_id: Optional[str]
    event_index: Optional[int]
    true_possession_id: Optional[str]
    period: Optional[int]
    clock: Optional[str]
    source_id: str
    source_type: str
    label_family: str
    label_value: str
    confidence: float
    evidence_text: str
    evidence_start_seconds: Optional[float] = None
    evidence_end_seconds: Optional[float] = None
    label_version: str = "coverage_fusion_v1"


# =============================================================================
# Tactical phrase dictionary
# =============================================================================

TACTICAL_PATTERNS: Dict[str, Dict[str, Any]] = {
    "double_team": {
        "family": "attention", "base_confidence": 0.76,
        "positive": [r"\bdouble[- ]team(?:ed|s|ing)?\b", r"\bdraws two\b", r"\btwo defenders\b", r"\btwo on (?:the )?ball\b", r"\bthey send two\b", r"\bwall of defenders\b", r"\bdefense collapses\b", r"\bcollapses on him\b", r"\bpaint collapses\b"],
        "negative": [r"\bnot a double\b", r"\bno double\b", r"\bdon't double\b", r"\bshould double\b", r"\bcould double\b", r"\bmay double\b"],
    },
    "soft_help_shade": {"family": "attention", "base_confidence": 0.62, "positive": [r"\bshow(?:s|ing)? help\b", r"\bshade(?:s|d)? toward\b", r"\bloads up\b", r"\bhelp is there\b"], "negative": [r"\bno help\b", r"\bstays home\b"]},
    "decoy_gravity": {"family": "attention", "base_confidence": 0.58, "positive": [r"\bdecoy\b", r"\boccupies two\b", r"\bkeeps the defender attached\b", r"\bgravity\b"], "negative": []},
    "drop_coverage": {"family": "coverage", "base_confidence": 0.78, "positive": [r"\bdrop coverage\b", r"\bdrops back\b", r"\bbig is in a drop\b", r"\bsitting in the paint\b", r"\bconcedes the mid(?:range)?\b"], "negative": [r"\bnot in drop\b", r"\bno drop\b"]},
    "switch": {"family": "coverage", "base_confidence": 0.72, "positive": [r"\bswitch(?:ed|es|ing)?\b", r"\bswitch everything\b", r"\blate switch\b"], "negative": [r"\bnot switching\b", r"\bdidn'?t switch\b", r"\bno switch\b"]},
    "blitz_trap": {"family": "coverage", "base_confidence": 0.80, "positive": [r"\bblitz(?:ed|es|ing)?\b", r"\btrap(?:ped|s|ping)?\b", r"\baggressive trap\b", r"\bsend(?:s|ing)? two\b"], "negative": [r"\bnot a trap\b", r"\bno trap\b"]},
    "hedge": {"family": "coverage", "base_confidence": 0.68, "positive": [r"\bhedge(?:s|d|ing)?\b", r"\bshow and recover\b", r"\bshows high\b"], "negative": []},
    "ice_side_pnr": {"family": "coverage", "base_confidence": 0.63, "positive": [r"\bice\b", r"\bdowning the screen\b", r"\bforces him baseline\b"], "negative": []},
    "zone_defense": {"family": "coverage", "base_confidence": 0.74, "positive": [r"\bzone\b", r"\btwo[- ]three zone\b", r"\b2[- ]3 zone\b", r"\bthree[- ]two zone\b", r"\b3[- ]2 zone\b", r"\bbox and one\b", r"\bjunk defense\b"], "negative": [r"\bnot a zone\b", r"\bman to man\b", r"\bman-to-man\b"]},
    "scramble_rotation": {"family": "coverage", "base_confidence": 0.66, "positive": [r"\bscramble\b", r"\brotat(?:e|es|ing|ion)\b", r"\bemergency rotation\b", r"\bin rotation\b"], "negative": []},
    "nail_help": {"family": "help", "base_confidence": 0.66, "positive": [r"\bnail help\b", r"\bhelp at the nail\b", r"\bfree[- ]throw line help\b", r"\bstunts at the nail\b"], "negative": []},
    "lowman_tag": {"family": "help", "base_confidence": 0.70, "positive": [r"\blow man\b", r"\btags the roller\b", r"\btag(?:s|ged|ging)? the roll(?:er)?\b", r"\bweak[- ]side tag\b"], "negative": []},
    "paint_collapse": {"family": "help", "base_confidence": 0.72, "positive": [r"\bpaint collapses\b", r"\bcollapses the paint\b", r"\bdefense collapses\b", r"\bwall at the rim\b"], "negative": []},
    "spain_pnr": {"family": "set_action", "base_confidence": 0.84, "positive": [r"\bspain pick[- ]and[- ]roll\b", r"\bspain pnr\b", r"\bbackscreen(?:s|ing)? the roller\b", r"\bback screen on the roll(?:er)?\b"], "negative": []},
    "horns": {"family": "set_action", "base_confidence": 0.78, "positive": [r"\bhorns\b", r"\btwo bigs at the elbows\b", r"\belbow alignment\b", r"\bboth elbows occupied\b"], "negative": []},
    "dho": {"family": "set_action", "base_confidence": 0.78, "positive": [r"\bdribble hand[- ]?off\b", r"\bdho\b", r"\bhandoff\b"], "negative": []},
    "zoom_action": {"family": "set_action", "base_confidence": 0.72, "positive": [r"\bzoom action\b", r"\bpindown into a handoff\b", r"\boff the pin[- ]down into the handoff\b"], "negative": []},
    "hammer_action": {"family": "set_action", "base_confidence": 0.78, "positive": [r"\bhammer\b", r"\bhammer pass\b", r"\bweak[- ]side corner\b", r"\bbaseline drive.*corner\b"], "negative": []},
    "post_split": {"family": "set_action", "base_confidence": 0.76, "positive": [r"\bpost split\b", r"\bsplit action\b", r"\bsplits around the post\b"], "negative": []},
    "ghost_screen": {"family": "set_action", "base_confidence": 0.70, "positive": [r"\bghost screen\b", r"\bghosts the screen\b", r"\bslips out before contact\b"], "negative": []},
    "pocket_pass": {"family": "pass_type", "base_confidence": 0.84, "positive": [r"\bpocket pass\b", r"\bslips it inside\b", r"\bthreads it to the roll(?:er)?\b"], "negative": []},
    "drive_and_kick": {"family": "pass_type", "base_confidence": 0.84, "positive": [r"\bdrive and kick\b", r"\bkick(?:s|ed)? it out\b", r"\bkickout\b", r"\bcollapse and kick\b"], "negative": []},
    "skip_pass": {"family": "pass_type", "base_confidence": 0.80, "positive": [r"\bskip pass\b", r"\bcross[- ]court pass\b", r"\bopposite corner\b"], "negative": []},
    "swing_swing": {"family": "pass_type", "base_confidence": 0.74, "positive": [r"\bswing[- ]swing\b", r"\bone more\b", r"\bextra pass\b"], "negative": []},
    "pump_fake": {"family": "deception", "base_confidence": 0.78, "positive": [r"\bpump fake\b", r"\bup fake\b", r"\bshot fake\b", r"\bbit on the fake\b"], "negative": []},
    "fly_by_closeout": {"family": "closeout", "base_confidence": 0.72, "positive": [r"\bfly[- ]by\b", r"\bflew past\b", r"\bruns him off\b", r"\bran him off\b"], "negative": []},
    "controlled_closeout": {"family": "closeout", "base_confidence": 0.68, "positive": [r"\bcontrolled closeout\b", r"\bcloses out short\b", r"\bchopping feet\b"], "negative": []},
    "tip_out": {"family": "rebounding", "base_confidence": 0.82, "positive": [r"\btip(?:s|ped)? it out\b", r"\btap(?:s|ped)? it back\b", r"\bkeeps it alive\b"], "negative": []},
    "box_out": {"family": "rebounding", "base_confidence": 0.76, "positive": [r"\bbox(?:es|ed)? out\b", r"\bcrowded the glass\b", r"\bseals him on the glass\b"], "negative": []},
}


# =============================================================================
# Utilities
# =============================================================================

def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def clean_text(text: Any) -> str:
    return re.sub(r"\s+", " ", str(text or "").replace("\n", " ")).strip()


def write_csv(df: pd.DataFrame, path: Path) -> None:
    ensure_dir(path.parent)
    df.to_csv(path, index=False)


def read_table(path: str | Path) -> pd.DataFrame:
    p = Path(path)
    if not p.exists():
        return pd.DataFrame()
    if p.suffix.lower() in {".parquet", ".pq"}:
        return pd.read_parquet(p)
    return pd.read_csv(p)


def bbref_clock_to_seconds_remaining(s: Any) -> Optional[float]:
    m = re.match(r"(\d+):(\d+(?:\.\d+)?)", str(s).strip())
    return int(m.group(1)) * 60 + float(m.group(2)) if m else None


def elapsed_from_bbref_clock(period: int, time_remaining: Any) -> Optional[float]:
    rem = bbref_clock_to_seconds_remaining(time_remaining)
    if rem is None:
        return None
    plen = 12 * 60 if int(period) <= 4 else 5 * 60
    prior = sum((12 * 60 if p <= 4 else 5 * 60) for p in range(1, int(period)))
    return round(prior + (plen - rem), 1)


def nba_clock_to_seconds_remaining(clock: Any) -> Optional[float]:
    if not clock:
        return None
    m = re.search(r"PT(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?", str(clock))
    if not m:
        return None
    return float(m.group(1) or 0) * 60 + float(m.group(2) or 0)


def elapsed_from_nba_clock(period: int, clock: Any) -> Optional[float]:
    rem = nba_clock_to_seconds_remaining(clock)
    if rem is None:
        return None
    plen = 720 if int(period) <= 4 else 300
    prior = sum((720 if p <= 4 else 300) for p in range(1, int(period)))
    return round(prior + (plen - rem), 1)


def period_length_seconds(period: int) -> float:
    return 720.0 if int(period) <= 4 else 300.0


def elapsed_from_period_seconds_remaining(period: int, seconds_remaining: Any) -> Optional[float]:
    sec = _float_or_none(seconds_remaining)
    if sec is None:
        return None
    plen = period_length_seconds(int(period))
    prior = sum((720.0 if p <= 4 else 300.0) for p in range(1, int(period)))
    return round(prior + max(0.0, plen - sec), 1)


def seconds_remaining_in_period(period: Any, clock: Any = None, game_elapsed_seconds: Any = None) -> Optional[float]:
    rem = bbref_clock_to_seconds_remaining(clock)
    if rem is not None:
        return rem
    p = _int_or_none(period)
    elapsed = _float_or_none(game_elapsed_seconds)
    if p is None or elapsed is None:
        return None
    prior = sum((720.0 if q <= 4 else 300.0) for q in range(1, p))
    within = max(0.0, elapsed - prior)
    return max(0.0, period_length_seconds(p) - within)


def maybe_int(x: Any) -> Optional[int]:
    try:
        if pd.isna(x):
            return None
    except Exception:
        pass
    try:
        if x is None or x == "":
            return None
        return int(x)
    except Exception:
        return None


def is_true(x: Any) -> bool:
    """Boolean parser that is safe after CSV round-trips.

    Pandas usually preserves True/False columns, but mixed missing values can turn
    them into object/string columns.  bool("False") is True, which silently
    corrupts event-type logic, touch chains, and NBA alignment filters.
    """
    if x is None:
        return False
    try:
        if pd.isna(x):
            return False
    except Exception:
        pass
    if isinstance(x, str):
        return x.strip().lower() in {"1", "true", "t", "yes", "y"}
    return bool(x)


def clean_team_code(x: Any) -> Optional[str]:
    if x is None:
        return None
    try:
        if pd.isna(x):
            return None
    except Exception:
        pass
    txt = str(x).strip().upper()
    return txt or None


def nonempty_id(x: Any) -> bool:
    if x is None:
        return False
    try:
        if pd.isna(x):
            return False
    except Exception:
        pass
    return str(x).strip() not in {"", "nan", "None", "NONE", "NaN"}


BOOL_EVENT_COLS = [
    "is_playoff", "is_scoring", "is_shot", "shot_made", "is_ft", "ft_made",
    "is_tech_ft", "is_rebound", "is_off_rebound", "is_def_rebound",
    "is_turnover", "is_steal", "is_block", "is_foul", "is_timeout",
    "is_sub", "is_jumpball", "is_live_ball_tov", "is_dead_ball",
]


def to_jsonable_records(df: pd.DataFrame) -> List[Dict[str, Any]]:
    if df is None or df.empty:
        return []
    out = df.where(pd.notna(df), None).to_dict(orient="records")
    return out


# =============================================================================
# Advanced event-context feature extraction
# =============================================================================

NO_STEAL = "No_Steal"
NO_REBOUND = "No_Rebound"
NO_CUT = "No_Cut_Detected"
NO_MISS = "No_Miss_Or_Shot_Made"
NO_CONTEST = "Unspecified_Contest"
NO_OFF_BALL_SCREEN = "No_Off_Ball_Screen_Noted"
NO_SWITCH = "No_Switch_Detected"
NO_PLAYBOOK = "None_Executed"


def _safe_lower(x: Any) -> str:
    if x is None:
        return ""
    try:
        if pd.isna(x):
            return ""
    except Exception:
        pass
    return clean_text(x).lower()


def _event_text_bundle(act: Any, matched_text: str = "") -> str:
    """Combine all available human-readable event text without assuming a schema."""
    parts: List[str] = []
    for key in ["event_text", "description", "nba_description_aligned", "descriptor", "sub_type", "shot_zone_bbref"]:
        try:
            val = act.get(key) if hasattr(act, "get") else None
        except Exception:
            val = None
        if val is not None:
            parts.append(str(val))
    if matched_text:
        parts.append(str(matched_text))
    return clean_text(" ".join(parts)).lower()


def _action_type_bundle(act: Any) -> str:
    parts = []
    for key in ["actionType", "action_type", "subType", "sub_type", "descriptor"]:
        try:
            val = act.get(key) if hasattr(act, "get") else None
        except Exception:
            val = None
        if val is not None:
            parts.append(str(val))
    return clean_text(" ".join(parts)).lower()


def _contains_any(text: str, phrases: Iterable[str]) -> bool:
    return any(p in text for p in phrases)


def _regex_any(text: str, patterns: Iterable[str]) -> bool:
    return any(re.search(p, text) for p in patterns)


def extract_granular_action_sub_types(act: Any, matched_text: str = "") -> Dict[str, str]:
    """Classify mechanical sub-types from PBP/commentary text.

    These are deliberately treated as text-derived evidence, not ground truth.
    The caller should use the returned fields with confidence/source columns.
    """
    text = _event_text_bundle(act, matched_text)
    action_type = _action_type_bundle(act)

    steal_type = NO_STEAL
    rebound_type = NO_REBOUND
    cut_type = NO_CUT
    miss_type = NO_MISS
    contest_type = NO_CONTEST

    is_steal_event = is_true(act.get("is_steal")) if hasattr(act, "get") else False
    is_rebound_event = is_true(act.get("is_rebound")) if hasattr(act, "get") else False
    is_shot_event = is_true(act.get("is_shot")) if hasattr(act, "get") else False
    shot_made = is_true(act.get("shot_made")) if hasattr(act, "get") else False

    if is_steal_event or "steal" in action_type or _regex_any(text, [r"\bst(?:eal|ole|olen)\b", r"\bpick(?:ed)?(?:s)? (?:his|the)? ?pocket\b"]):
        if _contains_any(text, ["picked his pocket", "picks his pocket", "rip away", "rips it away", "ripped away", "stripped", "strip", "knocks it loose"]):
            steal_type = "Dribble_Strip_Pickpocket"
        elif _contains_any(text, ["intercepts", "intercepted", "jumped the lane", "jumps the lane", "passing lane", "read that pass", "bad pass stolen"]):
            steal_type = "Passing_Lane_Interception"
        elif _contains_any(text, ["pokes it away from behind", "poked it away from behind", "from behind", "blind side", "blindside"]):
            steal_type = "Blind_Side_Poke"
        elif _contains_any(text, ["trap", "trapped", "corner trap", "baseline trap", "double team forces", "forced by the double"]):
            steal_type = "Trapped_Boundary_Force"
        elif _contains_any(text, ["deflect", "deflection", "tips the pass", "tipped pass", "taps it away"]):
            steal_type = "Deflection_Created_Steal"
        else:
            steal_type = "Standard_Defensive_Steal"

    if is_rebound_event or "rebound" in action_type or "rebound" in text or "board" in text:
        if _contains_any(text, ["box out", "boxed out", "boxes out", "seals his man", "seal his man", "wedges"]):
            rebound_type = "Box_Out_Clearance"
        elif _contains_any(text, ["over the top", "skies over", "sky over", "climbs the ladder", "outjump", "high-points"]):
            rebound_type = "Over_The_Top_Snatch"
        elif _contains_any(text, ["tip out", "tipped it out", "tips it out", "taps it back", "volleyballs it", "keeps it alive"]):
            rebound_type = "Intentional_Tip_Out"
        elif _contains_any(text, ["long bounce", "long rebound", "caroms out", "bounces out", "out to the perimeter", "above the break rebound"]):
            rebound_type = "Long_Bounce_Perimeter_Board"
        elif _contains_any(text, ["in traffic", "traffic", "crowd", "crowded", "surrounded", "among the trees", "bodies around"]):
            rebound_type = "Heavy_Traffic_Crowd_Board"
        else:
            rebound_type = "Standard_Rebound_Unspecified"

    if _regex_any(text, [r"\bcut(?:s|ting)?\b", r"\bslash(?:es|ing)?\b", r"\bdive(?:s|ing)?\b", r"\bdrift(?:s|ing)?\b"]):
        if _contains_any(text, ["backdoor", "back-door", "behind the defense", "door cut"]):
            cut_type = "Backdoor_Baseline_Cut"
        elif _contains_any(text, ["45 cut", "45-cut", "forty five cut", "diagonal", "through the slot", "slot cut"]):
            cut_type = "Slot_Diagonal_45_Cut"
        elif _contains_any(text, ["iverson cut", "across the floor", "across the top"]):
            cut_type = "Horizontal_Iverson_Cut"
        elif _contains_any(text, ["flash", "high post", "to the free throw", "flashes middle", "flashes to the nail"]):
            cut_type = "High_Post_Flash_Cut"
        elif _contains_any(text, ["baseline drift", "drifts baseline", "slides to the corner", "drifts to the corner"]):
            cut_type = "Baseline_Drift_Cut"
        else:
            cut_type = "Generic_Off_Ball_Cut"

    miss_event = (is_shot_event and not shot_made) or "miss" in action_type or _regex_any(text, [r"\bmiss(?:es|ed)?\b", r"\bno good\b"])
    if miss_event:
        if _contains_any(text, ["airball", "air ball", "touches nothing", "missed everything", "completely missed everything"]):
            miss_type = "Airball_Complete_Miss"
        elif _contains_any(text, ["rattles out", "in and out", "in-and-out", "rims out", "rimmed out", "lip of the rim", "spins out"]):
            miss_type = "In_And_Out_Rim_Rattler"
        elif _contains_any(text, ["back iron", "missed long", "long off the rim", "hard off the back", "back rim"]):
            miss_type = "Back_Iron_Long_Clank"
        elif _contains_any(text, ["front iron", "front rim", "short", "hit the front", "short off the rim"]):
            miss_type = "Front_Rim_Short_Miss"
        elif is_true(act.get("is_block")) if hasattr(act, "get") else False:
            miss_type = "Blocked_Altered_Miss"
        elif _contains_any(text, ["blocked", "swatted", "rejected", "altered", "bothered", "changed the shot"]):
            miss_type = "Blocked_Altered_Miss"
        else:
            miss_type = "Standard_Geometric_Miss"

    if _contains_any(text, ["contest", "contests", "challenges", "hand in his face", "defended by", "closeout", "close out", "body him"]):
        if _contains_any(text, ["flew past", "flies by", "fly-by", "fly by", "bit on the pump fake", "runs past"]):
            contest_type = "Aggressive_Fly_By_Closeout"
        elif _contains_any(text, ["verticality", "straight up", "absorbs the body", "wall up", "walls up"]):
            contest_type = "Rim_Protection_Verticality_Wall"
        elif _contains_any(text, ["smothering", "smothered", "lockdown", "right in his pocket", "chest to chest", "attached"]):
            contest_type = "Tight_Stayed_Ground_Contest"
        elif _contains_any(text, ["late recovery", "scrambling", "closes out late", "late closeout", "late contest"]):
            contest_type = "Late_Recovery_Hand_Up"
        elif _contains_any(text, ["under him", "landing space", "flagrant", "zaza", "reckless closeout"]):
            contest_type = "Dangerous_Landing_Space_Violation"
        else:
            contest_type = "Generic_Contest_Pressure"

    return {
        "steal_type": steal_type,
        "rebound_type": rebound_type,
        "cut_type": cut_type,
        "miss_type": miss_type,
        "contest_type": contest_type,
    }


def extract_off_ball_screen_variations(act: Any, matched_text: str = "") -> str:
    """Detect off-ball screen families from natural-language evidence.

    The generic "pick" cue is intentionally not enough by itself; otherwise ball
    screens and normal PNR notes would be mislabeled as off-ball actions.
    """
    text = _event_text_bundle(act, matched_text)
    if not _contains_any(text, [
        "screen", "screens", "screened", "curls off", "comes off",
        "off ball", "away from the ball", "away from the play",
        # Elevator sets are often described as doors/gates closing without the word "screen".
        "elevator", "elevator doors", "elevator gates", "gates close", "doors close", "doors shut",
    ]):
        return NO_OFF_BALL_SCREEN

    if _contains_any(text, ["pin down", "pindown", "pin-down", "down screen", "down-screen", "curls up", "curling up"]):
        return "Pin_Down_Down_Screen"
    if _contains_any(text, ["flare screen", "flare-screen", "fades to the wing", "flares out", "flare action", "flares to the corner"]):
        return "Perimeter_Flare_Screen"
    if _contains_any(text, ["back screen", "back-screen", "ucla cut", "blind screen", "screen on the back"]):
        return "Rim_Cut_Back_Screen"
    if _contains_any(text, ["staggered", "double screen", "consecutive screens", "two screens", "stagger screen"]):
        return "Staggered_Double_Screen"
    if _contains_any(text, ["screen the screener", "screen-the-screener", "sts action", "screens the screener"]):
        return "Screen_The_Screener_STS"
    if _contains_any(text, ["elevator screen", "elevator gates", "elevator doors"]):
        return "Elevator_Gates_Screen"
    if _contains_any(text, ["off ball screen", "off-ball screen", "away from the play", "away from the ball", "baseline screen", "cross screen"]):
        return "Generic_Off_Ball_Screen"
    return NO_OFF_BALL_SCREEN


def _semantic_subtype_confidence(features: Dict[str, str], text: str) -> float:
    hit_cols = [
        ("steal_type", NO_STEAL), ("rebound_type", NO_REBOUND), ("cut_type", NO_CUT),
        ("miss_type", NO_MISS), ("contest_type", NO_CONTEST), ("off_ball_screen", NO_OFF_BALL_SCREEN),
    ]
    hits = [features.get(k) for k, default in hit_cols if features.get(k) and features.get(k) != default]
    if not hits:
        return 0.0
    generic_hits = [h for h in hits if "Generic" in h or "Standard" in h or "Unspecified" in h]
    base = 0.58 if len(generic_hits) == len(hits) else 0.72
    if len(text) >= 90:
        base += 0.05
    return round(min(0.90, base + 0.03 * (len(hits) - 1)), 4)


def _float_or_none(x: Any) -> Optional[float]:
    try:
        if x is None or pd.isna(x):
            return None
    except Exception:
        pass
    try:
        return float(x)
    except Exception:
        return None


def _int_or_none(x: Any) -> Optional[int]:
    try:
        if x is None or pd.isna(x):
            return None
    except Exception:
        pass
    try:
        return int(float(x))
    except Exception:
        return None


def _shotchart_by_action_number(shotchart: Optional[pd.DataFrame]) -> Dict[int, Dict[str, Any]]:
    if shotchart is None or shotchart.empty or "GAME_EVENT_ID" not in shotchart.columns:
        return {}
    out: Dict[int, Dict[str, Any]] = {}
    for _, r in shotchart.iterrows():
        action_no = _int_or_none(r.get("GAME_EVENT_ID"))
        if action_no is None:
            continue
        out[action_no] = {
            "x": _float_or_none(r.get("LOC_X")),
            "y": _float_or_none(r.get("LOC_Y")),
            "zone": r.get("SHOT_ZONE_BASIC") or r.get("SHOT_ZONE_AREA") or r.get("SHOT_ZONE_RANGE"),
            "distance_ft": _float_or_none(r.get("SHOT_DISTANCE")),
            "source": "nba_shotchartdetail",
            "confidence": 0.95,
        }
    return out


def _nba_pbp_by_action_number(nba_pbp: Optional[pd.DataFrame]) -> Dict[int, Dict[str, Any]]:
    if nba_pbp is None or nba_pbp.empty or "nba_action_number" not in nba_pbp.columns:
        return {}
    out: Dict[int, Dict[str, Any]] = {}
    for _, r in nba_pbp.iterrows():
        action_no = _int_or_none(r.get("nba_action_number"))
        if action_no is None:
            continue
        x = _float_or_none(r.get("x_legacy"))
        y = _float_or_none(r.get("y_legacy"))
        if x is None:
            x = _float_or_none(r.get("x"))
        if y is None:
            y = _float_or_none(r.get("y"))
        out[action_no] = {
            "x": x,
            "y": y,
            "zone": None,
            "distance_ft": _float_or_none(r.get("shot_distance")),
            "source": "nba_playbyplayv3_xy" if x is not None and y is not None else "nba_playbyplayv3_no_xy",
            "confidence": 0.82 if x is not None and y is not None else 0.0,
        }
    return out


def _coarse_zone_from_event_text(act: Any, text: str) -> Dict[str, Any]:
    """Return conservative location hints when exact tracking/shotchart coords are absent."""
    shot_dist = _float_or_none(act.get("shot_dist_bbref")) if hasattr(act, "get") else None
    shot_zone = act.get("shot_zone_bbref") if hasattr(act, "get") else None

    if shot_zone and str(shot_zone).strip() not in {"", "nan", "None"}:
        return {"x": None, "y": None, "zone": str(shot_zone), "distance_ft": shot_dist, "source": "bbref_shot_zone", "confidence": 0.55}
    if _contains_any(text, ["dunk", "layup", "tip shot", "at rim", "at the rim", "restricted area"]):
        # Zone-only text anchor. Do not emit fabricated (0,0) into the same
        # coordinate fields used by real shotchart/PBP x/y or kinematics.
        return {"x": None, "y": None, "zone": "Restricted_Area_Text_Anchor", "distance_ft": shot_dist or 0.0, "source": "text_anchor_restricted_area_zone_only", "confidence": 0.50}
    if _contains_any(text, ["free throw", "free throw line"]):
        # Zone-only text anchor. The free-throw line is useful context, not a
        # measured actor coordinate.
        return {"x": None, "y": None, "zone": "Free_Throw_Line_Text_Anchor", "distance_ft": 15.0, "source": "text_anchor_free_throw_line_zone_only", "confidence": 0.48}
    if shot_dist is not None:
        return {"x": None, "y": None, "zone": "Distance_Only_Shot_Context", "distance_ft": shot_dist, "source": "bbref_shot_distance_only", "confidence": 0.45}
    if _contains_any(text, ["corner three", "from the corner", "corner 3"]):
        return {"x": None, "y": None, "zone": "Corner_Three_Text_Anchor", "distance_ft": shot_dist, "source": "text_anchor_corner_three", "confidence": 0.46}
    return {"x": None, "y": None, "zone": None, "distance_ft": shot_dist, "source": "none", "confidence": 0.0}




def spatial_supports_kinematics(spatial: Optional[Dict[str, Any]]) -> bool:
    """Only measured coordinate sources may feed velocity / spatial validation.

    Text anchors and BBRef zone labels can be useful basketball context, but they
    are not actor coordinates. Keeping this guard explicit prevents zone hints
    from becoming fake movement or fake playbook validation.
    """
    if not spatial:
        return False
    source = str(spatial.get("source") or "")
    if source not in REAL_COORDINATE_SOURCES:
        return False
    if _float_or_none(spatial.get("x")) is None or _float_or_none(spatial.get("y")) is None:
        return False
    return (_float_or_none(spatial.get("confidence")) or 0.0) >= 0.80

def infer_switching_networks_and_playbooks(act: Any, inferred_coords: Optional[Dict[str, Any]] = None, matched_text: str = "") -> Dict[str, Any]:
    """Detect switch-network and playbook cues with explicit confidence.

    This is an NLP-plus-optional-location heuristic. It does not claim optical
    tracking truth; spatial agreement only nudges confidence when reliable coords
    exist.
    """
    text = _event_text_bundle(act, matched_text)
    switch_state = NO_SWITCH
    playbook_preset = NO_PLAYBOOK
    confidence = 0.0

    if _contains_any(text, ["switch", "switched out", "rotation", "rotate", "scramble", "x-out", "miscommunication"]):
        if _contains_any(text, ["blew the switch", "blown switch", "miscommunication", "lost him", "nobody picked him up", "wide open because"]):
            switch_state = "Blown_Switch_Defensive_Error"
            confidence = max(confidence, 0.78)
        elif _contains_any(text, ["late rotation", "late rotate", "scrambling to get out", "x-out", "scramble mode"]):
            switch_state = "Late_Defensive_Rotation"
            confidence = max(confidence, 0.70)
        elif "switch" in text:
            switch_state = "Clean_Pick_And_Roll_Switch"
            confidence = max(confidence, 0.60)

    if _contains_any(text, ["horns", "two bigs at the elbows", "both elbows"]):
        playbook_preset = "Horns_Elbow_Set"
        confidence = max(confidence, 0.78)
    elif _contains_any(text, ["spain pick-and-roll", "spain pick and roll", "spain pnr", "spain action", "back screen on the ball", "backscreen the roller", "back screen on the roller"]):
        playbook_preset = "Spain_Pick_And_Roll"
        confidence = max(confidence, 0.84)
    elif _contains_any(text, ["pistol", "21 action", "twenty one", "twenty-one"]):
        playbook_preset = "Pistol_Early_Offense"
        confidence = max(confidence, 0.78)
    elif "iverson" in text:
        playbook_preset = "Iverson_Cut_Entry"
        confidence = max(confidence, 0.75)
    elif _contains_any(text, ["elevator screen", "elevator gates", "elevator doors"]):
        playbook_preset = "Elevator_Gates_Set"
        confidence = max(confidence, 0.83)
    elif _contains_any(text, ["zoom action", "pin down into a handoff", "pindown into a handoff"]):
        playbook_preset = "Zoom_Action"
        confidence = max(confidence, 0.76)
    elif _contains_any(text, ["hammer", "hammer screen", "weakside hammer"]):
        playbook_preset = "Hammer_Weakside_Action"
        confidence = max(confidence, 0.76)

    # Optional spatial sanity check. Only use it when an upstream source produced
    # actual or anchored coordinates; no coordinates means no boost.
    coords = inferred_coords or {}
    x = _float_or_none(coords.get("x"))
    y = _float_or_none(coords.get("y"))
    spatial_conf = _float_or_none(coords.get("confidence")) or 0.0
    if playbook_preset == "Spain_Pick_And_Roll" and spatial_supports_kinematics(coords):
        if abs(x) <= 80.0 and -20.0 <= y <= 220.0:
            confidence = min(0.95, confidence + 0.07)
        else:
            confidence = max(0.20, confidence - 0.12)

    return {"switch_state": switch_state, "playbook_preset": playbook_preset, "confidence": round(confidence, 4)}


def add_advanced_event_features(
    events: pd.DataFrame,
    nba_pbp: Optional[pd.DataFrame] = None,
    shotchart: Optional[pd.DataFrame] = None,
) -> pd.DataFrame:
    """Append text-derived tactical subtypes and conservative spatial context."""
    if events is None or events.empty:
        return events

    out = events.copy()
    sc_by_action = _shotchart_by_action_number(shotchart)
    nba_by_action = _nba_pbp_by_action_number(nba_pbp)

    feature_rows: List[Dict[str, Any]] = []
    prev_loc_by_actor: Dict[str, Dict[str, Any]] = {}

    for _, e in out.iterrows():
        text = _event_text_bundle(e)
        granular = extract_granular_action_sub_types(e)
        screen = extract_off_ball_screen_variations(e)
        semantic_features = {**granular, "off_ball_screen": screen}
        subtype_conf = _semantic_subtype_confidence(semantic_features, text)

        action_no = _int_or_none(e.get("nba_action_number"))
        spatial = sc_by_action.get(action_no) if action_no is not None else None
        if not spatial and action_no is not None:
            maybe_nba = nba_by_action.get(action_no)
            if maybe_nba and maybe_nba.get("confidence", 0.0) > 0:
                spatial = maybe_nba
        if not spatial:
            spatial = _coarse_zone_from_event_text(e, text)

        actor_key = str(e.get("player_id_bbref") or e.get("player") or "").strip()
        elapsed = _float_or_none(e.get("game_elapsed_seconds"))
        period = _int_or_none(e.get("period"))
        x = _float_or_none(spatial.get("x"))
        y = _float_or_none(spatial.get("y"))
        pos_key = str(e.get("true_possession_id") or e.get("possession_id") or "").strip()
        reliable_xy = spatial_supports_kinematics(spatial)
        velocity_fps = None
        if actor_key and reliable_xy and elapsed is not None and period is not None:
            prev = prev_loc_by_actor.get(actor_key)
            if (
                prev
                and prev.get("period") == period
                and prev.get("pos_key") == pos_key
                and prev.get("elapsed") is not None
            ):
                dt = float(elapsed) - float(prev["elapsed"])
                # Event logs are sparse. Treat velocity as a same-possession short-hop
                # diagnostic, not a continuous tracking feed.
                if 0 < dt <= 14.0:
                    dist_ft = math.sqrt((x - float(prev["x"])) ** 2 + (y - float(prev["y"])) ** 2) / 12.0
                    velocity_fps = round(dist_ft / dt, 4)
            prev_loc_by_actor[actor_key] = {
                "x": x, "y": y, "elapsed": elapsed, "period": period,
                "pos_key": pos_key, "source": spatial.get("source"),
            }

        tactical = infer_switching_networks_and_playbooks(e, inferred_coords=spatial)
        tracking_conf = max(_float_or_none(spatial.get("confidence")) or 0.0, tactical["confidence"])
        if subtype_conf:
            tracking_conf = max(tracking_conf, subtype_conf)

        row_prov = normalize_nba_provenance(e.get("nba_enrichment_provenance"))
        if row_prov == "missing":
            row_prov = normalize_nba_provenance(e.get("win_probability_data_provenance"))
        if row_prov == "missing":
            row_prov = normalize_nba_provenance(spatial.get("source"))
        if row_prov == "missing":
            row_prov = "bbref_only"

        feature_rows.append({
            "event_data_provenance": row_prov,
            "extracted_steal_type": granular["steal_type"],
            "extracted_rebound_type": granular["rebound_type"],
            "extracted_cut_type": granular["cut_type"],
            "extracted_miss_type": granular["miss_type"],
            "extracted_contest_type": granular["contest_type"],
            "extracted_off_ball_screen": screen,
            "semantic_subtype_confidence": subtype_conf,
            "inferred_actor_x": x,
            "inferred_actor_y": y,
            "inferred_floor_zone": spatial.get("zone"),
            "estimated_shot_distance_ft": spatial.get("distance_ft"),
            "kinematic_velocity_fps": velocity_fps,
            "spatial_inference_source": spatial.get("source"),
            "spatial_inference_confidence": round(float(spatial.get("confidence") or 0.0), 4),
            "tactical_switch_network_state": tactical["switch_state"],
            "playbook_preset_detected": tactical["playbook_preset"],
            "tracking_inference_confidence": round(float(tracking_conf or 0.0), 4),
            "event_semantic_version": SEMANTIC_FEATURE_VERSION,
        })

    feats = pd.DataFrame(feature_rows, index=out.index)
    return pd.concat([out, feats], axis=1)


def build_event_advanced_context(events: pd.DataFrame) -> pd.DataFrame:
    if events is None or events.empty:
        return pd.DataFrame()
    keep = [
        "bbref_game_id", "event_id", "event_index", "true_possession_id", "period", "clock",
        "game_elapsed_seconds", "event_team", "player", "player_id_bbref", "event_text",
        "event_data_provenance", "nba_game_id", "nba_action_number", "nba_alignment_confidence", "nba_description_aligned",
        "home_win_probability", "away_win_probability", "official_leverage_index_score",
        "custom_leverage_index_score", "flag_is_low_leverage_garbage_time",
        "win_probability_available", "win_probability_source", "win_probability_confidence",
        "win_probability_data_provenance", "nba_enrichment_provenance",
        "win_probability_event_num", "win_probability_alignment_method",
        "win_probability_seconds_delta", "leverage_model_version",
        "extracted_steal_type", "extracted_rebound_type", "extracted_cut_type",
        "extracted_miss_type", "extracted_contest_type", "extracted_off_ball_screen",
        "semantic_subtype_confidence", "inferred_actor_x", "inferred_actor_y",
        "inferred_floor_zone", "estimated_shot_distance_ft", "kinematic_velocity_fps",
        "spatial_inference_source", "spatial_inference_confidence",
        "tactical_switch_network_state", "playbook_preset_detected",
        "tracking_inference_confidence", "event_semantic_version",
    ]
    return events[[c for c in keep if c in events.columns]].copy()



# =============================================================================
# Configure and run Jack's BBRef scraper for only 2025-26
# =============================================================================

def configure_bbref_module(data_dir: str | Path, delay: float = 3.5, jitter: float = 1.5, save_html: bool = True) -> None:
    data_dir = Path(data_dir)
    bbref.SEASONS = [2026]
    bbref.DELAY = delay
    bbref.JITTER = jitter
    bbref.SAVE_HTML = save_html
    bbref.DATA_DIR = data_dir
    bbref.RAW_DIR = data_dir / "raw_pbp"
    bbref.POSS_DIR = data_dir / "possessions"
    bbref.SCHED_DIR = data_dir / "schedule"
    bbref.HTML_DIR = data_dir / "html"
    bbref.PLAYERS_MASTER = data_dir / "players_master.csv"
    bbref.QC_MANIFEST = data_dir / "qc_manifest.csv"
    bbref.FAILURES = data_dir / "failures.csv"
    for d in [bbref.RAW_DIR, bbref.POSS_DIR, bbref.SCHED_DIR, bbref.HTML_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def scrape_bbref_2025_26(
    data_dir: str | Path,
    game: Optional[str] = None,
    limit: Optional[int] = None,
    delay: float = 3.5,
    jitter: float = 1.5,
    save_html: bool = True,
) -> Dict[str, Any]:
    configure_bbref_module(data_dir, delay=delay, jitter=jitter, save_html=save_html)
    schedule = bbref.season_game_ids(2026)

    if game:
        ok = bbref.scrape_game(game, schedule.get(game, False))
        return {"mode": "single_game", "game": game, "ok": bool(ok), "scheduled_games": len(schedule)}

    total = success = skip = fail = 0
    for gid, is_po in sorted(schedule.items()):
        if limit is not None and total >= limit:
            break
        raw = bbref.RAW_DIR / f"{gid}.csv"
        luf = bbref.POSS_DIR / f"{gid}_lineups.csv"
        tpf = bbref.POSS_DIR / f"{gid}_tp.csv"
        if raw.exists() and luf.exists() and tpf.exists():
            skip += 1
            continue
        ok = bbref.scrape_game(gid, is_po)
        total += 1
        success += int(ok)
        fail += int(not ok)
        if total % 25 == 0:
            print(f"BBRef scrape progress: {success} ok / {fail} fail / {skip} skip")

    return {"mode": "season_2026", "scheduled_games": len(schedule), "attempted": total, "success": success, "fail": fail, "skip": skip}


# =============================================================================
# Load BBRef authority outputs
# =============================================================================

def bbref_paths(data_dir: str | Path, game_id: str) -> Dict[str, Path]:
    data_dir = Path(data_dir)
    return {
        "raw_pbp": data_dir / "raw_pbp" / f"{game_id}.csv",
        "true_possessions": data_dir / "possessions" / f"{game_id}_tp.csv",
        "lineups": data_dir / "possessions" / f"{game_id}_lineups.csv",
        "meta": data_dir / "possessions" / f"{game_id}_meta.json",
    }


def available_bbref_games(data_dir: str | Path) -> List[str]:
    raw_dir = Path(data_dir) / "raw_pbp"
    if not raw_dir.exists():
        return []
    return sorted(p.stem for p in raw_dir.glob("*.csv"))


def load_bbref_game(data_dir: str | Path, game_id: str) -> Dict[str, Any]:
    paths = bbref_paths(data_dir, game_id)
    raw = read_table(paths["raw_pbp"])
    tp = read_table(paths["true_possessions"])
    lineups = read_table(paths["lineups"])
    meta = {}
    if paths["meta"].exists():
        try:
            meta = json.loads(paths["meta"].read_text(encoding="utf-8"))
        except Exception:
            meta = {}
    return {"raw_pbp": raw, "true_possessions": tp, "lineups": lineups, "meta": meta, "paths": paths}


# =============================================================================
# Normalize BBRef into master tables
# =============================================================================

def normalize_clean_game_events(raw: pd.DataFrame) -> pd.DataFrame:
    if raw.empty:
        return pd.DataFrame()
    df = raw.copy()
    if "elapsed" not in df.columns:
        df["elapsed"] = df.apply(lambda r: elapsed_from_bbref_clock(int(r["period"]), r["time_remaining"]), axis=1)
    df["event_index"] = range(len(df))
    df["bbref_event_id"] = df.apply(lambda r: f"{r['game_id']}_E{int(r['event_index']):04d}", axis=1)
    out = pd.DataFrame({
        "bbref_game_id": df["game_id"],
        "season": df.get("season"),
        "date": df.get("date"),
        "is_playoff": df.get("is_playoff"),
        "event_index": df["event_index"],
        "event_id": df["bbref_event_id"],
        "period": df.get("period"),
        "clock": df.get("time_remaining"),
        "game_elapsed_seconds": df.get("elapsed"),
        "away_team": df.get("away_team"),
        "home_team": df.get("home_team"),
        "event_side": df.get("side"),
        "event_team": df.get("team"),
        "player": df.get("player"),
        "player_id_bbref": df.get("player_id"),
        "player2": df.get("player2"),
        "player2_id_bbref": df.get("player2_id"),
        "assist_id_bbref": df.get("assist_id"),
        "block_id_bbref": df.get("block_id"),
        "steal_id_bbref": df.get("steal_id"),
        "event_text": df.get("event_text"),
        "points": df.get("points"),
        "shot_zone_bbref": df.get("shot_zone"),
        "shot_dist_bbref": df.get("shot_dist"),
        "away_score": df.get("away_score"),
        "home_score": df.get("home_score"),
        "is_scoring": df.get("is_scoring"),
        "is_shot": df.get("is_shot"),
        "shot_made": df.get("shot_made"),
        "is_ft": df.get("is_ft"),
        "ft_made": df.get("ft_made"),
        "ft_num": df.get("ft_num"),
        "ft_of": df.get("ft_of"),
        "is_tech_ft": df.get("is_tech_ft"),
        "is_rebound": df.get("is_rebound"),
        "is_off_rebound": df.get("is_off_rebound"),
        "is_def_rebound": df.get("is_def_rebound"),
        "is_turnover": df.get("is_turnover"),
        "is_steal": df.get("is_steal"),
        "is_block": df.get("is_block"),
        "is_foul": df.get("is_foul"),
        "is_timeout": df.get("is_timeout"),
        "is_sub": df.get("is_sub"),
        "is_jumpball": df.get("is_jumpball"),
        "is_live_ball_tov": df.get("is_live_ball_tov"),
        "is_dead_ball": df.get("is_dead_ball"),
        "source": "bbref_pbp_scraper_v2",
    })
    for col in BOOL_EVENT_COLS:
        if col in out.columns:
            out[col] = out[col].map(is_true)
    for col in ["period", "event_index", "points", "ft_num", "ft_of", "away_score", "home_score"]:
        if col in out.columns:
            out[col] = pd.to_numeric(out[col], errors="coerce")
    if "game_elapsed_seconds" in out.columns:
        out["game_elapsed_seconds"] = pd.to_numeric(out["game_elapsed_seconds"], errors="coerce")
    return out


def normalize_possession_frames(tp: pd.DataFrame, raw: pd.DataFrame) -> pd.DataFrame:
    if tp.empty:
        return pd.DataFrame()
    out = tp.copy()
    if not raw.empty:
        game_id = raw["game_id"].iloc[0]
        away_team = raw["away_team"].iloc[0]
        home_team = raw["home_team"].iloc[0]
    else:
        game_id = out["game_id"].iloc[0]
        away_team = home_team = None

    out = out.rename(columns={
        "true_possession_id": "possession_id",
        "tp_start_time": "start_clock",
        "tp_end_time": "end_clock",
        "true_possession_points": "points_scored",
        "dead_ball_end_type": "end_type",
    })
    out["bbref_game_id"] = out.get("game_id", game_id)
    out["season"] = raw["season"].iloc[0] if not raw.empty and "season" in raw.columns else None
    out["start_elapsed"] = out.apply(lambda r: elapsed_from_bbref_clock(int(r["period"]), r.get("start_clock")), axis=1)
    out["end_elapsed"] = out.apply(lambda r: elapsed_from_bbref_clock(int(r["period"]), r.get("end_clock")), axis=1)
    out["duration_seconds"] = out.apply(lambda r: None if pd.isna(r.get("start_elapsed")) or pd.isna(r.get("end_elapsed")) else round(float(r["end_elapsed"]) - float(r["start_elapsed"]), 1), axis=1)
    out["away_team"] = away_team
    out["home_team"] = home_team
    out["source"] = "bbref_true_possessions_ft_aware"
    keep = [
        "bbref_game_id", "season", "possession_id", "period", "offense_team", "defense_team",
        "start_clock", "end_clock", "start_elapsed", "end_elapsed", "duration_seconds",
        "points_scored", "standard_possessions_inside", "advantage_count", "end_type",
        "away_team", "home_team", "source"
    ]
    return out[[c for c in keep if c in out.columns]]


def _stint_player_match_score(stint: pd.Series, event: Optional[pd.Series] = None) -> int:
    if event is None:
        return 0
    ids = [event.get("player_id_bbref"), event.get("player2_id_bbref"), event.get("assist_id_bbref"), event.get("block_id_bbref"), event.get("steal_id_bbref")]
    ids = {str(x) for x in ids if nonempty_id(x)}
    if not ids:
        return 0
    away_ids = {str(stint.get(f"away_p{i}_id", "")) for i in range(1, 6) if nonempty_id(stint.get(f"away_p{i}_id", ""))}
    home_ids = {str(stint.get(f"home_p{i}_id", "")) for i in range(1, 6) if nonempty_id(stint.get(f"home_p{i}_id", ""))}
    side = str(event.get("event_side", "")).lower()
    score = len(ids & (away_ids | home_ids))
    if side == "away":
        score += 2 * len(ids & away_ids)
    elif side == "home":
        score += 2 * len(ids & home_ids)
    return int(score)


def stint_for_elapsed(lineups: pd.DataFrame, period: int, elapsed: float, event: Optional[pd.Series] = None) -> Optional[pd.Series]:
    if lineups.empty or elapsed is None or pd.isna(elapsed):
        return None
    sub = lineups[lineups["period"].astype(int) == int(period)].copy()
    if sub.empty:
        return None

    sub["_secs_on"] = pd.to_numeric(sub["secs_on"], errors="coerce")
    sub["_secs_off"] = pd.to_numeric(sub["secs_off"], errors="coerce")
    sub = sub.dropna(subset=["_secs_on", "_secs_off"]).copy()
    if sub.empty:
        return None

    t = float(elapsed)
    eps = 0.2
    last_off = float(sub["_secs_off"].max())

    # Primary rule: half-open stint windows [secs_on, secs_off).  This prevents
    # substitution-boundary events from being claimed by the lineup that just left.
    half_open = sub[(sub["_secs_on"] <= t) & (t < sub["_secs_off"])]

    # At the final recorded stint boundary of a period there is no next stint; keep
    # the last row eligible so end-of-period/game-end events are not orphaned.
    if half_open.empty and abs(t - last_off) <= eps:
        half_open = sub[(sub["_secs_off"] - eps <= t) & (t <= sub["_secs_off"] + eps)]

    if not half_open.empty:
        hit = half_open.copy()
        hit["_player_match"] = hit.apply(lambda r: _stint_player_match_score(r, event), axis=1)
        hit["_start_dist"] = (hit["_secs_on"] - t).abs()
        hit["_dur"] = pd.to_numeric(hit.get("duration", hit["_secs_off"] - hit["_secs_on"]), errors="coerce")
        return hit.sort_values(["_player_match", "_start_dist", "_dur"], ascending=[False, True, False]).iloc[0]

    # Boundary/tolerance fallback for noisy clocks: choose the compatible row, not
    # merely the shortest row.  This is deliberately second-priority behind the
    # half-open rule above.
    near = sub[(sub["_secs_on"] - eps <= t) & (t <= sub["_secs_off"] + eps)].copy()
    if not near.empty:
        near["_half_open"] = (near["_secs_on"] <= t) & (t < near["_secs_off"])
        near["_player_match"] = near.apply(lambda r: _stint_player_match_score(r, event), axis=1)
        near["_boundary_dist"] = near.apply(lambda r: min(abs(float(r["_secs_on"]) - t), abs(float(r["_secs_off"]) - t)), axis=1)
        return near.sort_values(["_half_open", "_player_match", "_boundary_dist", "_secs_on"], ascending=[False, False, True, False]).iloc[0]

    # Last resort: nearest stint start in the same period.
    sub["_dist"] = (sub["_secs_on"] - t).abs().clip(upper=99999)
    return sub.sort_values("_dist").iloc[0] if not sub.empty else None


def lineup_ids_from_stint(stint: pd.Series, side: str) -> List[str]:
    cols = [f"{side}_p{i}_id" for i in range(1, 6)]
    return [str(stint.get(c, "")) for c in cols if str(stint.get(c, "")) not in {"", "nan", "None"}]


def lineup_names_from_stint(stint: pd.Series, side: str) -> List[str]:
    cols = [f"{side}_p{i}" for i in range(1, 6)]
    return [str(stint.get(c, "")) for c in cols if str(stint.get(c, "")) not in {"", "nan", "None"}]


def build_event_lineups(events: pd.DataFrame, lineups: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    if events.empty or lineups.empty:
        return pd.DataFrame(rows)
    for _, e in events.iterrows():
        st = stint_for_elapsed(lineups, int(e["period"]), float(e["game_elapsed_seconds"]) if pd.notna(e["game_elapsed_seconds"]) else None, event=e)
        if st is None:
            rows.append({"bbref_game_id": e["bbref_game_id"], "event_id": e["event_id"], "lineup_source": "missing"})
            continue
        rows.append({
            "bbref_game_id": e["bbref_game_id"],
            "event_id": e["event_id"],
            "event_index": e["event_index"],
            "period": e["period"],
            "clock": e["clock"],
            "game_elapsed_seconds": e["game_elapsed_seconds"],
            "away_team": e["away_team"],
            "home_team": e["home_team"],
            "away_player_ids_bbref": json.dumps(lineup_ids_from_stint(st, "away")),
            "home_player_ids_bbref": json.dumps(lineup_ids_from_stint(st, "home")),
            "away_player_names": json.dumps(lineup_names_from_stint(st, "away")),
            "home_player_names": json.dumps(lineup_names_from_stint(st, "home")),
            "stint_time_on": st.get("time_on"),
            "stint_time_off": st.get("time_off"),
            "stint_secs_on": st.get("secs_on"),
            "stint_secs_off": st.get("secs_off"),
            "lineup_source": "bbref_stints",
        })
    return pd.DataFrame(rows)


def build_possession_lineups(possessions: pd.DataFrame, lineups: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    if possessions.empty or lineups.empty:
        return pd.DataFrame(rows)
    for _, p in possessions.iterrows():
        elapsed = p.get("start_elapsed")
        if pd.isna(elapsed):
            elapsed = p.get("end_elapsed")
        st = stint_for_elapsed(lineups, int(p["period"]), float(elapsed) if pd.notna(elapsed) else None)
        if st is None:
            rows.append({"bbref_game_id": p["bbref_game_id"], "possession_id": p["possession_id"], "lineup_source": "missing"})
            continue
        offense_side = "away" if p.get("offense_team") == p.get("away_team") else "home"
        defense_side = "home" if offense_side == "away" else "away"
        rows.append({
            "bbref_game_id": p["bbref_game_id"],
            "possession_id": p["possession_id"],
            "period": p["period"],
            "start_clock": p.get("start_clock"),
            "end_clock": p.get("end_clock"),
            "start_elapsed": p.get("start_elapsed"),
            "end_elapsed": p.get("end_elapsed"),
            "offense_team": p.get("offense_team"),
            "defense_team": p.get("defense_team"),
            "offense_side": offense_side,
            "defense_side": defense_side,
            "offense_player_ids_bbref": json.dumps(lineup_ids_from_stint(st, offense_side)),
            "defense_player_ids_bbref": json.dumps(lineup_ids_from_stint(st, defense_side)),
            "offense_player_names": json.dumps(lineup_names_from_stint(st, offense_side)),
            "defense_player_names": json.dumps(lineup_names_from_stint(st, defense_side)),
            "lineup_source": "bbref_stints",
        })
    return pd.DataFrame(rows)


def _possession_fallback_match(e: pd.Series, poss_period: pd.DataFrame, eps: float = 0.2) -> Tuple[Optional[Any], str]:
    if poss_period.empty or pd.isna(e.get("_event_elapsed")):
        return None, "missing_elapsed"
    t = float(e["_event_elapsed"])
    team = clean_team_code(e.get("event_team"))
    cand = poss_period[(poss_period["_start"] - eps <= t) & (t <= poss_period["_end"] + eps)].copy()
    if cand.empty:
        return None, "no_window"
    last_end = float(poss_period["_end"].max())
    cand["_half_open"] = (cand["_start"] <= t) & (t < cand["_end"])
    cand.loc[(abs(t - last_end) <= eps) & (cand["_end"] == last_end), "_half_open"] = True
    cand["_start_boundary"] = (cand["_start"] - t).abs() <= eps
    cand["_team_match"] = cand["offense_team"].map(clean_team_code).eq(team) if team else False
    cand["_boundary_dist"] = cand.apply(lambda r: min(abs(float(r["_start"]) - t), abs(float(r["_end"]) - t)), axis=1)
    # Half-open wins first; team match is a tie-break/fallback so a closing
    # possession cannot steal an exact end-boundary event from the new window.
    cand = cand.sort_values(["_half_open", "_start_boundary", "_team_match", "_boundary_dist", "_start"], ascending=[False, False, False, True, False])
    row = cand.iloc[0]
    method = "half_open_fallback" if bool(row.get("_half_open")) else "tolerance_team_fallback"
    return row.get("possession_id"), method


def attach_possession_ids_to_events(events: pd.DataFrame, possessions: pd.DataFrame) -> pd.DataFrame:
    if events.empty or possessions.empty:
        events["true_possession_id"] = None
        return events

    out = events.copy().reset_index(drop=False).rename(columns={"index": "_event_row"})
    out["_period_int"] = pd.to_numeric(out.get("period"), errors="coerce")
    out["_event_elapsed"] = pd.to_numeric(out.get("game_elapsed_seconds"), errors="coerce").astype(float)

    poss = possessions.copy()
    poss["_period_int"] = pd.to_numeric(poss.get("period"), errors="coerce")
    poss["_start_raw"] = pd.to_numeric(poss.get("start_elapsed"), errors="coerce")
    poss["_end_raw"] = pd.to_numeric(poss.get("end_elapsed"), errors="coerce")
    poss = poss.dropna(subset=["_period_int", "_start_raw", "_end_raw"]).copy()
    if poss.empty:
        out["true_possession_id"] = None
        return out.drop(columns=[c for c in out.columns if c.startswith("_")], errors="ignore")

    poss["_start"] = poss[["_start_raw", "_end_raw"]].min(axis=1).astype(float)
    poss["_end"] = poss[["_start_raw", "_end_raw"]].max(axis=1).astype(float)
    poss = poss.sort_values(["_period_int", "_start", "_end"]).reset_index(drop=True)

    assignments: Dict[int, Any] = {}
    methods: Dict[int, str] = {}
    eps = 0.2

    eligible = out.dropna(subset=["_period_int", "_event_elapsed"]).copy()
    for period, evg in eligible.groupby("_period_int", sort=False):
        pg = poss[poss["_period_int"] == period].copy()
        if pg.empty:
            continue
        ev_sorted = evg.sort_values("_event_elapsed")
        pg_sorted = pg.sort_values("_start")
        merged = pd.merge_asof(
            ev_sorted,
            pg_sorted[["possession_id", "offense_team", "_start", "_end"]].sort_values("_start"),
            left_on="_event_elapsed",
            right_on="_start",
            direction="backward",
            allow_exact_matches=True,
        )
        last_end = float(pg_sorted["_end"].max())
        for _, m in merged.iterrows():
            row_id = int(m["_event_row"])
            pid = m.get("possession_id")
            valid = False
            if pd.notna(pid) and pd.notna(m.get("_start")) and pd.notna(m.get("_end")):
                t = float(m["_event_elapsed"])
                start = float(m["_start"])
                end = float(m["_end"])
                valid = (start <= t) and (t < end)
                if not valid and abs(t - last_end) <= eps and abs(t - end) <= eps:
                    valid = True
            if valid:
                assignments[row_id] = pid
                methods[row_id] = "merge_asof_half_open"
            else:
                pid2, method = _possession_fallback_match(m, pg_sorted, eps=eps)
                assignments[row_id] = pid2
                methods[row_id] = method

    out["true_possession_id"] = out["_event_row"].map(assignments)
    out["true_possession_attach_method"] = out["_event_row"].map(methods).fillna("unmatched")
    return out.drop(columns=[c for c in out.columns if c.startswith("_")], errors="ignore")


def build_observed_touch_chain(events: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    if events.empty:
        return pd.DataFrame(rows)

    def add(e, role, player_col="player_id_bbref", name_col="player", confidence=1.0):
        pid = e.get(player_col)
        if pid is None or str(pid) in {"", "nan", "None"}:
            return
        rows.append({
            "bbref_game_id": e.get("bbref_game_id"),
            "possession_id": e.get("true_possession_id"),
            "event_id": e.get("event_id"),
            "event_index": e.get("event_index"),
            "period": e.get("period"),
            "clock": e.get("clock"),
            "game_elapsed_seconds": e.get("game_elapsed_seconds"),
            "player_id_bbref": pid,
            "player_name": e.get(name_col),
            "touch_role": role,
            "is_observed": True,
            "confidence": confidence,
            "source": "bbref_pbp_actor_skeleton",
            "event_text": e.get("event_text"),
        })

    for _, e in events.iterrows():
        if is_true(e.get("is_def_rebound")):
            add(e, "DEFENSIVE_REBOUNDER_START")
        if is_true(e.get("is_off_rebound")):
            add(e, "OFFENSIVE_REBOUNDER")
        if is_true(e.get("is_shot")):
            add(e, "SHOT_TAKER")
        if str(e.get("assist_id_bbref", "")) not in {"", "nan", "None"}:
            add(e, "ASSISTER", "assist_id_bbref", "player2")
        if is_true(e.get("is_turnover")):
            add(e, "TURNOVER_PLAYER")
        if is_true(e.get("is_steal")) and str(e.get("steal_id_bbref", "")) not in {"", "nan", "None"}:
            add(e, "STEAL_PLAYER", "steal_id_bbref", "player2")
        if is_true(e.get("is_block")) and str(e.get("block_id_bbref", "")) not in {"", "nan", "None"}:
            add(e, "BLOCK_PLAYER", "block_id_bbref", "player2")
        if is_true(e.get("is_ft")):
            add(e, "FREE_THROW_SHOOTER")
        if is_true(e.get("is_foul")) and not is_true(e.get("is_turnover")):
            # BBRef often places fouls in the drawn-team column; keep role generic until validated.
            add(e, "FOUL_EVENT_PRIMARY_ACTOR", confidence=0.75)

    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df["touch_index_observed_order"] = df.groupby("possession_id").cumcount() + 1
    return df


# =============================================================================
# NBA game ID crosswalk + sidecars
# =============================================================================

def bbref_game_date_to_nba_date(game_id: str) -> str:
    return f"{game_id[4:6]}/{game_id[6:8]}/{game_id[:4]}"


def _append_nba_crosswalk_failure(log_path: Optional[str | Path], rec: Dict[str, Any]) -> None:
    if not log_path:
        return
    try:
        path = Path(log_path)
        ensure_dir(path.parent)
        row = pd.DataFrame([{**{"logged_at_utc": pd.Timestamp.utcnow().isoformat()}, **rec}])
        if path.exists():
            row.to_csv(path, mode="a", index=False, header=False)
        else:
            row.to_csv(path, index=False)
    except Exception as e:
        print(f"WARN: could not write NBA crosswalk failure log {log_path}: {e}")


def _iso_date_from_any(value: Any) -> Optional[str]:
    if value is None or pd.isna(value):
        return None
    text = str(value).strip()
    if not text:
        return None
    # Already ISO-like: 2025-10-22 or 2025-10-22T00:00:00Z
    m = re.search(r"(\d{4}-\d{2}-\d{2})", text)
    if m:
        return m.group(1)
    # NBA/BBRef date: MM/DD/YYYY
    try:
        dt = pd.to_datetime(text, errors="coerce")
        if pd.notna(dt):
            return dt.strftime("%Y-%m-%d")
    except Exception:
        pass
    return None


def _bbref_game_id_to_iso_date(game_id: str) -> str:
    return f"{game_id[:4]}-{game_id[4:6]}-{game_id[6:8]}"


def _extract_schedule_team_code(team_obj: Any) -> Optional[str]:
    if isinstance(team_obj, dict):
        for k in ["teamTricode", "teamTricodeLong", "teamAbbreviation", "tricode", "abbreviation", "teamCode"]:
            v = team_obj.get(k)
            if v:
                return clean_team_code(v)
    return clean_team_code(team_obj)


def _iter_schedule_games(obj: Any) -> Iterable[Dict[str, Any]]:
    """Yield normalized game records from NBA schedule/live JSON shapes."""
    if isinstance(obj, dict):
        game_id = obj.get("gameId") or obj.get("gameID") or obj.get("GAME_ID")
        home_obj = obj.get("homeTeam") or obj.get("hTeam") or obj.get("home")
        away_obj = obj.get("awayTeam") or obj.get("vTeam") or obj.get("visitorTeam") or obj.get("away")
        home = _extract_schedule_team_code(home_obj)
        away = _extract_schedule_team_code(away_obj)
        game_date = (
            obj.get("gameDateEst") or obj.get("gameDateEastern") or obj.get("gameDate")
            or obj.get("GAME_DATE_EST") or obj.get("gameDateTimeEst") or obj.get("gameTimeUTC")
        )
        iso = _iso_date_from_any(game_date)
        if game_id and home and away:
            yield {
                "game_id": str(game_id),
                "home": home,
                "away": away,
                "date_iso": iso,
                "game_code": obj.get("gameCode") or obj.get("GAMECODE") or obj.get("gameCodeLong"),
                "source": "nba_static_schedule_cdn",
            }
        for v in obj.values():
            yield from _iter_schedule_games(v)
    elif isinstance(obj, list):
        for item in obj:
            yield from _iter_schedule_games(item)


def fetch_nba_schedule_cdn() -> Tuple[pd.DataFrame, str]:
    payload, route = _raw_get_json_with_cache(
        "NBAScheduleCDN",
        None,
        NBA_STATIC_SCHEDULE_URL,
        headers=NBA_CDN_HEADERS,
        timeout=30,
    )
    if not payload:
        return pd.DataFrame(), route
    rows = list(_iter_schedule_games(payload))
    if not rows:
        return pd.DataFrame(), route
    df = pd.DataFrame(rows).drop_duplicates(["game_id", "home", "away", "date_iso"], keep="last")
    return df, route


def resolve_nba_game_id_from_schedule_cdn(
    bbref_game_id: str,
    home_team_bbref: Optional[str] = None,
    away_team_bbref: Optional[str] = None,
    log_path: Optional[str | Path] = None,
) -> Optional[str]:
    home = home_team_bbref or bbref_game_id[-3:]
    home_nba = BBREF_TO_NBA_TEAM.get(str(home).upper(), str(home).upper())
    away_nba = BBREF_TO_NBA_TEAM.get(str(away_team_bbref).upper(), str(away_team_bbref).upper()) if away_team_bbref else None
    iso_date = _bbref_game_id_to_iso_date(bbref_game_id)
    try:
        schedule, route = fetch_nba_schedule_cdn()
        if schedule.empty:
            _append_nba_crosswalk_failure(log_path, {
                "bbref_game_id": bbref_game_id, "reason": "nba_schedule_cdn_empty_or_failed", "route": route
            })
            return None
        cand = schedule[(schedule["date_iso"] == iso_date) & (schedule["home"] == home_nba)].copy()
        if away_nba:
            cand = cand[cand["away"] == away_nba]
        if len(cand) == 1:
            return str(cand.iloc[0]["game_id"])
        if len(cand) > 1:
            _append_nba_crosswalk_failure(log_path, {
                "bbref_game_id": bbref_game_id, "reason": "ambiguous_schedule_cdn_matches",
                "candidate_game_ids": json.dumps(cand["game_id"].astype(str).tolist()),
            })
            return None
        _append_nba_crosswalk_failure(log_path, {
            "bbref_game_id": bbref_game_id, "reason": "no_schedule_cdn_match",
            "game_date_iso": iso_date, "home_nba": home_nba, "away_nba": away_nba,
        })
    except Exception as e:
        _append_nba_crosswalk_failure(log_path, {
            "bbref_game_id": bbref_game_id, "reason": "schedule_cdn_exception", "error": str(e)
        })
    return None


def _scoreboard_candidates_from_frames(dfs: List[pd.DataFrame], home_nba: str, away_nba: Optional[str]) -> Tuple[List[str], List[Dict[str, Any]]]:
    matches: List[str] = []
    seen: set[str] = set()
    available: List[Dict[str, Any]] = []
    home_nba = str(home_nba).upper()
    away_nba = str(away_nba).upper() if away_nba else None

    def add_match(game_id: Any, why: str, row: Optional[pd.Series] = None) -> None:
        if game_id is None or pd.isna(game_id):
            return
        gid = str(game_id)
        if gid not in seen:
            seen.add(gid)
            matches.append(gid)
        if row is not None:
            available.append({"game_id": gid, "why": why, "row": {k: row.get(k) for k in row.index if k in {"GAME_ID", "GAMECODE", "HOME_TEAM_ABBREVIATION", "VISITOR_TEAM_ABBREVIATION", "HTM", "VTM"}}})

    for df in dfs:
        if df is None or df.empty or "GAME_ID" not in df.columns:
            continue
        cols = set(df.columns)
        for _, r in df.iterrows():
            h = clean_team_code(r.get("HOME_TEAM_ABBREVIATION") or r.get("HTM") or r.get("HOME_TEAM"))
            v = clean_team_code(r.get("VISITOR_TEAM_ABBREVIATION") or r.get("VTM") or r.get("AWAY_TEAM") or r.get("VISITOR_TEAM"))
            gamecode = clean_team_code(r.get("GAMECODE"))
            if h == home_nba and (away_nba is None or v in {None, away_nba}):
                add_match(r.get("GAME_ID"), "home_visitor_columns", r)
            elif gamecode and gamecode.endswith(f"/{away_nba or ''}{home_nba}"):
                add_match(r.get("GAME_ID"), "gamecode_away_home_suffix", r)
            elif gamecode and away_nba and f"/{away_nba}{home_nba}" in gamecode:
                add_match(r.get("GAME_ID"), "gamecode_away_home", r)

    # ScoreboardV2 often has a LineScore-style frame with one team row per game.
    # That frame may not mark home/away, but matching date + both teams is a strong
    # fallback for doubleheaders/abbreviation quirks.
    for df in dfs:
        if df is None or df.empty or "GAME_ID" not in df.columns:
            continue
        abbr_col = None
        for c in ["TEAM_ABBREVIATION", "TEAM_ABBREVIATION_HOME", "TEAM_ABBREVIATION_AWAY", "TEAM"]:
            if c in df.columns:
                abbr_col = c
                break
        if not abbr_col:
            continue
        for gid, g in df.groupby("GAME_ID"):
            teams = {clean_team_code(x) for x in g[abbr_col].tolist()}
            teams.discard(None)
            if home_nba in teams and (away_nba is None or away_nba in teams):
                add_match(gid, "line_score_team_set")

    return matches, available


def resolve_nba_game_id_from_scoreboard(
    bbref_game_id: str,
    home_team_bbref: Optional[str] = None,
    away_team_bbref: Optional[str] = None,
    log_path: Optional[str | Path] = None,
) -> Optional[str]:
    home = home_team_bbref or bbref_game_id[-3:]
    home_nba = BBREF_TO_NBA_TEAM.get(str(home).upper(), str(home).upper())
    away_nba = BBREF_TO_NBA_TEAM.get(str(away_team_bbref).upper(), str(away_team_bbref).upper()) if away_team_bbref else None
    game_date = bbref_game_date_to_nba_date(bbref_game_id)

    # Primary route: stats.nba.com ScoreboardV2 via nba_api.
    if scoreboardv2 is not None:
        try:
            sb = scoreboardv2.ScoreboardV2(game_date=game_date, headers=NBA_HEADERS, timeout=30)
            dfs = sb.get_data_frames()
            matches, available = _scoreboard_candidates_from_frames(dfs, home_nba, away_nba)
            if len(matches) == 1:
                return matches[0]
            if len(matches) > 1:
                _append_nba_crosswalk_failure(log_path, {
                    "bbref_game_id": bbref_game_id, "game_date": game_date, "home_nba": home_nba,
                    "away_nba": away_nba, "reason": "ambiguous_scoreboard_matches",
                    "candidate_game_ids": json.dumps(matches),
                })
                return None
            _append_nba_crosswalk_failure(log_path, {
                "bbref_game_id": bbref_game_id, "game_date": game_date, "home_nba": home_nba,
                "away_nba": away_nba, "reason": "no_scoreboard_match",
                "scoreboard_probe": json.dumps(available[:8], default=str),
            })
        except Exception as e:
            _append_nba_crosswalk_failure(log_path, {
                "bbref_game_id": bbref_game_id, "game_date": game_date, "home_nba": home_nba,
                "away_nba": away_nba, "reason": "scoreboardv2_exception", "error": str(e),
            })
            print(f"WARN: ScoreboardV2 could not resolve NBA game id for {bbref_game_id}: {e}")
    else:
        _append_nba_crosswalk_failure(log_path, {"bbref_game_id": bbref_game_id, "reason": "nba_api_scoreboardv2_unavailable"})

    # Fallback route: documented/static NBA CDN schedule JSON.  This is not a
    # firewall-bypass/proxy layer; it is a different official public data route.
    cdn_gid = resolve_nba_game_id_from_schedule_cdn(
        bbref_game_id, home_team_bbref=home_team_bbref, away_team_bbref=away_team_bbref, log_path=log_path
    )
    if cdn_gid:
        _append_nba_crosswalk_failure(log_path, {
            "bbref_game_id": bbref_game_id, "game_date": game_date, "home_nba": home_nba,
            "away_nba": away_nba, "reason": "resolved_by_schedule_cdn_fallback", "nba_game_id": cdn_gid,
        })
        return cdn_gid
    return None


def _normalize_nba_live_action_rows(actions: List[Dict[str, Any]], nba_game_id: str, source: str) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for idx, a in enumerate(actions or []):
        period = maybe_int(a.get("period"))
        clock = a.get("clock")
        action_no = a.get("actionNumber")
        if action_no is None:
            action_no = a.get("actionId")
        rows.append({
            "nba_game_id": nba_game_id,
            "nba_event_index": idx,
            "nba_action_number": action_no,
            "period": period,
            "clock": clock,
            "game_elapsed_seconds": elapsed_from_nba_clock(period, clock) if period else None,
            "action_type": a.get("actionType"),
            "sub_type": a.get("subType"),
            "descriptor": a.get("descriptor"),
            "qualifiers": json.dumps(a.get("qualifiers")) if isinstance(a.get("qualifiers"), (list, dict)) else a.get("qualifiers"),
            "team_id_nba": a.get("teamId"),
            "team_tricode_nba": a.get("teamTricode"),
            "player_id_nba": a.get("personId"),
            "player_name_nba": a.get("playerName"),
            "x": a.get("x"),
            "y": a.get("y"),
            "x_legacy": a.get("xLegacy"),
            "y_legacy": a.get("yLegacy"),
            "shot_distance": a.get("shotDistance"),
            "score_home": a.get("scoreHome"),
            "score_away": a.get("scoreAway"),
            "description": clean_text(a.get("description", "")),
            "nba_pbp_source": source,
            "nba_pbp_provenance": normalize_nba_provenance(source),
            "data_provenance": normalize_nba_provenance(source),
            "raw_action": json.dumps(a),
        })
    return pd.DataFrame(rows)


def fetch_nba_pbp_live_cdn(nba_game_id: str) -> pd.DataFrame:
    """Fetch documented NBA live play-by-play CDN JSON as a stats-PBP fallback."""
    url = NBA_LIVE_PBP_CDN_URL.format(game_id=nba_game_id)
    payload, route = _raw_get_json_with_cache(
        "LivePlayByPlayCDN",
        nba_game_id,
        url,
        headers=NBA_CDN_HEADERS,
        timeout=30,
    )
    if not payload:
        return pd.DataFrame()
    actions = payload.get("game", {}).get("actions", [])
    if not isinstance(actions, list) or not actions:
        log_nba_api_failure("LivePlayByPlayCDN", nba_game_id, "no_actions_in_live_cdn_payload", {"url": url, "route": route})
        return pd.DataFrame()
    out = _normalize_nba_live_action_rows(actions, nba_game_id, source=f"nba_live_cdn_{route}")
    return out


def fetch_nba_pbp_v3(nba_game_id: str) -> pd.DataFrame:
    # Primary route: stats.nba.com PlayByPlayV3.
    if playbyplayv3 is not None:
        try:
            raw = playbyplayv3.PlayByPlayV3(game_id=nba_game_id, headers=NBA_HEADERS, timeout=30).get_json()
            actions = json.loads(raw)["game"]["actions"]
            out = _normalize_nba_live_action_rows(actions, nba_game_id, source="nba_stats_playbyplayv3")
            return out
        except Exception as e:
            log_nba_api_failure("PlayByPlayV3", nba_game_id, e)
            print(f"WARN: PlayByPlayV3 failed for {nba_game_id}: {e}")
    else:
        log_nba_api_failure("PlayByPlayV3", nba_game_id, "nba_api_playbyplayv3_unavailable")

    # Fallback route: official NBA live-data CDN JSON.  This keeps enrichment
    # alive when stats.nba.com is blocked, without using public proxies/Tor.
    cdn = fetch_nba_pbp_live_cdn(nba_game_id)
    if not cdn.empty:
        return cdn
    return pd.DataFrame()

def fetch_nba_shotchart(nba_game_id: str, season_label: str = "2025-26") -> pd.DataFrame:
    if shotchartdetail is None:
        return pd.DataFrame()
    try:
        df = shotchartdetail.ShotChartDetail(
            team_id=0,
            player_id=0,
            game_id_nullable=nba_game_id,
            context_measure_simple_nullable="FGA",
            season_nullable=season_label,
            headers=NBA_HEADERS,
            timeout=30,
        ).get_data_frames()[0]
        df.insert(0, "nba_game_id", nba_game_id)
        df["shotchart_provenance"] = "stats_api"
        df["data_provenance"] = "stats_api"
        return df
    except Exception as e:
        log_nba_api_failure("ShotChartDetail", nba_game_id, e, {"season_label": season_label})
        print(f"WARN: ShotChartDetail failed for {nba_game_id}: {e}")
        return pd.DataFrame()



def _find_first_column(df: pd.DataFrame, candidates: Iterable[str]) -> Optional[str]:
    if df is None or df.empty:
        return None
    lookup = {str(c).lower(): c for c in df.columns}
    for cand in candidates:
        c = lookup.get(str(cand).lower())
        if c is not None:
            return c
    return None


def normalize_probability_value(x: Any) -> Optional[float]:
    """Normalize NBA win-prob values to 0..1.

    nba_api docs expose HOME_PCT/VISITOR_PCT. Depending on endpoint/runtime,
    those can arrive as fractions (0.537) or percentages (53.7).  This keeps the
    parser from mistaking 53.7 for a 5,370% win probability.
    """
    v = _float_or_none(x)
    if v is None:
        return None
    if v > 1.000001 and v <= 100.0:
        v = v / 100.0
    return float(max(0.0, min(1.0, v)))


def calculate_custom_leverage_index(
    period: Any,
    clock: Any = None,
    home_win_probability: Any = None,
    game_elapsed_seconds: Any = None,
    home_score: Any = None,
    away_score: Any = None,
) -> Tuple[float, int, str, float]:
    """Return (custom_li, garbage_flag, source, confidence).

    Official NBA win probability is preferred when present.  If the endpoint is
    down/unavailable, fall back to a coarse score-margin/time heuristic rather
    than writing fake neutral 0.50 probabilities into the official WP columns.
    """
    p = _int_or_none(period)
    if p is None:
        return 1.0, 0, "missing_period_neutral", 0.0

    rem = seconds_remaining_in_period(p, clock=clock, game_elapsed_seconds=game_elapsed_seconds)
    hp = normalize_probability_value(home_win_probability)
    source = "official_win_probability" if hp is not None else "score_time_margin_fallback"
    confidence = 0.90 if hp is not None else 0.40

    if hp is not None:
        closeness = 1.0 - (abs(hp - 0.5) / 0.5)
    else:
        hs = _float_or_none(home_score)
        aas = _float_or_none(away_score)
        if hs is None or aas is None:
            closeness = 1.0
            source = "neutral_no_win_probability_or_score"
            confidence = 0.0
        else:
            margin = abs(hs - aas)
            # Coarse heuristic: a 0-point game = 1.0, 30+ point game = 0.0.
            closeness = max(0.0, 1.0 - margin / 30.0)

    time_weight = 1.0
    if p >= 5:
        time_weight = 2.75
    elif p >= 4:
        if rem is not None and rem <= 240.0:
            time_weight = 2.5
        else:
            time_weight = 1.5

    custom_li = round(float(max(0.0, closeness) * time_weight), 4)

    garbage = 0
    if p >= 4:
        if hp is not None and (hp >= 0.96 or hp <= 0.04):
            garbage = 1
        elif hp is None:
            hs = _float_or_none(home_score)
            aas = _float_or_none(away_score)
            margin = abs(hs - aas) if hs is not None and aas is not None else None
            # Explicitly lower-confidence fallback.  This prevents a broken WP
            # endpoint from erasing useful rows, but still tags obvious blowouts.
            if margin is not None and rem is not None and rem <= 360.0 and margin >= 25.0:
                garbage = 1

    return custom_li, int(garbage), source, float(confidence)




def _probability_pair(home_value: Any, away_value: Any) -> Tuple[Optional[float], Optional[float]]:
    hp = normalize_probability_value(home_value)
    ap = normalize_probability_value(away_value)
    if hp is None and ap is not None:
        hp = 1.0 - ap
    if ap is None and hp is not None:
        ap = 1.0 - hp
    if hp is not None:
        hp = float(max(0.0, min(1.0, hp)))
    if ap is not None:
        ap = float(max(0.0, min(1.0, ap)))
    return hp, ap


def elapsed_from_winprob_clock_or_seconds(period: int, seconds_remaining: Any = None, clock: Any = None) -> Tuple[Optional[float], str]:
    """Normalize WinProbabilityPBP time to game elapsed seconds.

    nba_api documents both PCTIMESTRING and SECONDS_REMAINING for this endpoint.
    In practice, SECONDS_REMAINING can be interpreted differently across endpoint
    snapshots/run types, so prefer the period clock string when present. If only
    seconds are available, values inside the current period length are treated as
    period-seconds remaining; larger regulation values are treated as total game
    seconds remaining.
    """
    p = _int_or_none(period)
    if p is None:
        return None, "missing_period"

    clock_rem = bbref_clock_to_seconds_remaining(clock)
    if clock_rem is None:
        clock_rem = nba_clock_to_seconds_remaining(clock)
    if clock_rem is not None:
        return elapsed_from_period_seconds_remaining(p, clock_rem), "pctimestring_period_clock"

    sec = _float_or_none(seconds_remaining)
    if sec is None:
        return None, "missing_seconds_remaining"

    plen = period_length_seconds(p)
    if 0.0 <= sec <= plen + 1e-6:
        return elapsed_from_period_seconds_remaining(p, sec), "seconds_remaining_period_clock"

    # Common each-second WinProbabilityPBP shape: seconds remaining in regulation/game.
    # Use this only for regulation periods; OT rows should normally have a PCTIMESTRING
    # or <=300 seconds remaining and go through the period-clock path above.
    if p <= 4 and 0.0 <= sec <= 2880.0 + 1e-6:
        return round(max(0.0, 2880.0 - sec), 1), "seconds_remaining_regulation_game_clock"

    return None, "unrecognized_seconds_remaining_basis"

def _normalize_winprob_pbp_frame(wp_df: pd.DataFrame, nba_game_id: str) -> pd.DataFrame:
    if wp_df is None or wp_df.empty:
        return pd.DataFrame()

    event_col = _find_first_column(wp_df, ["EVENT_NUM", "EVENTNUM", "EVENT_NUM_ID", "GAME_EVENT_ID", "event_num"])
    home_col = _find_first_column(wp_df, ["HOME_PCT", "HOME_WP", "HOME_WIN_PCT", "home_pct"])
    away_col = _find_first_column(wp_df, ["VISITOR_PCT", "VISITOR_WP", "AWAY_WP", "VISITOR_WIN_PCT", "visitor_pct"])
    period_col = _find_first_column(wp_df, ["PERIOD", "period"])
    sec_col = _find_first_column(wp_df, ["SECONDS_REMAINING", "SECONDSREMAINING", "seconds_remaining"])
    clock_col = _find_first_column(wp_df, ["PCTIMESTRING", "PCTIME", "CLOCK", "clock"])
    lev_col = _find_first_column(wp_df, ["LEVERAGE_INDEX", "LEVERAGE", "LI", "leverage_index"])
    desc_col = _find_first_column(wp_df, ["DESCRIPTION", "description"])

    if home_col is None or away_col is None or period_col is None:
        return pd.DataFrame()

    rows: List[Dict[str, Any]] = []
    for idx, r in wp_df.iterrows():
        period = _int_or_none(r.get(period_col))
        if period is None:
            continue
        event_num = _int_or_none(r.get(event_col)) if event_col else None
        home_wp, away_wp = _probability_pair(r.get(home_col), r.get(away_col))
        sec_rem = _float_or_none(r.get(sec_col)) if sec_col else None
        clock_value = r.get(clock_col) if clock_col else None
        elapsed, time_basis = elapsed_from_winprob_clock_or_seconds(period, sec_rem, clock_value)
        rows.append({
            "nba_game_id": nba_game_id,
            "winprob_row_index": int(idx),
            "winprob_event_num": event_num,
            "period": period,
            "winprob_seconds_remaining": sec_rem,
            "winprob_clock": clock_value,
            "winprob_game_elapsed_seconds": elapsed,
            "winprob_time_basis": time_basis,
            "home_win_probability": home_wp,
            "away_win_probability": away_wp,
            "official_leverage_index_score": _float_or_none(r.get(lev_col)) if lev_col else None,
            "win_probability_description": clean_text(r.get(desc_col, "")) if desc_col else None,
            "win_probability_source": "nba_stats_winprobabilitypbp",
            "win_probability_provenance": "stats_api",
            "data_provenance": "stats_api",
        })
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    # Endpoint can contain each-second rows with repeated/null event ids.  Keep a
    # stable row order for direct event matches and asof fallbacks.
    out["winprob_game_elapsed_seconds"] = pd.to_numeric(out["winprob_game_elapsed_seconds"], errors="coerce").astype(float)
    return out


def fetch_nba_win_probability_pbp(nba_game_id: str) -> pd.DataFrame:
    """Fetch and normalize NBA WinProbabilityPBP with robust failure handling.

    Current nba_api docs list WinProbPBP columns as EVENT_NUM, HOME_PCT,
    VISITOR_PCT, PERIOD, and SECONDS_REMAINING.  The endpoint has also had
    upstream non-JSON failures, so this function must never be a hard dependency
    for parsing a game.
    """
    if winprobabilitypbp is None:
        return pd.DataFrame()
    try:
        endpoint = winprobabilitypbp.WinProbabilityPBP(
            game_id=nba_game_id,
            run_type="each second",
            headers=NBA_HEADERS,
            timeout=30,
        )
        frames = endpoint.get_data_frames()
        candidates = []
        for df in frames:
            if df is not None and not df.empty:
                cols = {str(c).upper() for c in df.columns}
                if {"HOME_PCT", "VISITOR_PCT"}.issubset(cols) or {"HOME_WP", "VISITOR_WP"}.issubset(cols):
                    candidates.append(df)
        if not candidates:
            return pd.DataFrame()
        norm = _normalize_winprob_pbp_frame(candidates[0], nba_game_id)
        return norm
    except Exception as e:
        log_nba_api_failure("WinProbabilityPBP", nba_game_id, e, {"run_type": "each second"})
        print(f"WARN: WinProbabilityPBP failed for {nba_game_id}: {e}")
        return pd.DataFrame()


def add_win_probability_features(events: pd.DataFrame, winprob: Optional[pd.DataFrame] = None) -> pd.DataFrame:
    if events is None or events.empty:
        return events

    out = events.copy().reset_index(drop=False).rename(columns={"index": "_event_row"})
    default_cols = {
        "home_win_probability": None,
        "away_win_probability": None,
        "official_leverage_index_score": None,
        "custom_leverage_index_score": 1.0,
        "flag_is_low_leverage_garbage_time": 0,
        "win_probability_available": 0,
        "win_probability_source": "score_time_margin_fallback",
        "win_probability_confidence": 0.0,
        "win_probability_data_provenance": "bbref_only",
        "win_probability_event_num": None,
        "win_probability_alignment_method": "score_time_margin_fallback",
        "win_probability_seconds_delta": None,
        "leverage_model_version": LEVERAGE_FEATURE_VERSION,
    }
    for c, v in default_cols.items():
        out[c] = v

    # Start every row with the fallback LI so downstream filters still have a
    # calibrated pressure/garbage-time signal even when the endpoint is down.
    for idx, e in out.iterrows():
        li, garbage, src, conf = calculate_custom_leverage_index(
            e.get("period"),
            clock=e.get("clock"),
            game_elapsed_seconds=e.get("game_elapsed_seconds"),
            home_score=e.get("home_score"),
            away_score=e.get("away_score"),
        )
        out.at[idx, "custom_leverage_index_score"] = li
        out.at[idx, "flag_is_low_leverage_garbage_time"] = garbage
        out.at[idx, "win_probability_source"] = src
        out.at[idx, "win_probability_confidence"] = conf
        out.at[idx, "win_probability_data_provenance"] = normalize_nba_provenance(src)

    if winprob is None or winprob.empty:
        return out.drop(columns=[c for c in out.columns if c.startswith("_")], errors="ignore")

    wp = winprob.copy()
    # Direct event-id/action-number match is preferred.
    if "winprob_event_num" in wp.columns and "nba_action_number" in out.columns:
        wp_direct = wp.dropna(subset=["winprob_event_num"]).copy()
        if not wp_direct.empty:
            wp_direct["_wp_event_num"] = pd.to_numeric(wp_direct["winprob_event_num"], errors="coerce")
            wp_direct = wp_direct.dropna(subset=["_wp_event_num"]).drop_duplicates("_wp_event_num", keep="last")
            lookup = wp_direct.set_index("_wp_event_num")
            for idx, e in out.iterrows():
                action_no = _float_or_none(e.get("nba_action_number"))
                if action_no is None or action_no not in lookup.index:
                    continue
                r = lookup.loc[action_no]
                hp, ap = _probability_pair(r.get("home_win_probability"), r.get("away_win_probability"))
                li, garbage, src, conf = calculate_custom_leverage_index(
                    e.get("period"), clock=e.get("clock"), game_elapsed_seconds=e.get("game_elapsed_seconds"),
                    home_win_probability=hp, home_score=e.get("home_score"), away_score=e.get("away_score")
                )
                out.at[idx, "home_win_probability"] = hp
                out.at[idx, "away_win_probability"] = ap
                out.at[idx, "official_leverage_index_score"] = r.get("official_leverage_index_score")
                out.at[idx, "custom_leverage_index_score"] = li
                out.at[idx, "flag_is_low_leverage_garbage_time"] = garbage
                out.at[idx, "win_probability_available"] = 1
                out.at[idx, "win_probability_source"] = r.get("win_probability_source") or src
                out.at[idx, "win_probability_confidence"] = conf
                out.at[idx, "win_probability_data_provenance"] = r.get("win_probability_provenance") or normalize_nba_provenance(r.get("win_probability_source") or src)
                out.at[idx, "win_probability_event_num"] = _int_or_none(r.get("winprob_event_num")) or int(action_no)
                out.at[idx, "win_probability_alignment_method"] = "direct_event_num"
                out.at[idx, "win_probability_seconds_delta"] = 0.0

    # Asof fallback covers each-second rows or mismatched action/event numbering.
    need = out[out["win_probability_available"].astype(int) == 0].copy()
    if not need.empty and "winprob_game_elapsed_seconds" in wp.columns:
        wp2 = wp.dropna(subset=["period", "winprob_game_elapsed_seconds"]).copy()
        wp2["_period_int"] = pd.to_numeric(wp2["period"], errors="coerce")
        wp2["_wp_elapsed"] = pd.to_numeric(wp2["winprob_game_elapsed_seconds"], errors="coerce").astype(float)
        ev = need.dropna(subset=["period", "game_elapsed_seconds"]).copy()
        ev["_period_int"] = pd.to_numeric(ev["period"], errors="coerce")
        ev["_event_elapsed"] = pd.to_numeric(ev["game_elapsed_seconds"], errors="coerce").astype(float)
        for period, evg in ev.groupby("_period_int", sort=False):
            wg = wp2[wp2["_period_int"] == period].sort_values("_wp_elapsed")
            if wg.empty:
                continue
            keep_cols = [
                "winprob_event_num", "home_win_probability", "away_win_probability",
                "official_leverage_index_score", "win_probability_source", "_wp_elapsed"
            ]
            if "win_probability_provenance" in wg.columns:
                keep_cols.append("win_probability_provenance")
            wg_match = wg[keep_cols].rename(columns={
                "home_win_probability": "_wp_home_win_probability",
                "away_win_probability": "_wp_away_win_probability",
                "official_leverage_index_score": "_wp_official_leverage_index_score",
                "win_probability_source": "_wp_win_probability_source",
                "win_probability_provenance": "_wp_win_probability_provenance",
            }).sort_values("_wp_elapsed")
            merged = pd.merge_asof(
                evg.sort_values("_event_elapsed"),
                wg_match,
                left_on="_event_elapsed",
                right_on="_wp_elapsed",
                direction="nearest",
                tolerance=3.0,
            )
            for _, m in merged.iterrows():
                if pd.isna(m.get("_wp_home_win_probability")):
                    continue
                idx = int(m["_event_row"])
                hp, ap = _probability_pair(m.get("_wp_home_win_probability"), m.get("_wp_away_win_probability"))
                li, garbage, src, conf = calculate_custom_leverage_index(
                    m.get("period"), clock=m.get("clock"), game_elapsed_seconds=m.get("game_elapsed_seconds"),
                    home_win_probability=hp, home_score=m.get("home_score"), away_score=m.get("away_score")
                )
                dt = abs(float(m["_event_elapsed"]) - float(m["_wp_elapsed"])) if pd.notna(m.get("_wp_elapsed")) else 3.0
                out.at[idx, "home_win_probability"] = hp
                out.at[idx, "away_win_probability"] = ap
                out.at[idx, "official_leverage_index_score"] = m.get("_wp_official_leverage_index_score")
                out.at[idx, "custom_leverage_index_score"] = li
                out.at[idx, "flag_is_low_leverage_garbage_time"] = garbage
                out.at[idx, "win_probability_available"] = 1
                out.at[idx, "win_probability_source"] = m.get("_wp_win_probability_source") or src
                out.at[idx, "win_probability_confidence"] = round(max(0.0, conf * (1.0 - min(dt, 3.0) / 6.0)), 4)
                out.at[idx, "win_probability_data_provenance"] = m.get("_wp_win_probability_provenance") or normalize_nba_provenance(m.get("_wp_win_probability_source") or src)
                out.at[idx, "win_probability_event_num"] = _int_or_none(m.get("winprob_event_num"))
                out.at[idx, "win_probability_alignment_method"] = "nearest_elapsed_within_3s"
                out.at[idx, "win_probability_seconds_delta"] = round(float(dt), 4)

    return out.drop(columns=[c for c in out.columns if c.startswith("_")], errors="ignore")


def fetch_videoevents_for_nba_pbp(nba_game_id: str, nba_pbp: pd.DataFrame, max_events: int = 80) -> pd.DataFrame:
    if videoevents is None or nba_pbp.empty:
        return pd.DataFrame()
    rows = []
    # Don't hammer it for every event by default. Prioritize shot/turnover/block/steal-ish rows.
    cand = nba_pbp.copy()
    if "action_type" in cand.columns:
        mask = cand["action_type"].astype(str).str.lower().isin(["2pt", "3pt", "freethrow", "turnover", "block", "steal", "foul"])
        if mask.any():
            cand = cand[mask]
    cand = cand.head(max_events)
    for _, r in cand.iterrows():
        action_no = r.get("nba_action_number")
        if action_no is None or pd.isna(action_no):
            continue
        try:
            obj = videoevents.VideoEvents(game_id=nba_game_id, game_event_id=int(action_no), headers=NBA_HEADERS, timeout=30)
            payload = obj.nba_response.get_dict()
            rows.append({
                "nba_game_id": nba_game_id,
                "nba_action_number": int(action_no),
                "period": r.get("period"),
                "clock": r.get("clock"),
                "description": r.get("description"),
                "videoevents_payload": json.dumps(payload),
                "videoevents_error": None,
                "videoevents_provenance": "stats_api",
                "data_provenance": "stats_api",
            })
        except Exception as e:
            rows.append({
                "nba_game_id": nba_game_id,
                "nba_action_number": int(action_no),
                "period": r.get("period"),
                "clock": r.get("clock"),
                "description": r.get("description"),
                "videoevents_payload": None,
                "videoevents_error": str(e),
                "videoevents_provenance": "missing",
                "data_provenance": "missing",
            })
        time.sleep(0.25)
    return pd.DataFrame(rows)


def _bbref_event_kind(e: pd.Series) -> str:
    if is_true(e.get("is_shot")):
        return "shot"
    if is_true(e.get("is_turnover")):
        return "turnover"
    if is_true(e.get("is_rebound")):
        return "rebound"
    if is_true(e.get("is_foul")):
        return "foul"
    if is_true(e.get("is_sub")):
        return "substitution"
    if is_true(e.get("is_timeout")):
        return "timeout"
    if is_true(e.get("is_jumpball")):
        return "jumpball"
    return "other"


def _compatible_nba_actions(nba_period: pd.DataFrame, kind: str) -> pd.DataFrame:
    if nba_period.empty or "action_type" not in nba_period.columns:
        return nba_period
    at = nba_period["action_type"].astype(str).str.lower()
    if kind == "shot":
        mask = at.isin(["2pt", "3pt", "freethrow"])
    elif kind == "turnover":
        mask = at.str.contains("turnover", na=False)
    elif kind == "rebound":
        mask = at.str.contains("rebound", na=False)
    elif kind == "foul":
        mask = at.str.contains("foul", na=False)
    elif kind == "substitution":
        mask = at.str.contains("sub", na=False)
    elif kind == "timeout":
        mask = at.str.contains("timeout", na=False)
    elif kind == "jumpball":
        mask = at.str.contains("jump", na=False)
    else:
        mask = pd.Series(False, index=nba_period.index)
    filt = nba_period[mask].copy()
    return filt if not filt.empty else nba_period


def align_bbref_events_to_nba(events: pd.DataFrame, nba_pbp: pd.DataFrame) -> pd.DataFrame:
    if events.empty or nba_pbp.empty:
        return events.assign(nba_game_id=None, nba_action_number=None, nba_alignment_confidence=0.0, nba_description_aligned=None, nba_alignment_method="unmatched", nba_enrichment_provenance="bbref_only")

    out = events.copy().reset_index(drop=False).rename(columns={"index": "_event_row"})
    out["_period_int"] = pd.to_numeric(out.get("period"), errors="coerce")
    out["_event_elapsed"] = pd.to_numeric(out.get("game_elapsed_seconds"), errors="coerce").astype(float)
    out["_event_kind"] = out.apply(_bbref_event_kind, axis=1)

    nba = nba_pbp.dropna(subset=["period", "game_elapsed_seconds"]).copy()
    if nba.empty:
        return out.drop(columns=[c for c in out.columns if c.startswith("_")], errors="ignore").assign(nba_game_id=None, nba_action_number=None, nba_alignment_confidence=0.0, nba_description_aligned=None, nba_alignment_method="unmatched", nba_enrichment_provenance="bbref_only")
    nba["_period_int"] = pd.to_numeric(nba["period"], errors="coerce")
    nba["_nba_elapsed"] = pd.to_numeric(nba["game_elapsed_seconds"], errors="coerce").astype(float)
    nba = nba.dropna(subset=["_period_int", "_nba_elapsed"]).copy()
    nba_game_id = nba["nba_game_id"].dropna().iloc[0] if "nba_game_id" in nba.columns and nba["nba_game_id"].notna().any() else None

    actions: Dict[int, Any] = {}
    confs: Dict[int, float] = {}
    ndesc: Dict[int, Any] = {}
    methods: Dict[int, str] = {}
    provs: Dict[int, str] = {}
    tolerance = 6.0

    eligible = out.dropna(subset=["_period_int", "_event_elapsed"]).copy()
    for (period, kind), evg in eligible.groupby(["_period_int", "_event_kind"], sort=False):
        nba_period = nba[nba["_period_int"] == period].copy()
        if nba_period.empty:
            continue
        comp = _compatible_nba_actions(nba_period, kind)
        used_compatible = len(comp) < len(nba_period) and kind != "other"
        ev_sorted = evg.sort_values("_event_elapsed")
        nb_cols = ["nba_action_number", "description", "_nba_elapsed"]
        if "nba_pbp_provenance" in comp.columns:
            nb_cols.append("nba_pbp_provenance")
        elif "data_provenance" in comp.columns:
            nb_cols.append("data_provenance")
        if "action_type" in comp.columns:
            nb_cols.append("action_type")
        merged = pd.merge_asof(
            ev_sorted,
            comp[nb_cols].sort_values("_nba_elapsed"),
            left_on="_event_elapsed",
            right_on="_nba_elapsed",
            direction="nearest",
            tolerance=tolerance,
        )
        for _, m in merged.iterrows():
            row_id = int(m["_event_row"])
            if pd.isna(m.get("nba_action_number")):
                actions[row_id] = None
                confs[row_id] = 0.0
                ndesc[row_id] = None
                methods[row_id] = "unmatched"
                provs[row_id] = "bbref_only"
                continue
            dt = abs(float(m["_event_elapsed"]) - float(m["_nba_elapsed"]))
            conf = max(0.0, 1.0 - dt / tolerance)
            actions[row_id] = m.get("nba_action_number")
            confs[row_id] = round(conf, 4)
            ndesc[row_id] = m.get("description")
            methods[row_id] = "merge_asof_nearest_type_filtered" if used_compatible else "merge_asof_nearest_period"
            provs[row_id] = m.get("nba_pbp_provenance") or m.get("data_provenance") or "missing"

    out["nba_game_id"] = nba_game_id
    out["nba_action_number"] = out["_event_row"].map(actions)
    out["nba_alignment_confidence"] = out["_event_row"].map(confs).fillna(0.0)
    out["nba_description_aligned"] = out["_event_row"].map(ndesc)
    out["nba_alignment_method"] = out["_event_row"].map(methods).fillna("unmatched")
    out["nba_enrichment_provenance"] = out["_event_row"].map(provs).fillna("bbref_only").apply(normalize_nba_provenance)
    return out.drop(columns=[c for c in out.columns if c.startswith("_")], errors="ignore")


def fetch_public_tracking_aggregates(season_label: str, season_type: str = "Regular Season") -> pd.DataFrame:
    if leaguedashptstats is None:
        return pd.DataFrame()
    pt_types = [
        "Possessions", "SpeedDistance", "CatchShoot", "PullUpShot", "Defense",
        "Drives", "Passing", "ElbowTouch", "PostTouch", "PaintTouch", "Efficiency", "Rebounding"
    ]
    rows = []
    for pt in pt_types:
        try:
            obj = leaguedashptstats.LeagueDashPtStats(
                season=season_label,
                season_type_all_star=season_type,
                pt_measure_type=pt,
                per_mode_simple="PerGame",
                headers=NBA_HEADERS,
                timeout=60,
            )
            dfs = obj.get_data_frames()
            if dfs:
                df = dfs[0].copy()
                df.insert(0, "pt_measure_type", pt)
                df.insert(0, "season_type", season_type)
                df.insert(0, "season", season_label)
                rows.append(df)
            print(f"tracking aggregate ok: {pt}")
        except Exception as e:
            print(f"WARN: tracking aggregate failed: {pt}: {e}")
        time.sleep(1.0)
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()


# =============================================================================
# Coverage ingestion
# =============================================================================

def run_cmd(cmd: List[str]) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, shell=False)


def parse_vtt_timestamp(ts: str) -> Optional[float]:
    ts = ts.strip().replace(",", ".")
    parts = ts.split(":")
    try:
        if len(parts) == 3:
            h, m, s = parts
            return int(h) * 3600 + int(m) * 60 + float(s)
        if len(parts) == 2:
            m, s = parts
            return int(m) * 60 + float(s)
    except Exception:
        return None
    return None


def parse_vtt_file(path: str, source: CoverageSource) -> List[TranscriptSegment]:
    text = Path(path).read_text(encoding="utf-8", errors="ignore")
    blocks = re.split(r"\n\s*\n", text)
    out: List[TranscriptSegment] = []
    for block in blocks:
        lines = [l.strip() for l in block.splitlines() if l.strip()]
        tl = next((l for l in lines if "-->" in l), None)
        if not tl:
            continue
        left, right = tl.split("-->", 1)
        start = parse_vtt_timestamp(left)
        end = parse_vtt_timestamp(right.split()[0])
        caption_lines = [l for l in lines if "-->" not in l and not l.lower().startswith("webvtt") and not l.isdigit()]
        cap = re.sub(r"<[^>]+>", "", clean_text(" ".join(caption_lines)))
        if cap:
            out.append(TranscriptSegment(source.source_id, source.source_type, start, end, cap, confidence=0.75))
    return out


def download_subtitles(video_url: str, out_dir: Path, source_id: str) -> List[Path]:
    ensure_dir(out_dir)
    output_template = str(out_dir / f"{source_id}.%(ext)s")
    cmd = ["yt-dlp", "--skip-download", "--write-subs", "--write-auto-subs", "--sub-langs", "en.*", "--sub-format", "vtt/srv3/ttml/best", "-o", output_template, video_url]
    res = run_cmd(cmd)
    if res.returncode != 0:
        raise RuntimeError(res.stderr)
    return list(out_dir.glob(f"{source_id}*.vtt"))


def download_audio(video_url: str, out_dir: Path, source_id: str) -> Path:
    ensure_dir(out_dir)
    out_base = str(out_dir / source_id)
    cmd = ["yt-dlp", "-x", "--audio-format", "mp3", video_url, "-o", out_base]
    res = run_cmd(cmd)
    if res.returncode != 0:
        raise RuntimeError(res.stderr)
    matches = list(out_dir.glob(f"{source_id}*.mp3"))
    if not matches:
        raise FileNotFoundError(f"No mp3 created for {source_id}")
    return matches[0]


def transcribe_audio(path: str, source: CoverageSource, model_name: str = "base") -> List[TranscriptSegment]:
    if whisper is None:
        raise RuntimeError("openai-whisper is not installed. pip install openai-whisper")
    model = whisper.load_model(model_name)
    result = model.transcribe(path, word_timestamps=False)
    out = []
    for seg in result.get("segments", []):
        txt = clean_text(seg.get("text", ""))
        if txt:
            out.append(TranscriptSegment(source.source_id, source.source_type, float(seg.get("start", 0)), float(seg.get("end", 0)), txt, confidence=WHISPER_SEGMENT_SOURCE_PRIOR))
    return out


def load_text_segments(path: str, source: CoverageSource) -> List[TranscriptSegment]:
    raw = clean_text(Path(path).read_text(encoding="utf-8", errors="ignore"))
    matches = list(re.finditer(r"\[(\d{1,2}:\d{2}(?::\d{2})?)\]", raw))
    if not matches:
        return [TranscriptSegment(source.source_id, source.source_type, None, None, raw, confidence=0.58)] if raw else []
    out = []
    for i, m in enumerate(matches):
        start = parse_vtt_timestamp(m.group(1))
        end_pos = matches[i + 1].start() if i + 1 < len(matches) else len(raw)
        end = parse_vtt_timestamp(matches[i + 1].group(1)) if i + 1 < len(matches) else None
        txt = clean_text(raw[m.end():end_pos])
        if txt:
            out.append(TranscriptSegment(source.source_id, source.source_type, start, end, txt, confidence=0.66))
    return out


def extract_article_text(url: str, source: CoverageSource, max_chars: int = 20000) -> List[TranscriptSegment]:
    if BeautifulSoup is None:
        raise RuntimeError("beautifulsoup4 is not installed")
    resp = requests.get(url, headers={"User-Agent": NBA_HEADERS["User-Agent"]}, timeout=30)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")
    for tag in soup(["script", "style", "noscript", "svg", "nav", "header", "footer", "aside", "form", "button"]):
        tag.decompose()

    # Prefer the densest article/main body instead of concatenating all wrappers;
    # many sites put nav modules, recirculation links, and ad copy inside <main>.
    blocks = []
    for c in soup.find_all(["article", "main"]):
        paras = [clean_text(p.get_text(" ")) for p in c.find_all(["p", "li", "blockquote"])]
        paras = [x for x in paras if len(x) >= 30]
        text = clean_text(" ".join(paras))
        if text:
            blocks.append(text)
    if blocks:
        text = max(blocks, key=len)
    else:
        paras = [clean_text(p.get_text(" ")) for p in soup.find_all(["p", "li", "blockquote"])]
        paras = [x for x in paras if len(x) >= 30]
        text = " ".join(paras)
    text = clean_text(text)[:max_chars]
    return [TranscriptSegment(source.source_id, source.source_type, None, None, text, confidence=0.55)] if text else []


def ingest_coverage_source(source: CoverageSource, work_dir: Path) -> List[TranscriptSegment]:
    if source.local_path:
        p = Path(source.local_path)
        if not p.exists():
            raise FileNotFoundError(str(p))
        ext = p.suffix.lower()
        if ext == ".vtt":
            return parse_vtt_file(str(p), source)
        if ext in {".txt", ".md", ".srt"}:
            return load_text_segments(str(p), source)
        if ext in {".mp3", ".wav", ".m4a", ".mp4", ".mkv", ".mov"}:
            return transcribe_audio(str(p), source)
    if source.url:
        parsed = urlparse(source.url)
        looks_video = any(host in parsed.netloc for host in ["youtube.com", "youtu.be", "nba.com", "twitch.tv"])
        if source.source_type in {SOURCE_WRITTEN_COVERAGE, SOURCE_FILM_BREAKDOWN} and not looks_video:
            return extract_article_text(source.url, source)
        # captions first, audio fallback
        try:
            vtts = download_subtitles(source.url, work_dir, source.source_id)
            segs: List[TranscriptSegment] = []
            for v in vtts:
                segs.extend(parse_vtt_file(str(v), source))
            if segs:
                return segs
        except Exception as e:
            print(f"WARN: subtitle ingest failed for {source.source_id}: {e}")
        audio = download_audio(source.url, work_dir, source.source_id)
        return transcribe_audio(str(audio), source)
    return []


def source_weight(source_type: str) -> float:
    return {
        SOURCE_ALT_BROADCAST: 1.08,
        SOURCE_CLOSED_CAPTIONS: 1.00,
        SOURCE_BROADCAST_TRANSCRIPT: 0.92,
        SOURCE_WRITTEN_COVERAGE: 0.78,
        SOURCE_FILM_BREAKDOWN: 1.15,
        SOURCE_PBP_DESCRIPTION: 0.75,
    }.get(source_type, 0.85)


def extract_tactical_labels_from_text(text: str, sw: float = 1.0) -> List[Dict[str, Any]]:
    text_l = clean_text(text).lower()
    labels = []
    for label, cfg in TACTICAL_PATTERNS.items():
        pos = any(re.search(p, text_l) for p in cfg["positive"])
        neg = any(re.search(n, text_l) for n in cfg.get("negative", []))
        if pos and not neg:
            labels.append({"label_family": cfg["family"], "label_value": label, "confidence": round(min(0.98, cfg["base_confidence"] * sw), 4)})
        elif pos and neg:
            labels.append({"label_family": cfg["family"], "label_value": label, "confidence": round(min(0.40, cfg["base_confidence"] * 0.45 * sw), 4)})
    return labels


def _event_priority_for_label(e: pd.Series, lab: Dict[str, Any]) -> int:
    family = str(lab.get("label_family", ""))
    value = str(lab.get("label_value", ""))

    if is_true(e.get("is_sub")) or is_true(e.get("is_timeout")):
        return -5
    if family == "rebounding" or value in {"tip_out", "box_out"}:
        if is_true(e.get("is_rebound")):
            return 10
        if is_true(e.get("is_shot")):
            return 5
    if family in {"rim_pressure", "closeout", "deception", "advantage_conversion"}:
        if is_true(e.get("is_shot")):
            return 10
        if is_true(e.get("is_foul")) or is_true(e.get("is_turnover")):
            return 7
    if family in {"pass_type", "set_action", "advantage_creation", "attention", "coverage", "help"}:
        if is_true(e.get("is_shot")) or is_true(e.get("is_turnover")):
            return 8
        if is_true(e.get("is_foul")) or is_true(e.get("is_rebound")):
            return 5
    if is_true(e.get("is_shot")) or is_true(e.get("is_turnover")):
        return 4
    if is_true(e.get("is_foul")) or is_true(e.get("is_rebound")):
        return 3
    return 1


def _nearest_compatible_event(near: pd.DataFrame, lab: Dict[str, Any]) -> Optional[pd.Series]:
    if near.empty:
        return None
    cand = near.copy()
    cand["_label_priority"] = cand.apply(lambda e: _event_priority_for_label(e, lab), axis=1)
    usable = cand[cand["_label_priority"] >= 0].copy()
    if usable.empty:
        usable = cand.copy()
    usable = usable.sort_values(["_label_priority", "_dt"], ascending=[False, True])
    return usable.iloc[0]


def align_segments_to_events(
    bbref_game_id: str,
    nba_game_id: Optional[str],
    events: pd.DataFrame,
    segments: List[TranscriptSegment],
    source: CoverageSource,
    window_seconds: float = 8.0,
) -> List[TacticalLabel]:
    out: List[TacticalLabel] = []
    sw = source_weight(source.source_type)
    timed = [s for s in segments if s.start_seconds is not None or s.end_seconds is not None]
    untimed = [s for s in segments if s.start_seconds is None and s.end_seconds is None]

    event_pool = events.copy()
    if "game_elapsed_seconds" in event_pool.columns:
        event_pool = event_pool[pd.notna(event_pool["game_elapsed_seconds"])].copy()
    else:
        event_pool = pd.DataFrame()

    for seg in timed:
        mid = seg.start_seconds if seg.end_seconds is None else ((seg.start_seconds or seg.end_seconds or 0) + seg.end_seconds) / 2
        target_elapsed = float(mid or 0) - float(source.broadcast_offset_seconds or 0)
        if not event_pool.empty:
            near = event_pool.copy()
            near["_dt"] = (near["game_elapsed_seconds"].astype(float) - target_elapsed).abs()
            near = near[near["_dt"] <= window_seconds].sort_values("_dt")
        else:
            near = pd.DataFrame()

        labs = extract_tactical_labels_from_text(seg.text, sw * seg.confidence)
        for lab in labs:
            e = _nearest_compatible_event(near, lab)
            if e is None:
                continue
            dt = float(e.get("_dt", 0.0) or 0.0)
            distance_weight = max(0.70, 1.0 - min(dt, window_seconds) / max(window_seconds, 1.0) * 0.30)
            out.append(TacticalLabel(
                bbref_game_id=bbref_game_id,
                nba_game_id=nba_game_id,
                event_id=e.get("event_id"),
                event_index=maybe_int(e.get("event_index")),
                true_possession_id=e.get("true_possession_id"),
                period=maybe_int(e.get("period")),
                clock=e.get("clock"),
                source_id=seg.source_id,
                source_type=seg.source_type,
                label_family=lab["label_family"],
                label_value=lab["label_value"],
                confidence=round(float(lab["confidence"]) * distance_weight, 4),
                evidence_text=seg.text[:500],
                evidence_start_seconds=seg.start_seconds,
                evidence_end_seconds=seg.end_seconds,
            ))

    for seg in untimed:
        labs = extract_tactical_labels_from_text(seg.text, sw * seg.confidence)
        for lab in labs:
            out.append(TacticalLabel(
                bbref_game_id=bbref_game_id,
                nba_game_id=nba_game_id,
                event_id=None,
                event_index=None,
                true_possession_id=None,
                period=None,
                clock=None,
                source_id=seg.source_id,
                source_type=seg.source_type,
                label_family=lab["label_family"],
                label_value=lab["label_value"],
                confidence=lab["confidence"],
                evidence_text=seg.text[:500],
            ))
    return out


def pbp_description_labels(bbref_game_id: str, nba_game_id: Optional[str], events: pd.DataFrame) -> List[TacticalLabel]:
    out = []
    if events.empty:
        return out
    for _, e in events.iterrows():
        labs = extract_tactical_labels_from_text(e.get("event_text", ""), source_weight(SOURCE_PBP_DESCRIPTION))
        for lab in labs:
            out.append(TacticalLabel(
                bbref_game_id=bbref_game_id,
                nba_game_id=nba_game_id,
                event_id=e.get("event_id"),
                event_index=maybe_int(e.get("event_index")),
                true_possession_id=e.get("true_possession_id"),
                period=maybe_int(e.get("period")),
                clock=e.get("clock"),
                source_id="bbref_pbp_description",
                source_type=SOURCE_PBP_DESCRIPTION,
                label_family=lab["label_family"],
                label_value=lab["label_value"],
                confidence=lab["confidence"],
                evidence_text=str(e.get("event_text", ""))[:500],
            ))
    return out


def load_sources_json(path: Optional[str]) -> List[CoverageSource]:
    if not path:
        return []
    p = Path(path)
    if not p.exists():
        return []
    data = json.loads(p.read_text(encoding="utf-8"))
    raw_sources = data.get("sources", data if isinstance(data, list) else [])
    return [CoverageSource(**s) for s in raw_sources]


# =============================================================================
# NBA sidecar cache / crosswalk cache / failed-game queue
# =============================================================================

def _master_out_dir_from_game_out_dir(game_out_dir: Path) -> Path:
    return Path(game_out_dir).parent


def _crosswalk_cache_path(master_out_dir: str | Path) -> Path:
    return Path(master_out_dir) / "nba_game_id_crosswalk_cache.csv"


def load_cached_nba_game_id(bbref_game_id: str, game_out_dir: str | Path) -> Optional[str]:
    game_out = Path(game_out_dir)
    report_path = game_out / "report.json"
    try:
        if report_path.exists():
            data = json.loads(report_path.read_text(encoding="utf-8"))
            gid = data.get("nba_game_id")
            if gid and str(gid).lower() not in {"none", "nan", "null"}:
                return str(gid)
    except Exception:
        pass
    cache_path = _crosswalk_cache_path(_master_out_dir_from_game_out_dir(game_out))
    try:
        if cache_path.exists():
            df = pd.read_csv(cache_path)
            row = df[df.get("bbref_game_id", pd.Series(dtype=str)).astype(str) == str(bbref_game_id)]
            if not row.empty:
                gid = row.iloc[-1].get("nba_game_id")
                if gid and str(gid).lower() not in {"none", "nan", "null"}:
                    return str(gid)
    except Exception:
        pass
    return None


def save_cached_nba_game_id(bbref_game_id: str, nba_game_id: Optional[str], game_out_dir: str | Path, source: str) -> None:
    if not nba_game_id:
        return
    path = _crosswalk_cache_path(_master_out_dir_from_game_out_dir(Path(game_out_dir)))
    try:
        ensure_dir(path.parent)
        old = pd.read_csv(path) if path.exists() else pd.DataFrame()
        old = old[old.get("bbref_game_id", pd.Series(dtype=str)).astype(str) != str(bbref_game_id)] if not old.empty else old
        row = pd.DataFrame([{
            "bbref_game_id": bbref_game_id,
            "nba_game_id": str(nba_game_id),
            "source": source,
            "cached_at_utc": pd.Timestamp.utcnow().isoformat(),
        }])
        pd.concat([old, row], ignore_index=True).to_csv(path, index=False)
    except Exception as e:
        print(f"WARN: could not save NBA game id cache: {e}")


def read_cached_sidecar(game_out_dir: str | Path, filename: str, provenance_col: Optional[str] = None) -> pd.DataFrame:
    if not _cache_read_enabled():
        return pd.DataFrame()
    path = Path(game_out_dir) / filename
    if not path.exists():
        return pd.DataFrame()
    try:
        df = read_table(path)
        if provenance_col and not df.empty:
            original_col = f"{provenance_col}_original"
            if provenance_col in df.columns and original_col not in df.columns:
                df[original_col] = df[provenance_col]
            df[provenance_col] = "cache"
            if "data_provenance" in df.columns:
                df["data_provenance_original"] = df.get("data_provenance")
                df["data_provenance"] = "cache"
        return df
    except Exception as e:
        log_nba_api_failure("SidecarCache", None, e, {"filename": filename})
        return pd.DataFrame()


def should_skip_network_for_missing_sidecar() -> bool:
    return _cache_network_disabled()


def failed_games_queue_path(out_dir: str | Path) -> Path:
    return Path(out_dir) / "failed_games_queue.csv"


def append_failed_game_queue(out_dir: str | Path, bbref_game_id: str, error: Any, stage: str = "process_available_games") -> None:
    path = failed_games_queue_path(out_dir)
    try:
        ensure_dir(path.parent)
        old = pd.read_csv(path) if path.exists() else pd.DataFrame()
        attempts = 1
        if not old.empty and "bbref_game_id" in old.columns:
            prev = old[old["bbref_game_id"].astype(str) == str(bbref_game_id)]
            if not prev.empty and "attempts" in prev.columns:
                attempts = int(prev.iloc[-1].get("attempts", 0) or 0) + 1
            old = old[old["bbref_game_id"].astype(str) != str(bbref_game_id)]
        row = pd.DataFrame([{
            "bbref_game_id": bbref_game_id,
            "stage": stage,
            "error": str(error)[:1000],
            "failed_at_utc": pd.Timestamp.utcnow().isoformat(),
            "attempts": attempts,
        }])
        pd.concat([old, row], ignore_index=True).to_csv(path, index=False)
    except Exception as e:
        print(f"WARN: could not append failed-game queue: {e}")


def clear_failed_game_queue_entry(out_dir: str | Path, bbref_game_id: str) -> None:
    path = failed_games_queue_path(out_dir)
    if not path.exists():
        return
    try:
        df = pd.read_csv(path)
        if "bbref_game_id" not in df.columns:
            return
        df = df[df["bbref_game_id"].astype(str) != str(bbref_game_id)]
        if df.empty:
            path.unlink(missing_ok=True)
        else:
            df.to_csv(path, index=False)
    except Exception:
        pass


def load_failed_game_queue(out_dir: str | Path) -> List[str]:
    path = failed_games_queue_path(out_dir)
    if not path.exists():
        return []
    try:
        df = pd.read_csv(path)
        if "bbref_game_id" not in df.columns:
            return []
        return [str(x) for x in df["bbref_game_id"].dropna().drop_duplicates().tolist()]
    except Exception:
        return []


def run_nba_endpoint_healthcheck(sample_game_id: str = "0022500001") -> Dict[str, Any]:
    """Check safe/documented NBA routes before a long run."""
    results: Dict[str, Any] = {"sample_game_id": sample_game_id, "checked_at_utc": pd.Timestamp.utcnow().isoformat()}
    schedule, schedule_route = fetch_nba_schedule_cdn()
    results["schedule_cdn_route"] = schedule_route
    results["schedule_cdn_rows"] = int(len(schedule)) if schedule is not None else 0
    pbp = fetch_nba_pbp_live_cdn(sample_game_id)
    results["live_cdn_pbp_rows"] = int(len(pbp)) if pbp is not None else 0
    results["ok"] = bool(results["schedule_cdn_rows"] > 0 or results["live_cdn_pbp_rows"] > 0)
    return results


# =============================================================================
# Game-level pipeline
# =============================================================================

def process_game(
    bbref_game_id: str,
    bbref_data_dir: str | Path,
    out_dir: str | Path,
    season_label: str = "2025-26",
    sources: Optional[List[CoverageSource]] = None,
    include_nba: bool = True,
    include_videoevents: bool = False,
    work_dir: Optional[str | Path] = None,
) -> Dict[str, Any]:
    out_dir = ensure_dir(Path(out_dir) / bbref_game_id)
    set_nba_api_failure_log(Path(out_dir).parent / "nba_api_failures.csv")
    set_nba_network_cache_dir(Path(out_dir).parent / "nba_network_cache")
    work_dir = ensure_dir(work_dir or (out_dir / "coverage_work"))

    game = load_bbref_game(bbref_data_dir, bbref_game_id)
    raw = game["raw_pbp"]
    tp = game["true_possessions"]
    lineups = game["lineups"]

    if raw.empty:
        raise RuntimeError(f"Missing BBRef raw PBP for {bbref_game_id}. Run with --scrape-bbref first.")

    events = normalize_clean_game_events(raw)
    possessions = normalize_possession_frames(tp, raw)
    events = attach_possession_ids_to_events(events, possessions)
    event_lineups = build_event_lineups(events, lineups)
    possession_lineups = build_possession_lineups(possessions, lineups)
    touches = build_observed_touch_chain(events)

    # NBA ID crosswalk and sidecars
    home = str(raw["home_team"].iloc[0]) if "home_team" in raw.columns and not raw.empty else bbref_game_id[-3:]
    away = str(raw["away_team"].iloc[0]) if "away_team" in raw.columns and not raw.empty else None
    nba_game_id = None
    nba_pbp = pd.DataFrame()
    shotchart = pd.DataFrame()
    winprob = pd.DataFrame()
    video_df = pd.DataFrame()

    if include_nba:
        cached_gid = load_cached_nba_game_id(bbref_game_id, out_dir)
        if cached_gid:
            nba_game_id = cached_gid
        elif not _cache_network_disabled():
            nba_game_id = resolve_nba_game_id_from_scoreboard(
                bbref_game_id,
                home_team_bbref=home,
                away_team_bbref=away,
                log_path=Path(out_dir).parent / "nba_game_id_failures.csv",
            )
            save_cached_nba_game_id(bbref_game_id, nba_game_id, out_dir, source="scoreboard_or_schedule_cdn")
        else:
            log_nba_api_failure("Crosswalk", None, "cache_read_mode_no_cached_nba_game_id", {"bbref_game_id": bbref_game_id})

        if nba_game_id:
            NBA_REQUEST_BUDGET.reset_game(nba_game_id)

            nba_pbp = read_cached_sidecar(out_dir, "nba_playbyplayv3_sidecar.csv", "nba_pbp_provenance")
            if nba_pbp.empty and not should_skip_network_for_missing_sidecar():
                nba_pbp = fetch_nba_pbp_v3(nba_game_id)

            shotchart = read_cached_sidecar(out_dir, "nba_shotchartdetail_sidecar.csv", "shotchart_provenance")
            if shotchart.empty and not should_skip_network_for_missing_sidecar():
                shotchart = fetch_nba_shotchart(nba_game_id, season_label=season_label)

            winprob = read_cached_sidecar(out_dir, "nba_winprobabilitypbp_sidecar.csv", "win_probability_provenance")
            if winprob.empty and not should_skip_network_for_missing_sidecar():
                winprob = fetch_nba_win_probability_pbp(nba_game_id)

            if not nba_pbp.empty:
                events = align_bbref_events_to_nba(events, nba_pbp)
            else:
                events = events.assign(
                    nba_game_id=nba_game_id,
                    nba_action_number=None,
                    nba_alignment_confidence=0.0,
                    nba_description_aligned=None,
                    nba_alignment_method="unmatched",
                    nba_enrichment_provenance="missing" if not _cache_network_disabled() else "bbref_only",
                )

            # Win prob is optional and endpoint-fragile; the fallback LI layer still
            # runs even when the official sidecar is empty.
            events = add_win_probability_features(events, winprob=winprob)

            if include_videoevents and not nba_pbp.empty:
                video_df = read_cached_sidecar(out_dir, "nba_videoevents_sidecar.csv", "videoevents_provenance")
                if video_df.empty and not should_skip_network_for_missing_sidecar():
                    video_df = fetch_videoevents_for_nba_pbp(nba_game_id, nba_pbp)
        else:
            print(f"WARN: no NBA game ID resolved for {bbref_game_id}; NBA sidecars skipped.")
            events = events.assign(nba_enrichment_provenance="bbref_only")
            events = add_win_probability_features(events, winprob=pd.DataFrame())
    else:
        events = events.assign(nba_enrichment_provenance="bbref_only")
        events = add_win_probability_features(events, winprob=pd.DataFrame())

    # Advanced text/geometry/context features. These are source/confidence tagged;
    # exact x/y comes from NBA sidecars when available, otherwise stays coarse/null.
    events = add_advanced_event_features(events, nba_pbp=nba_pbp, shotchart=shotchart)

    # Coverage labels
    sources = sources or []
    # Filter sources for this game if game ids are supplied.
    sources_for_game = []
    for s in sources:
        if s.bbref_game_id and s.bbref_game_id != bbref_game_id:
            continue
        if s.nba_game_id and nba_game_id and s.nba_game_id != nba_game_id:
            continue
        sources_for_game.append(s)

    segments: List[TranscriptSegment] = []
    labels: List[TacticalLabel] = pbp_description_labels(bbref_game_id, nba_game_id, events)
    for s in sources_for_game:
        try:
            segs = ingest_coverage_source(s, work_dir=work_dir)
            segments.extend(segs)
            labels.extend(align_segments_to_events(bbref_game_id, nba_game_id, events, segs, s))
        except Exception as e:
            print(f"WARN: coverage source failed {s.source_id}: {e}")

    tactical_labels = pd.DataFrame([asdict(l) for l in labels]) if labels else pd.DataFrame()
    transcript_segments = pd.DataFrame([asdict(s) for s in segments]) if segments else pd.DataFrame()

    # Possession proxy labels from event/source labels.
    possession_proxy = build_possession_proxy_labels(tactical_labels)
    event_advanced_context = build_event_advanced_context(events)

    # Write outputs
    write_csv(events, out_dir / "clean_game_events.csv")
    write_csv(possessions, out_dir / "possession_frames.csv")
    write_csv(event_lineups, out_dir / "event_lineups.csv")
    write_csv(possession_lineups, out_dir / "possession_lineups.csv")
    write_csv(touches, out_dir / "observed_touch_chain.csv")
    write_csv(tactical_labels, out_dir / "tactical_labels.csv")
    write_csv(transcript_segments, out_dir / "transcript_segments.csv")
    write_csv(possession_proxy, out_dir / "possession_proxy_labels.csv")
    write_csv(event_advanced_context, out_dir / "event_advanced_context.csv")
    if not nba_pbp.empty: write_csv(nba_pbp, out_dir / "nba_playbyplayv3_sidecar.csv")
    if not shotchart.empty: write_csv(shotchart, out_dir / "nba_shotchartdetail_sidecar.csv")
    if not winprob.empty: write_csv(winprob, out_dir / "nba_winprobabilitypbp_sidecar.csv")
    if not video_df.empty: write_csv(video_df, out_dir / "nba_videoevents_sidecar.csv")

    report = {
        "bbref_game_id": bbref_game_id,
        "nba_game_id": nba_game_id,
        "raw_events": int(len(raw)),
        "clean_events": int(len(events)),
        "true_possessions": int(len(possessions)),
        "lineup_stints": int(len(lineups)),
        "event_lineups": int(len(event_lineups)),
        "possession_lineups": int(len(possession_lineups)),
        "observed_touch_rows": int(len(touches)),
        "tactical_labels": int(len(tactical_labels)),
        "event_advanced_context_rows": int(len(event_advanced_context)),
        "transcript_segments": int(len(transcript_segments)),
        "nba_pbp_rows": int(len(nba_pbp)),
        "shotchart_rows": int(len(shotchart)),
        "winprobability_rows": int(len(winprob)),
        "winprobability_available_events": int(events.get("win_probability_available", pd.Series(dtype=int)).fillna(0).astype(int).sum()) if "win_probability_available" in events.columns else 0,
        "garbage_time_flagged_events": int(events.get("flag_is_low_leverage_garbage_time", pd.Series(dtype=int)).fillna(0).astype(int).sum()) if "flag_is_low_leverage_garbage_time" in events.columns else 0,
        "videoevents_rows": int(len(video_df)),
        "event_data_provenance_counts": events["event_data_provenance"].value_counts(dropna=False).to_dict() if "event_data_provenance" in events.columns else {},
        "nba_enrichment_provenance_counts": events["nba_enrichment_provenance"].value_counts(dropna=False).to_dict() if "nba_enrichment_provenance" in events.columns else {},
        "win_probability_provenance_counts": events["win_probability_data_provenance"].value_counts(dropna=False).to_dict() if "win_probability_data_provenance" in events.columns else {},
        "coverage_sources_used": [asdict(s) for s in sources_for_game],
        "bbref_meta": game.get("meta", {}),
    }
    (out_dir / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def build_possession_proxy_labels(labels: pd.DataFrame) -> pd.DataFrame:
    if labels.empty or "true_possession_id" not in labels.columns:
        return pd.DataFrame()
    rows = []
    sub = labels[pd.notna(labels["true_possession_id"])]
    if sub.empty:
        return pd.DataFrame()
    for (gid, pid), g in sub.groupby(["bbref_game_id", "true_possession_id"]):
        rec = {"bbref_game_id": gid, "possession_id": pid, "label_sources": json.dumps(g[["source_id", "source_type", "label_family", "label_value", "confidence"]].to_dict(orient="records"))}
        for label_value, gg in g.groupby("label_value"):
            col = f"p_{label_value}"
            # Noisy evidence combiner: max confidence, capped.
            rec[col] = round(min(0.98, float(gg["confidence"].max())), 4)
        rec["max_label_confidence"] = round(float(g["confidence"].max()), 4)
        rec["label_count"] = int(len(g))
        rows.append(rec)
    return pd.DataFrame(rows)


# =============================================================================
# Season-level orchestration
# =============================================================================

def process_available_games(
    bbref_data_dir: str | Path,
    out_dir: str | Path,
    season_label: str,
    sources: List[CoverageSource],
    include_nba: bool,
    include_videoevents: bool,
    game: Optional[str] = None,
    limit: Optional[int] = None,
    resume_failed: bool = False,
) -> Dict[str, Any]:
    if resume_failed:
        games = load_failed_game_queue(out_dir)
        if not games:
            print("No failed-game queue found; nothing to resume.")
            games = []
    else:
        games = [game] if game else available_bbref_games(bbref_data_dir)
    if limit is not None:
        games = games[:limit]
    reports = []
    failures = []
    for i, gid in enumerate(games, 1):
        try:
            print(f"[{i}/{len(games)}] processing {gid}")
            rep = process_game(
                bbref_game_id=gid,
                bbref_data_dir=bbref_data_dir,
                out_dir=out_dir,
                season_label=season_label,
                sources=sources,
                include_nba=include_nba,
                include_videoevents=include_videoevents,
            )
            reports.append(rep)
            clear_failed_game_queue_entry(out_dir, gid)
        except Exception as e:
            print(f"FAIL {gid}: {e}")
            failures.append({"bbref_game_id": gid, "error": str(e)})
            append_failed_game_queue(out_dir, gid, e)
    summary = {"processed": len(reports), "failures": len(failures), "failure_rows": failures, "reports": reports, "failed_games_queue": str(failed_games_queue_path(out_dir))}
    ensure_dir(out_dir)
    Path(out_dir, "season_report.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    if reports:
        write_csv(pd.DataFrame(reports), Path(out_dir) / "season_report.csv")
    if failures:
        write_csv(pd.DataFrame(failures), Path(out_dir) / "season_failures.csv")
    return summary


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--season-year", type=int, default=2026, help="BBRef season year; 2026 == 2025-26")
    ap.add_argument("--season-label", default="2025-26", help="NBA API season label")
    ap.add_argument("--bbref-data-dir", default="./data_2025_26_bbref")
    ap.add_argument("--out", default="./data_2025_26_master")
    ap.add_argument("--sources", default=None, help="JSON file with coverage sources")
    ap.add_argument("--game", default=None, help="Single BBRef game id, e.g. 202510220LAL")
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--scrape-bbref", action="store_true")
    ap.add_argument("--enrich", action="store_true")
    ap.add_argument("--enrich-only", action="store_true")
    ap.add_argument("--no-nba-api", action="store_true")
    ap.add_argument("--videoevents", action="store_true", help="Try NBA VideoEvents sidecar. Slower.")
    ap.add_argument("--fetch-tracking", action="store_true", help="Pull LeagueDashPtStats public tracking aggregates once.")
    ap.add_argument("--resume-failed", action="store_true", help="Process only games in the local failed_games_queue.csv.")
    ap.add_argument("--require-nba-healthcheck", action="store_true", help="Run safe NBA CDN healthcheck before enrichment and abort if unavailable.")
    ap.add_argument("--nba-healthcheck-only", action="store_true", help="Run the safe NBA endpoint healthcheck and exit.")
    ap.add_argument("--healthcheck-game-id", default="0022500001", help="Sample NBA GameID for CDN play-by-play healthcheck.")
    ap.add_argument("--delay", type=float, default=3.5)
    ap.add_argument("--jitter", type=float, default=1.5)
    ap.add_argument("--no-save-html", action="store_true")
    args = ap.parse_args()

    if args.season_year != 2026:
        print("WARN: this combined runner is tuned for 2025-26. Proceeding anyway.")

    scrape_report = None
    if args.scrape_bbref and not args.enrich_only:
        scrape_report = scrape_bbref_2025_26(
            data_dir=args.bbref_data_dir,
            game=args.game,
            limit=args.limit,
            delay=args.delay,
            jitter=args.jitter,
            save_html=not args.no_save_html,
        )
        print(json.dumps(scrape_report, indent=2))

    sources = load_sources_json(args.sources)

    if args.nba_healthcheck_only:
        set_nba_api_failure_log(Path(args.out) / "nba_api_failures.csv")
        set_nba_network_cache_dir(Path(args.out) / "nba_network_cache")
        result = run_nba_endpoint_healthcheck(args.healthcheck_game_id)
        print(json.dumps(result, indent=2))
        return

    need_healthcheck = args.require_nba_healthcheck or _env_bool("GINGEBALL_NBA_REQUIRE_HEALTHCHECK", False)
    if need_healthcheck and not args.no_nba_api and (args.enrich or args.enrich_only or not args.scrape_bbref):
        set_nba_api_failure_log(Path(args.out) / "nba_api_failures.csv")
        set_nba_network_cache_dir(Path(args.out) / "nba_network_cache")
        result = run_nba_endpoint_healthcheck(args.healthcheck_game_id)
        print(json.dumps({"nba_healthcheck": result}, indent=2))
        if not result.get("ok"):
            raise RuntimeError("NBA healthcheck failed and --require-nba-healthcheck was set.")

    summary = None
    if args.enrich or args.enrich_only or not args.scrape_bbref:
        summary = process_available_games(
            bbref_data_dir=args.bbref_data_dir,
            out_dir=args.out,
            season_label=args.season_label,
            sources=sources,
            include_nba=not args.no_nba_api,
            include_videoevents=args.videoevents,
            game=args.game,
            limit=args.limit,
            resume_failed=args.resume_failed,
        )
        print(json.dumps({"processed": summary["processed"], "failures": summary["failures"]}, indent=2))

    if args.fetch_tracking:
        tracking = fetch_public_tracking_aggregates(args.season_label)
        if not tracking.empty:
            write_csv(tracking, Path(args.out) / "public_tracking_aggregates_leaguedashptstats.csv")
            print(f"wrote tracking aggregates: {len(tracking)} rows")
        else:
            print("No tracking aggregate rows fetched.")


if __name__ == "__main__":
    main()
