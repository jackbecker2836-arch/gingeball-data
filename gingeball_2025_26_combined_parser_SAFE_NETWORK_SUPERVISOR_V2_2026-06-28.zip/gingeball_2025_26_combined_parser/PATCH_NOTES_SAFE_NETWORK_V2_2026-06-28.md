# Patch notes — Safe Network Supervisor v2 — 2026-06-28

## Added

- Bring-your-own authorized proxy support through env vars:
  - `GINGEBALL_NBA_PROXY`
  - `GINGEBALL_NBA_HTTP_PROXY`
  - `GINGEBALL_NBA_HTTPS_PROXY`
- Hard request budget:
  - `GINGEBALL_NBA_MAX_CALLS_PER_MINUTE`, default `40`
  - `GINGEBALL_NBA_MAX_CALLS_PER_GAME`, default `120`
  - `GINGEBALL_NBA_COOLDOWN_AFTER_BLOCK_SECONDS`, default `90`
- Cache-first sidecar reuse:
  - Existing NBA sidecars are loaded before any NBA network call.
  - `GINGEBALL_NBA_CACHE_MODE=read` makes enrichment cache-only/offline.
- NBA GameID crosswalk cache:
  - `nba_game_id_crosswalk_cache.csv`
- Local failed-game resume queue:
  - `failed_games_queue.csv`
  - `--resume-failed`
- Safe endpoint healthcheck:
  - `--nba-healthcheck-only`
  - `--require-nba-healthcheck`
  - `--healthcheck-game-id`
- Normalized provenance columns:
  - `event_data_provenance`
  - `nba_enrichment_provenance`
  - `win_probability_data_provenance`
  - sidecar-level `*_provenance` columns

## Provenance vocabulary

All normalized provenance uses one of:

- `stats_api`
- `live_cdn`
- `cache`
- `bbref_only`
- `missing`

## Kept out intentionally

- No public proxy scraping.
- No Tor rotation.
- No headless browser tunneling.
- No automatic access-control bypass loop.

The implemented path is resilient ingestion: authorized proxy support, budgets, cooldowns, cache-first reruns, official/static NBA fallbacks, and auditable failure queues.

## Validation

Passed:

```bash
python -m py_compile gingeball_2025_26_combined_parser.py bbref_pbp_scraper.py shot_predictor_ml.py nba_api_healthcheck.py
```

Smoke-tested:

- provenance normalization
- BYO proxy env parsing
- hard per-game request budget
- sidecar cache provenance rewrite
- failed-game queue upsert / clear
- win-prob fallback provenance
