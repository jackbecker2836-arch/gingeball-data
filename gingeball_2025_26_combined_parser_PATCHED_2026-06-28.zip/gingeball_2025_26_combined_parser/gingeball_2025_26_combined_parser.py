"""
Gingeball 2025-26 Combined Master Parser
========================================

This combines Jack's Basketball-Reference PBP / true-possession / lineup-stint scraper
with the Gingeball modern enrichment layer:

A. BBRef authority layer for 2025-26
   - schedule discovery
   - raw HTML cache
   - raw PBP events
   - FT-aware true possessions
   - complete lineup stints
   - QC manifests / failures

B. Master normalized tables
   - clean_game_events
   - possession_frames
   - event_lineups
   - possession_lineups
   - observed_touch_chain

C. NBA Stats enrichment, when NBA game IDs are resolvable
   - automatic BBRef -> NBA game_id crosswalk through ScoreboardV2
   - PlayByPlayV3 sidecar
   - ShotChartDetail exact shot x/y sidecar
   - VideoEvents metadata sidecar
   - LeagueDashPtStats public tracking aggregate attempts

D. Coverage/tactical label layer
   - alternate/data broadcast text/captions/audio
   - closed captions/subtitles
   - broadcast/radio transcript
   - written live blog / recap
   - postgame film breakdown transcript/notes
   - tactical regex labels with source/evidence/confidence

Run examples:
    python gingeball_2025_26_combined_parser.py --scrape-bbref --season-year 2026
    python gingeball_2025_26_combined_parser.py --scrape-bbref --enrich --season-year 2026 --limit 5
    python gingeball_2025_26_combined_parser.py --game 202510220LAL --scrape-bbref --enrich
    python gingeball_2025_26_combined_parser.py --enrich-only --bbref-data-dir ./data_2025_26_bbref --out ./data_2025_26_master

Notes:
- Use only coverage/video/audio you have rights or authorization to process.
- BBRef game IDs look like YYYYMMDDHOM. NBA GameIDs look like 00225xxxxx.
- Automatic crosswalk uses NBA ScoreboardV2 by date + home team abbreviation.
"""

from __future__ import annotations

import argparse
import dataclasses
import gzip
import json
import os
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.parse import urlparse

import requests
import pandas as pd

try:
    from bs4 import BeautifulSoup
except Exception:
    BeautifulSoup = None

try:
    import whisper
except Exception:
    whisper = None

# Local copy of Jack's scraper. Keep it in this same folder.
import bbref_pbp_scraper as bbref

try:
    from nba_api.stats.library.http import NBAStatsHTTP
    from nba_api.stats.endpoints import (
        scoreboardv2,
        playbyplayv3,
        shotchartdetail,
        videoevents,
        leaguedashptstats,
    )
except Exception:
    NBAStatsHTTP = None
    scoreboardv2 = None
    playbyplayv3 = None
    shotchartdetail = None
    videoevents = None
    leaguedashptstats = None


# =============================================================================
# Constants / headers
# =============================================================================

NBA_HEADERS = {
    "Host": "stats.nba.com",
    "Connection": "keep-alive",
    "Accept": "application/json, text/plain, */*",
    "x-nba-stats-token": "true",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "x-nba-stats-origin": "stats",
    "Origin": "https://www.nba.com",
    "Referer": "https://www.nba.com/",
    "Accept-Language": "en-US,en;q=0.9",
}

if NBAStatsHTTP is not None:
    NBAStatsHTTP.headers = NBA_HEADERS

BBREF_TO_NBA_TEAM = {
    "ATL": "ATL", "BOS": "BOS", "BRK": "BKN", "BKN": "BKN", "CHO": "CHA", "CHA": "CHA",
    "CHI": "CHI", "CLE": "CLE", "DAL": "DAL", "DEN": "DEN", "DET": "DET", "GSW": "GSW",
    "HOU": "HOU", "IND": "IND", "LAC": "LAC", "LAL": "LAL", "MEM": "MEM", "MIA": "MIA",
    "MIL": "MIL", "MIN": "MIN", "NOP": "NOP", "NOH": "NOP", "NYK": "NYK", "OKC": "OKC",
    "ORL": "ORL", "PHI": "PHI", "PHO": "PHX", "PHX": "PHX", "POR": "POR", "SAC": "SAC",
    "SAS": "SAS", "TOR": "TOR", "UTA": "UTA", "WAS": "WAS",
}

SOURCE_ALT_BROADCAST = "alternate_data_broadcast"              # 6
SOURCE_CLOSED_CAPTIONS = "closed_captions_subtitles"           # 7
SOURCE_BROADCAST_TRANSCRIPT = "broadcast_radio_transcript"     # 8
SOURCE_WRITTEN_COVERAGE = "written_live_blog_recap"            # 10
SOURCE_FILM_BREAKDOWN = "postgame_film_breakdown"              # 11
SOURCE_PBP_DESCRIPTION = "pbp_description"

# Whisper does not expose reliable per-segment confidence here; this is a
# source-trust prior, not measured ASR certainty.
WHISPER_SEGMENT_SOURCE_PRIOR = 0.64


# =============================================================================
# Coverage source data classes
# =============================================================================

@dataclass
class CoverageSource:
    source_id: str
    source_type: str
    label: str
    bbref_game_id: Optional[str] = None
    nba_game_id: Optional[str] = None
    url: Optional[str] = None
    local_path: Optional[str] = None
    notes: Optional[str] = None
    trusted: bool = False
    # If a video/audio/caption starts before tipoff, set this to seconds from source start to game start.
    broadcast_offset_seconds: float = 0.0

@dataclass
class TranscriptSegment:
    source_id: str
    source_type: str
    start_seconds: Optional[float]
    end_seconds: Optional[float]
    text: str
    confidence: float = 0.60

@dataclass
class TacticalLabel:
    bbref_game_id: str
    nba_game_id: Optional[str]
    event_id: Optional[str]
    event_index: Optional[int]
    true_possession_id: Optional[str]
    period: Optional[int]
    clock: Optional[str]
    source_id: str
    source_type: str
    label_family: str
    label_value: str
    confidence: float
    evidence_text: str
    evidence_start_seconds: Optional[float] = None
    evidence_end_seconds: Optional[float] = None
    label_version: str = "coverage_fusion_v1"


# =============================================================================
# Tactical phrase dictionary
# =============================================================================

TACTICAL_PATTERNS: Dict[str, Dict[str, Any]] = {
    "double_team": {
        "family": "attention", "base_confidence": 0.76,
        "positive": [r"\bdouble[- ]team(?:ed|s|ing)?\b", r"\bdraws two\b", r"\btwo defenders\b", r"\btwo on (?:the )?ball\b", r"\bthey send two\b", r"\bwall of defenders\b", r"\bdefense collapses\b", r"\bcollapses on him\b", r"\bpaint collapses\b"],
        "negative": [r"\bnot a double\b", r"\bno double\b", r"\bdon't double\b", r"\bshould double\b", r"\bcould double\b", r"\bmay double\b"],
    },
    "soft_help_shade": {"family": "attention", "base_confidence": 0.62, "positive": [r"\bshow(?:s|ing)? help\b", r"\bshade(?:s|d)? toward\b", r"\bloads up\b", r"\bhelp is there\b"], "negative": [r"\bno help\b", r"\bstays home\b"]},
    "decoy_gravity": {"family": "attention", "base_confidence": 0.58, "positive": [r"\bdecoy\b", r"\boccupies two\b", r"\bkeeps the defender attached\b", r"\bgravity\b"], "negative": []},
    "drop_coverage": {"family": "coverage", "base_confidence": 0.78, "positive": [r"\bdrop coverage\b", r"\bdrops back\b", r"\bbig is in a drop\b", r"\bsitting in the paint\b", r"\bconcedes the mid(?:range)?\b"], "negative": [r"\bnot in drop\b", r"\bno drop\b"]},
    "switch": {"family": "coverage", "base_confidence": 0.72, "positive": [r"\bswitch(?:ed|es|ing)?\b", r"\bswitch everything\b", r"\blate switch\b"], "negative": [r"\bnot switching\b", r"\bdidn'?t switch\b", r"\bno switch\b"]},
    "blitz_trap": {"family": "coverage", "base_confidence": 0.80, "positive": [r"\bblitz(?:ed|es|ing)?\b", r"\btrap(?:ped|s|ping)?\b", r"\baggressive trap\b", r"\bsend(?:s|ing)? two\b"], "negative": [r"\bnot a trap\b", r"\bno trap\b"]},
    "hedge": {"family": "coverage", "base_confidence": 0.68, "positive": [r"\bhedge(?:s|d|ing)?\b", r"\bshow and recover\b", r"\bshows high\b"], "negative": []},
    "ice_side_pnr": {"family": "coverage", "base_confidence": 0.63, "positive": [r"\bice\b", r"\bdowning the screen\b", r"\bforces him baseline\b"], "negative": []},
    "zone_defense": {"family": "coverage", "base_confidence": 0.74, "positive": [r"\bzone\b", r"\btwo[- ]three zone\b", r"\b2[- ]3 zone\b", r"\bthree[- ]two zone\b", r"\b3[- ]2 zone\b", r"\bbox and one\b", r"\bjunk defense\b"], "negative": [r"\bnot a zone\b", r"\bman to man\b", r"\bman-to-man\b"]},
    "scramble_rotation": {"family": "coverage", "base_confidence": 0.66, "positive": [r"\bscramble\b", r"\brotat(?:e|es|ing|ion)\b", r"\bemergency rotation\b", r"\bin rotation\b"], "negative": []},
    "nail_help": {"family": "help", "base_confidence": 0.66, "positive": [r"\bnail help\b", r"\bhelp at the nail\b", r"\bfree[- ]throw line help\b", r"\bstunts at the nail\b"], "negative": []},
    "lowman_tag": {"family": "help", "base_confidence": 0.70, "positive": [r"\blow man\b", r"\btags the roller\b", r"\btag(?:s|ged|ging)? the roll(?:er)?\b", r"\bweak[- ]side tag\b"], "negative": []},
    "paint_collapse": {"family": "help", "base_confidence": 0.72, "positive": [r"\bpaint collapses\b", r"\bcollapses the paint\b", r"\bdefense collapses\b", r"\bwall at the rim\b"], "negative": []},
    "spain_pnr": {"family": "set_action", "base_confidence": 0.84, "positive": [r"\bspain pick[- ]and[- ]roll\b", r"\bspain pnr\b", r"\bbackscreen(?:s|ing)? the roller\b", r"\bback screen on the roll(?:er)?\b"], "negative": []},
    "horns": {"family": "set_action", "base_confidence": 0.78, "positive": [r"\bhorns\b", r"\btwo bigs at the elbows\b", r"\belbow alignment\b", r"\bboth elbows occupied\b"], "negative": []},
    "dho": {"family": "set_action", "base_confidence": 0.78, "positive": [r"\bdribble hand[- ]?off\b", r"\bdho\b", r"\bhandoff\b"], "negative": []},
    "zoom_action": {"family": "set_action", "base_confidence": 0.72, "positive": [r"\bzoom action\b", r"\bpindown into a handoff\b", r"\boff the pin[- ]down into the handoff\b"], "negative": []},
    "hammer_action": {"family": "set_action", "base_confidence": 0.78, "positive": [r"\bhammer\b", r"\bhammer pass\b", r"\bweak[- ]side corner\b", r"\bbaseline drive.*corner\b"], "negative": []},
    "post_split": {"family": "set_action", "base_confidence": 0.76, "positive": [r"\bpost split\b", r"\bsplit action\b", r"\bsplits around the post\b"], "negative": []},
    "ghost_screen": {"family": "set_action", "base_confidence": 0.70, "positive": [r"\bghost screen\b", r"\bghosts the screen\b", r"\bslips out before contact\b"], "negative": []},
    "pocket_pass": {"family": "pass_type", "base_confidence": 0.84, "positive": [r"\bpocket pass\b", r"\bslips it inside\b", r"\bthreads it to the roll(?:er)?\b"], "negative": []},
    "drive_and_kick": {"family": "pass_type", "base_confidence": 0.84, "positive": [r"\bdrive and kick\b", r"\bkick(?:s|ed)? it out\b", r"\bkickout\b", r"\bcollapse and kick\b"], "negative": []},
    "skip_pass": {"family": "pass_type", "base_confidence": 0.80, "positive": [r"\bskip pass\b", r"\bcross[- ]court pass\b", r"\bopposite corner\b"], "negative": []},
    "swing_swing": {"family": "pass_type", "base_confidence": 0.74, "positive": [r"\bswing[- ]swing\b", r"\bone more\b", r"\bextra pass\b"], "negative": []},
    "pump_fake": {"family": "deception", "base_confidence": 0.78, "positive": [r"\bpump fake\b", r"\bup fake\b", r"\bshot fake\b", r"\bbit on the fake\b"], "negative": []},
    "fly_by_closeout": {"family": "closeout", "base_confidence": 0.72, "positive": [r"\bfly[- ]by\b", r"\bflew past\b", r"\bruns him off\b", r"\bran him off\b"], "negative": []},
    "controlled_closeout": {"family": "closeout", "base_confidence": 0.68, "positive": [r"\bcontrolled closeout\b", r"\bcloses out short\b", r"\bchopping feet\b"], "negative": []},
    "tip_out": {"family": "rebounding", "base_confidence": 0.82, "positive": [r"\btip(?:s|ped)? it out\b", r"\btap(?:s|ped)? it back\b", r"\bkeeps it alive\b"], "negative": []},
    "box_out": {"family": "rebounding", "base_confidence": 0.76, "positive": [r"\bbox(?:es|ed)? out\b", r"\bcrowded the glass\b", r"\bseals him on the glass\b"], "negative": []},
}


# =============================================================================
# Utilities
# =============================================================================

def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def clean_text(text: Any) -> str:
    return re.sub(r"\s+", " ", str(text or "").replace("\n", " ")).strip()


def write_csv(df: pd.DataFrame, path: Path) -> None:
    ensure_dir(path.parent)
    df.to_csv(path, index=False)


def read_table(path: str | Path) -> pd.DataFrame:
    p = Path(path)
    if not p.exists():
        return pd.DataFrame()
    if p.suffix.lower() in {".parquet", ".pq"}:
        return pd.read_parquet(p)
    return pd.read_csv(p)


def bbref_clock_to_seconds_remaining(s: Any) -> Optional[float]:
    m = re.match(r"(\d+):(\d+(?:\.\d+)?)", str(s).strip())
    return int(m.group(1)) * 60 + float(m.group(2)) if m else None


def elapsed_from_bbref_clock(period: int, time_remaining: Any) -> Optional[float]:
    rem = bbref_clock_to_seconds_remaining(time_remaining)
    if rem is None:
        return None
    plen = 12 * 60 if int(period) <= 4 else 5 * 60
    prior = sum((12 * 60 if p <= 4 else 5 * 60) for p in range(1, int(period)))
    return round(prior + (plen - rem), 1)


def nba_clock_to_seconds_remaining(clock: Any) -> Optional[float]:
    if not clock:
        return None
    m = re.search(r"PT(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?", str(clock))
    if not m:
        return None
    return float(m.group(1) or 0) * 60 + float(m.group(2) or 0)


def elapsed_from_nba_clock(period: int, clock: Any) -> Optional[float]:
    rem = nba_clock_to_seconds_remaining(clock)
    if rem is None:
        return None
    plen = 720 if int(period) <= 4 else 300
    prior = sum((720 if p <= 4 else 300) for p in range(1, int(period)))
    return round(prior + (plen - rem), 1)


def maybe_int(x: Any) -> Optional[int]:
    try:
        if pd.isna(x):
            return None
    except Exception:
        pass
    try:
        if x is None or x == "":
            return None
        return int(x)
    except Exception:
        return None


def is_true(x: Any) -> bool:
    """Boolean parser that is safe after CSV round-trips.

    Pandas usually preserves True/False columns, but mixed missing values can turn
    them into object/string columns.  bool("False") is True, which silently
    corrupts event-type logic, touch chains, and NBA alignment filters.
    """
    if x is None:
        return False
    try:
        if pd.isna(x):
            return False
    except Exception:
        pass
    if isinstance(x, str):
        return x.strip().lower() in {"1", "true", "t", "yes", "y"}
    return bool(x)


def clean_team_code(x: Any) -> Optional[str]:
    if x is None:
        return None
    try:
        if pd.isna(x):
            return None
    except Exception:
        pass
    txt = str(x).strip().upper()
    return txt or None


def nonempty_id(x: Any) -> bool:
    if x is None:
        return False
    try:
        if pd.isna(x):
            return False
    except Exception:
        pass
    return str(x).strip() not in {"", "nan", "None", "NONE", "NaN"}


BOOL_EVENT_COLS = [
    "is_playoff", "is_scoring", "is_shot", "shot_made", "is_ft", "ft_made",
    "is_tech_ft", "is_rebound", "is_off_rebound", "is_def_rebound",
    "is_turnover", "is_steal", "is_block", "is_foul", "is_timeout",
    "is_sub", "is_jumpball", "is_live_ball_tov", "is_dead_ball",
]


def to_jsonable_records(df: pd.DataFrame) -> List[Dict[str, Any]]:
    if df is None or df.empty:
        return []
    out = df.where(pd.notna(df), None).to_dict(orient="records")
    return out


# =============================================================================
# Configure and run Jack's BBRef scraper for only 2025-26
# =============================================================================

def configure_bbref_module(data_dir: str | Path, delay: float = 3.5, jitter: float = 1.5, save_html: bool = True) -> None:
    data_dir = Path(data_dir)
    bbref.SEASONS = [2026]
    bbref.DELAY = delay
    bbref.JITTER = jitter
    bbref.SAVE_HTML = save_html
    bbref.DATA_DIR = data_dir
    bbref.RAW_DIR = data_dir / "raw_pbp"
    bbref.POSS_DIR = data_dir / "possessions"
    bbref.SCHED_DIR = data_dir / "schedule"
    bbref.HTML_DIR = data_dir / "html"
    bbref.PLAYERS_MASTER = data_dir / "players_master.csv"
    bbref.QC_MANIFEST = data_dir / "qc_manifest.csv"
    bbref.FAILURES = data_dir / "failures.csv"
    for d in [bbref.RAW_DIR, bbref.POSS_DIR, bbref.SCHED_DIR, bbref.HTML_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def scrape_bbref_2025_26(
    data_dir: str | Path,
    game: Optional[str] = None,
    limit: Optional[int] = None,
    delay: float = 3.5,
    jitter: float = 1.5,
    save_html: bool = True,
) -> Dict[str, Any]:
    configure_bbref_module(data_dir, delay=delay, jitter=jitter, save_html=save_html)
    schedule = bbref.season_game_ids(2026)

    if game:
        ok = bbref.scrape_game(game, schedule.get(game, False))
        return {"mode": "single_game", "game": game, "ok": bool(ok), "scheduled_games": len(schedule)}

    total = success = skip = fail = 0
    for gid, is_po in sorted(schedule.items()):
        if limit is not None and total >= limit:
            break
        raw = bbref.RAW_DIR / f"{gid}.csv"
        luf = bbref.POSS_DIR / f"{gid}_lineups.csv"
        tpf = bbref.POSS_DIR / f"{gid}_tp.csv"
        if raw.exists() and luf.exists() and tpf.exists():
            skip += 1
            continue
        ok = bbref.scrape_game(gid, is_po)
        total += 1
        success += int(ok)
        fail += int(not ok)
        if total % 25 == 0:
            print(f"BBRef scrape progress: {success} ok / {fail} fail / {skip} skip")

    return {"mode": "season_2026", "scheduled_games": len(schedule), "attempted": total, "success": success, "fail": fail, "skip": skip}


# =============================================================================
# Load BBRef authority outputs
# =============================================================================

def bbref_paths(data_dir: str | Path, game_id: str) -> Dict[str, Path]:
    data_dir = Path(data_dir)
    return {
        "raw_pbp": data_dir / "raw_pbp" / f"{game_id}.csv",
        "true_possessions": data_dir / "possessions" / f"{game_id}_tp.csv",
        "lineups": data_dir / "possessions" / f"{game_id}_lineups.csv",
        "meta": data_dir / "possessions" / f"{game_id}_meta.json",
    }


def available_bbref_games(data_dir: str | Path) -> List[str]:
    raw_dir = Path(data_dir) / "raw_pbp"
    if not raw_dir.exists():
        return []
    return sorted(p.stem for p in raw_dir.glob("*.csv"))


def load_bbref_game(data_dir: str | Path, game_id: str) -> Dict[str, Any]:
    paths = bbref_paths(data_dir, game_id)
    raw = read_table(paths["raw_pbp"])
    tp = read_table(paths["true_possessions"])
    lineups = read_table(paths["lineups"])
    meta = {}
    if paths["meta"].exists():
        try:
            meta = json.loads(paths["meta"].read_text(encoding="utf-8"))
        except Exception:
            meta = {}
    return {"raw_pbp": raw, "true_possessions": tp, "lineups": lineups, "meta": meta, "paths": paths}


# =============================================================================
# Normalize BBRef into master tables
# =============================================================================

def normalize_clean_game_events(raw: pd.DataFrame) -> pd.DataFrame:
    if raw.empty:
        return pd.DataFrame()
    df = raw.copy()
    if "elapsed" not in df.columns:
        df["elapsed"] = df.apply(lambda r: elapsed_from_bbref_clock(int(r["period"]), r["time_remaining"]), axis=1)
    df["event_index"] = range(len(df))
    df["bbref_event_id"] = df.apply(lambda r: f"{r['game_id']}_E{int(r['event_index']):04d}", axis=1)
    out = pd.DataFrame({
        "bbref_game_id": df["game_id"],
        "season": df.get("season"),
        "date": df.get("date"),
        "is_playoff": df.get("is_playoff"),
        "event_index": df["event_index"],
        "event_id": df["bbref_event_id"],
        "period": df.get("period"),
        "clock": df.get("time_remaining"),
        "game_elapsed_seconds": df.get("elapsed"),
        "away_team": df.get("away_team"),
        "home_team": df.get("home_team"),
        "event_side": df.get("side"),
        "event_team": df.get("team"),
        "player": df.get("player"),
        "player_id_bbref": df.get("player_id"),
        "player2": df.get("player2"),
        "player2_id_bbref": df.get("player2_id"),
        "assist_id_bbref": df.get("assist_id"),
        "block_id_bbref": df.get("block_id"),
        "steal_id_bbref": df.get("steal_id"),
        "event_text": df.get("event_text"),
        "points": df.get("points"),
        "shot_zone_bbref": df.get("shot_zone"),
        "shot_dist_bbref": df.get("shot_dist"),
        "away_score": df.get("away_score"),
        "home_score": df.get("home_score"),
        "is_scoring": df.get("is_scoring"),
        "is_shot": df.get("is_shot"),
        "shot_made": df.get("shot_made"),
        "is_ft": df.get("is_ft"),
        "ft_made": df.get("ft_made"),
        "ft_num": df.get("ft_num"),
        "ft_of": df.get("ft_of"),
        "is_tech_ft": df.get("is_tech_ft"),
        "is_rebound": df.get("is_rebound"),
        "is_off_rebound": df.get("is_off_rebound"),
        "is_def_rebound": df.get("is_def_rebound"),
        "is_turnover": df.get("is_turnover"),
        "is_steal": df.get("is_steal"),
        "is_block": df.get("is_block"),
        "is_foul": df.get("is_foul"),
        "is_timeout": df.get("is_timeout"),
        "is_sub": df.get("is_sub"),
        "is_jumpball": df.get("is_jumpball"),
        "is_live_ball_tov": df.get("is_live_ball_tov"),
        "is_dead_ball": df.get("is_dead_ball"),
        "source": "bbref_pbp_scraper_v2",
    })
    for col in BOOL_EVENT_COLS:
        if col in out.columns:
            out[col] = out[col].map(is_true)
    for col in ["period", "event_index", "points", "ft_num", "ft_of", "away_score", "home_score"]:
        if col in out.columns:
            out[col] = pd.to_numeric(out[col], errors="coerce")
    if "game_elapsed_seconds" in out.columns:
        out["game_elapsed_seconds"] = pd.to_numeric(out["game_elapsed_seconds"], errors="coerce")
    return out


def normalize_possession_frames(tp: pd.DataFrame, raw: pd.DataFrame) -> pd.DataFrame:
    if tp.empty:
        return pd.DataFrame()
    out = tp.copy()
    if not raw.empty:
        game_id = raw["game_id"].iloc[0]
        away_team = raw["away_team"].iloc[0]
        home_team = raw["home_team"].iloc[0]
    else:
        game_id = out["game_id"].iloc[0]
        away_team = home_team = None

    out = out.rename(columns={
        "true_possession_id": "possession_id",
        "tp_start_time": "start_clock",
        "tp_end_time": "end_clock",
        "true_possession_points": "points_scored",
        "dead_ball_end_type": "end_type",
    })
    out["bbref_game_id"] = out.get("game_id", game_id)
    out["season"] = raw["season"].iloc[0] if not raw.empty and "season" in raw.columns else None
    out["start_elapsed"] = out.apply(lambda r: elapsed_from_bbref_clock(int(r["period"]), r.get("start_clock")), axis=1)
    out["end_elapsed"] = out.apply(lambda r: elapsed_from_bbref_clock(int(r["period"]), r.get("end_clock")), axis=1)
    out["duration_seconds"] = out.apply(lambda r: None if pd.isna(r.get("start_elapsed")) or pd.isna(r.get("end_elapsed")) else round(float(r["end_elapsed"]) - float(r["start_elapsed"]), 1), axis=1)
    out["away_team"] = away_team
    out["home_team"] = home_team
    out["source"] = "bbref_true_possessions_ft_aware"
    keep = [
        "bbref_game_id", "season", "possession_id", "period", "offense_team", "defense_team",
        "start_clock", "end_clock", "start_elapsed", "end_elapsed", "duration_seconds",
        "points_scored", "standard_possessions_inside", "advantage_count", "end_type",
        "away_team", "home_team", "source"
    ]
    return out[[c for c in keep if c in out.columns]]


def _stint_player_match_score(stint: pd.Series, event: Optional[pd.Series] = None) -> int:
    if event is None:
        return 0
    ids = [event.get("player_id_bbref"), event.get("player2_id_bbref"), event.get("assist_id_bbref"), event.get("block_id_bbref"), event.get("steal_id_bbref")]
    ids = {str(x) for x in ids if nonempty_id(x)}
    if not ids:
        return 0
    away_ids = {str(stint.get(f"away_p{i}_id", "")) for i in range(1, 6) if nonempty_id(stint.get(f"away_p{i}_id", ""))}
    home_ids = {str(stint.get(f"home_p{i}_id", "")) for i in range(1, 6) if nonempty_id(stint.get(f"home_p{i}_id", ""))}
    side = str(event.get("event_side", "")).lower()
    score = len(ids & (away_ids | home_ids))
    if side == "away":
        score += 2 * len(ids & away_ids)
    elif side == "home":
        score += 2 * len(ids & home_ids)
    return int(score)


def stint_for_elapsed(lineups: pd.DataFrame, period: int, elapsed: float, event: Optional[pd.Series] = None) -> Optional[pd.Series]:
    if lineups.empty or elapsed is None or pd.isna(elapsed):
        return None
    sub = lineups[lineups["period"].astype(int) == int(period)].copy()
    if sub.empty:
        return None

    sub["_secs_on"] = pd.to_numeric(sub["secs_on"], errors="coerce")
    sub["_secs_off"] = pd.to_numeric(sub["secs_off"], errors="coerce")
    sub = sub.dropna(subset=["_secs_on", "_secs_off"]).copy()
    if sub.empty:
        return None

    t = float(elapsed)
    eps = 0.2
    last_off = float(sub["_secs_off"].max())

    # Primary rule: half-open stint windows [secs_on, secs_off).  This prevents
    # substitution-boundary events from being claimed by the lineup that just left.
    half_open = sub[(sub["_secs_on"] <= t) & (t < sub["_secs_off"])]

    # At the final recorded stint boundary of a period there is no next stint; keep
    # the last row eligible so end-of-period/game-end events are not orphaned.
    if half_open.empty and abs(t - last_off) <= eps:
        half_open = sub[(sub["_secs_off"] - eps <= t) & (t <= sub["_secs_off"] + eps)]

    if not half_open.empty:
        hit = half_open.copy()
        hit["_player_match"] = hit.apply(lambda r: _stint_player_match_score(r, event), axis=1)
        hit["_start_dist"] = (hit["_secs_on"] - t).abs()
        hit["_dur"] = pd.to_numeric(hit.get("duration", hit["_secs_off"] - hit["_secs_on"]), errors="coerce")
        return hit.sort_values(["_player_match", "_start_dist", "_dur"], ascending=[False, True, False]).iloc[0]

    # Boundary/tolerance fallback for noisy clocks: choose the compatible row, not
    # merely the shortest row.  This is deliberately second-priority behind the
    # half-open rule above.
    near = sub[(sub["_secs_on"] - eps <= t) & (t <= sub["_secs_off"] + eps)].copy()
    if not near.empty:
        near["_half_open"] = (near["_secs_on"] <= t) & (t < near["_secs_off"])
        near["_player_match"] = near.apply(lambda r: _stint_player_match_score(r, event), axis=1)
        near["_boundary_dist"] = near.apply(lambda r: min(abs(float(r["_secs_on"]) - t), abs(float(r["_secs_off"]) - t)), axis=1)
        return near.sort_values(["_half_open", "_player_match", "_boundary_dist", "_secs_on"], ascending=[False, False, True, False]).iloc[0]

    # Last resort: nearest stint start in the same period.
    sub["_dist"] = (sub["_secs_on"] - t).abs().clip(upper=99999)
    return sub.sort_values("_dist").iloc[0] if not sub.empty else None


def lineup_ids_from_stint(stint: pd.Series, side: str) -> List[str]:
    cols = [f"{side}_p{i}_id" for i in range(1, 6)]
    return [str(stint.get(c, "")) for c in cols if str(stint.get(c, "")) not in {"", "nan", "None"}]


def lineup_names_from_stint(stint: pd.Series, side: str) -> List[str]:
    cols = [f"{side}_p{i}" for i in range(1, 6)]
    return [str(stint.get(c, "")) for c in cols if str(stint.get(c, "")) not in {"", "nan", "None"}]


def build_event_lineups(events: pd.DataFrame, lineups: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    if events.empty or lineups.empty:
        return pd.DataFrame(rows)
    for _, e in events.iterrows():
        st = stint_for_elapsed(lineups, int(e["period"]), float(e["game_elapsed_seconds"]) if pd.notna(e["game_elapsed_seconds"]) else None, event=e)
        if st is None:
            rows.append({"bbref_game_id": e["bbref_game_id"], "event_id": e["event_id"], "lineup_source": "missing"})
            continue
        rows.append({
            "bbref_game_id": e["bbref_game_id"],
            "event_id": e["event_id"],
            "event_index": e["event_index"],
            "period": e["period"],
            "clock": e["clock"],
            "game_elapsed_seconds": e["game_elapsed_seconds"],
            "away_team": e["away_team"],
            "home_team": e["home_team"],
            "away_player_ids_bbref": json.dumps(lineup_ids_from_stint(st, "away")),
            "home_player_ids_bbref": json.dumps(lineup_ids_from_stint(st, "home")),
            "away_player_names": json.dumps(lineup_names_from_stint(st, "away")),
            "home_player_names": json.dumps(lineup_names_from_stint(st, "home")),
            "stint_time_on": st.get("time_on"),
            "stint_time_off": st.get("time_off"),
            "stint_secs_on": st.get("secs_on"),
            "stint_secs_off": st.get("secs_off"),
            "lineup_source": "bbref_stints",
        })
    return pd.DataFrame(rows)


def build_possession_lineups(possessions: pd.DataFrame, lineups: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    if possessions.empty or lineups.empty:
        return pd.DataFrame(rows)
    for _, p in possessions.iterrows():
        elapsed = p.get("start_elapsed")
        if pd.isna(elapsed):
            elapsed = p.get("end_elapsed")
        st = stint_for_elapsed(lineups, int(p["period"]), float(elapsed) if pd.notna(elapsed) else None)
        if st is None:
            rows.append({"bbref_game_id": p["bbref_game_id"], "possession_id": p["possession_id"], "lineup_source": "missing"})
            continue
        offense_side = "away" if p.get("offense_team") == p.get("away_team") else "home"
        defense_side = "home" if offense_side == "away" else "away"
        rows.append({
            "bbref_game_id": p["bbref_game_id"],
            "possession_id": p["possession_id"],
            "period": p["period"],
            "start_clock": p.get("start_clock"),
            "end_clock": p.get("end_clock"),
            "start_elapsed": p.get("start_elapsed"),
            "end_elapsed": p.get("end_elapsed"),
            "offense_team": p.get("offense_team"),
            "defense_team": p.get("defense_team"),
            "offense_side": offense_side,
            "defense_side": defense_side,
            "offense_player_ids_bbref": json.dumps(lineup_ids_from_stint(st, offense_side)),
            "defense_player_ids_bbref": json.dumps(lineup_ids_from_stint(st, defense_side)),
            "offense_player_names": json.dumps(lineup_names_from_stint(st, offense_side)),
            "defense_player_names": json.dumps(lineup_names_from_stint(st, defense_side)),
            "lineup_source": "bbref_stints",
        })
    return pd.DataFrame(rows)


def _possession_fallback_match(e: pd.Series, poss_period: pd.DataFrame, eps: float = 0.2) -> Tuple[Optional[Any], str]:
    if poss_period.empty or pd.isna(e.get("_event_elapsed")):
        return None, "missing_elapsed"
    t = float(e["_event_elapsed"])
    team = clean_team_code(e.get("event_team"))
    cand = poss_period[(poss_period["_start"] - eps <= t) & (t <= poss_period["_end"] + eps)].copy()
    if cand.empty:
        return None, "no_window"
    last_end = float(poss_period["_end"].max())
    cand["_half_open"] = (cand["_start"] <= t) & (t < cand["_end"])
    cand.loc[(abs(t - last_end) <= eps) & (cand["_end"] == last_end), "_half_open"] = True
    cand["_start_boundary"] = (cand["_start"] - t).abs() <= eps
    cand["_team_match"] = cand["offense_team"].map(clean_team_code).eq(team) if team else False
    cand["_boundary_dist"] = cand.apply(lambda r: min(abs(float(r["_start"]) - t), abs(float(r["_end"]) - t)), axis=1)
    # Half-open wins first; team match is a tie-break/fallback so a closing
    # possession cannot steal an exact end-boundary event from the new window.
    cand = cand.sort_values(["_half_open", "_start_boundary", "_team_match", "_boundary_dist", "_start"], ascending=[False, False, False, True, False])
    row = cand.iloc[0]
    method = "half_open_fallback" if bool(row.get("_half_open")) else "tolerance_team_fallback"
    return row.get("possession_id"), method


def attach_possession_ids_to_events(events: pd.DataFrame, possessions: pd.DataFrame) -> pd.DataFrame:
    if events.empty or possessions.empty:
        events["true_possession_id"] = None
        return events

    out = events.copy().reset_index(drop=False).rename(columns={"index": "_event_row"})
    out["_period_int"] = pd.to_numeric(out.get("period"), errors="coerce")
    out["_event_elapsed"] = pd.to_numeric(out.get("game_elapsed_seconds"), errors="coerce")

    poss = possessions.copy()
    poss["_period_int"] = pd.to_numeric(poss.get("period"), errors="coerce")
    poss["_start_raw"] = pd.to_numeric(poss.get("start_elapsed"), errors="coerce")
    poss["_end_raw"] = pd.to_numeric(poss.get("end_elapsed"), errors="coerce")
    poss = poss.dropna(subset=["_period_int", "_start_raw", "_end_raw"]).copy()
    if poss.empty:
        out["true_possession_id"] = None
        return out.drop(columns=[c for c in out.columns if c.startswith("_")], errors="ignore")

    poss["_start"] = poss[["_start_raw", "_end_raw"]].min(axis=1)
    poss["_end"] = poss[["_start_raw", "_end_raw"]].max(axis=1)
    poss = poss.sort_values(["_period_int", "_start", "_end"]).reset_index(drop=True)

    assignments: Dict[int, Any] = {}
    methods: Dict[int, str] = {}
    eps = 0.2

    eligible = out.dropna(subset=["_period_int", "_event_elapsed"]).copy()
    for period, evg in eligible.groupby("_period_int", sort=False):
        pg = poss[poss["_period_int"] == period].copy()
        if pg.empty:
            continue
        ev_sorted = evg.sort_values("_event_elapsed")
        pg_sorted = pg.sort_values("_start")
        merged = pd.merge_asof(
            ev_sorted,
            pg_sorted[["possession_id", "offense_team", "_start", "_end"]].sort_values("_start"),
            left_on="_event_elapsed",
            right_on="_start",
            direction="backward",
            allow_exact_matches=True,
        )
        last_end = float(pg_sorted["_end"].max())
        for _, m in merged.iterrows():
            row_id = int(m["_event_row"])
            pid = m.get("possession_id")
            valid = False
            if pd.notna(pid) and pd.notna(m.get("_start")) and pd.notna(m.get("_end")):
                t = float(m["_event_elapsed"])
                start = float(m["_start"])
                end = float(m["_end"])
                valid = (start <= t) and (t < end)
                if not valid and abs(t - last_end) <= eps and abs(t - end) <= eps:
                    valid = True
            if valid:
                assignments[row_id] = pid
                methods[row_id] = "merge_asof_half_open"
            else:
                pid2, method = _possession_fallback_match(m, pg_sorted, eps=eps)
                assignments[row_id] = pid2
                methods[row_id] = method

    out["true_possession_id"] = out["_event_row"].map(assignments)
    out["true_possession_attach_method"] = out["_event_row"].map(methods).fillna("unmatched")
    return out.drop(columns=[c for c in out.columns if c.startswith("_")], errors="ignore")


def build_observed_touch_chain(events: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    if events.empty:
        return pd.DataFrame(rows)

    def add(e, role, player_col="player_id_bbref", name_col="player", confidence=1.0):
        pid = e.get(player_col)
        if pid is None or str(pid) in {"", "nan", "None"}:
            return
        rows.append({
            "bbref_game_id": e.get("bbref_game_id"),
            "possession_id": e.get("true_possession_id"),
            "event_id": e.get("event_id"),
            "event_index": e.get("event_index"),
            "period": e.get("period"),
            "clock": e.get("clock"),
            "game_elapsed_seconds": e.get("game_elapsed_seconds"),
            "player_id_bbref": pid,
            "player_name": e.get(name_col),
            "touch_role": role,
            "is_observed": True,
            "confidence": confidence,
            "source": "bbref_pbp_actor_skeleton",
            "event_text": e.get("event_text"),
        })

    for _, e in events.iterrows():
        if is_true(e.get("is_def_rebound")):
            add(e, "DEFENSIVE_REBOUNDER_START")
        if is_true(e.get("is_off_rebound")):
            add(e, "OFFENSIVE_REBOUNDER")
        if is_true(e.get("is_shot")):
            add(e, "SHOT_TAKER")
        if str(e.get("assist_id_bbref", "")) not in {"", "nan", "None"}:
            add(e, "ASSISTER", "assist_id_bbref", "player2")
        if is_true(e.get("is_turnover")):
            add(e, "TURNOVER_PLAYER")
        if is_true(e.get("is_steal")) and str(e.get("steal_id_bbref", "")) not in {"", "nan", "None"}:
            add(e, "STEAL_PLAYER", "steal_id_bbref", "player2")
        if is_true(e.get("is_block")) and str(e.get("block_id_bbref", "")) not in {"", "nan", "None"}:
            add(e, "BLOCK_PLAYER", "block_id_bbref", "player2")
        if is_true(e.get("is_ft")):
            add(e, "FREE_THROW_SHOOTER")
        if is_true(e.get("is_foul")) and not is_true(e.get("is_turnover")):
            # BBRef often places fouls in the drawn-team column; keep role generic until validated.
            add(e, "FOUL_EVENT_PRIMARY_ACTOR", confidence=0.75)

    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df["touch_index_observed_order"] = df.groupby("possession_id").cumcount() + 1
    return df


# =============================================================================
# NBA game ID crosswalk + sidecars
# =============================================================================

def bbref_game_date_to_nba_date(game_id: str) -> str:
    return f"{game_id[4:6]}/{game_id[6:8]}/{game_id[:4]}"


def _append_nba_crosswalk_failure(log_path: Optional[str | Path], rec: Dict[str, Any]) -> None:
    if not log_path:
        return
    try:
        path = Path(log_path)
        ensure_dir(path.parent)
        row = pd.DataFrame([{**{"logged_at_utc": pd.Timestamp.utcnow().isoformat()}, **rec}])
        if path.exists():
            row.to_csv(path, mode="a", index=False, header=False)
        else:
            row.to_csv(path, index=False)
    except Exception as e:
        print(f"WARN: could not write NBA crosswalk failure log {log_path}: {e}")


def _scoreboard_candidates_from_frames(dfs: List[pd.DataFrame], home_nba: str, away_nba: Optional[str]) -> Tuple[List[str], List[Dict[str, Any]]]:
    matches: List[str] = []
    seen: set[str] = set()
    available: List[Dict[str, Any]] = []
    home_nba = str(home_nba).upper()
    away_nba = str(away_nba).upper() if away_nba else None

    def add_match(game_id: Any, why: str, row: Optional[pd.Series] = None) -> None:
        if game_id is None or pd.isna(game_id):
            return
        gid = str(game_id)
        if gid not in seen:
            seen.add(gid)
            matches.append(gid)
        if row is not None:
            available.append({"game_id": gid, "why": why, "row": {k: row.get(k) for k in row.index if k in {"GAME_ID", "GAMECODE", "HOME_TEAM_ABBREVIATION", "VISITOR_TEAM_ABBREVIATION", "HTM", "VTM"}}})

    for df in dfs:
        if df is None or df.empty or "GAME_ID" not in df.columns:
            continue
        cols = set(df.columns)
        for _, r in df.iterrows():
            h = clean_team_code(r.get("HOME_TEAM_ABBREVIATION") or r.get("HTM") or r.get("HOME_TEAM"))
            v = clean_team_code(r.get("VISITOR_TEAM_ABBREVIATION") or r.get("VTM") or r.get("AWAY_TEAM") or r.get("VISITOR_TEAM"))
            gamecode = clean_team_code(r.get("GAMECODE"))
            if h == home_nba and (away_nba is None or v in {None, away_nba}):
                add_match(r.get("GAME_ID"), "home_visitor_columns", r)
            elif gamecode and gamecode.endswith(f"/{away_nba or ''}{home_nba}"):
                add_match(r.get("GAME_ID"), "gamecode_away_home_suffix", r)
            elif gamecode and away_nba and f"/{away_nba}{home_nba}" in gamecode:
                add_match(r.get("GAME_ID"), "gamecode_away_home", r)

    # ScoreboardV2 often has a LineScore-style frame with one team row per game.
    # That frame may not mark home/away, but matching date + both teams is a strong
    # fallback for doubleheaders/abbreviation quirks.
    for df in dfs:
        if df is None or df.empty or "GAME_ID" not in df.columns:
            continue
        abbr_col = None
        for c in ["TEAM_ABBREVIATION", "TEAM_ABBREVIATION_HOME", "TEAM_ABBREVIATION_AWAY", "TEAM"]:
            if c in df.columns:
                abbr_col = c
                break
        if not abbr_col:
            continue
        for gid, g in df.groupby("GAME_ID"):
            teams = {clean_team_code(x) for x in g[abbr_col].tolist()}
            teams.discard(None)
            if home_nba in teams and (away_nba is None or away_nba in teams):
                add_match(gid, "line_score_team_set")

    return matches, available


def resolve_nba_game_id_from_scoreboard(
    bbref_game_id: str,
    home_team_bbref: Optional[str] = None,
    away_team_bbref: Optional[str] = None,
    log_path: Optional[str | Path] = None,
) -> Optional[str]:
    if scoreboardv2 is None:
        _append_nba_crosswalk_failure(log_path, {"bbref_game_id": bbref_game_id, "reason": "nba_api_scoreboardv2_unavailable"})
        return None
    home = home_team_bbref or bbref_game_id[-3:]
    home_nba = BBREF_TO_NBA_TEAM.get(str(home).upper(), str(home).upper())
    away_nba = BBREF_TO_NBA_TEAM.get(str(away_team_bbref).upper(), str(away_team_bbref).upper()) if away_team_bbref else None
    game_date = bbref_game_date_to_nba_date(bbref_game_id)
    try:
        sb = scoreboardv2.ScoreboardV2(game_date=game_date, headers=NBA_HEADERS, timeout=30)
        dfs = sb.get_data_frames()
        matches, available = _scoreboard_candidates_from_frames(dfs, home_nba, away_nba)
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            # With both teams supplied, the line-score fallback should usually collapse
            # to one.  If not, do not guess silently.
            _append_nba_crosswalk_failure(log_path, {
                "bbref_game_id": bbref_game_id, "game_date": game_date, "home_nba": home_nba,
                "away_nba": away_nba, "reason": "ambiguous_scoreboard_matches",
                "candidate_game_ids": json.dumps(matches),
            })
            return None
        _append_nba_crosswalk_failure(log_path, {
            "bbref_game_id": bbref_game_id, "game_date": game_date, "home_nba": home_nba,
            "away_nba": away_nba, "reason": "no_scoreboard_match",
            "scoreboard_probe": json.dumps(available[:8], default=str),
        })
    except Exception as e:
        _append_nba_crosswalk_failure(log_path, {
            "bbref_game_id": bbref_game_id, "game_date": game_date, "home_nba": home_nba,
            "away_nba": away_nba, "reason": "exception", "error": str(e),
        })
        print(f"WARN: could not resolve NBA game id for {bbref_game_id}: {e}")
    return None


def fetch_nba_pbp_v3(nba_game_id: str) -> pd.DataFrame:
    if playbyplayv3 is None:
        return pd.DataFrame()
    try:
        raw = playbyplayv3.PlayByPlayV3(game_id=nba_game_id, headers=NBA_HEADERS, timeout=30).get_json()
        actions = json.loads(raw)["game"]["actions"]
        rows = []
        for idx, a in enumerate(actions):
            period = maybe_int(a.get("period"))
            clock = a.get("clock")
            rows.append({
                "nba_game_id": nba_game_id,
                "nba_event_index": idx,
                "nba_action_number": a.get("actionNumber"),
                "period": period,
                "clock": clock,
                "game_elapsed_seconds": elapsed_from_nba_clock(period, clock) if period else None,
                "action_type": a.get("actionType"),
                "sub_type": a.get("subType"),
                "descriptor": a.get("descriptor"),
                "qualifiers": json.dumps(a.get("qualifiers")) if isinstance(a.get("qualifiers"), (list, dict)) else a.get("qualifiers"),
                "team_id_nba": a.get("teamId"),
                "player_id_nba": a.get("personId"),
                "x": a.get("x"),
                "y": a.get("y"),
                "x_legacy": a.get("xLegacy"),
                "y_legacy": a.get("yLegacy"),
                "shot_distance": a.get("shotDistance"),
                "description": clean_text(a.get("description", "")),
                "raw_action": json.dumps(a),
            })
        return pd.DataFrame(rows)
    except Exception as e:
        print(f"WARN: PlayByPlayV3 failed for {nba_game_id}: {e}")
        return pd.DataFrame()


def fetch_nba_shotchart(nba_game_id: str, season_label: str = "2025-26") -> pd.DataFrame:
    if shotchartdetail is None:
        return pd.DataFrame()
    try:
        df = shotchartdetail.ShotChartDetail(
            team_id=0,
            player_id=0,
            game_id_nullable=nba_game_id,
            context_measure_simple_nullable="FGA",
            season_nullable=season_label,
            headers=NBA_HEADERS,
            timeout=30,
        ).get_data_frames()[0]
        df.insert(0, "nba_game_id", nba_game_id)
        return df
    except Exception as e:
        print(f"WARN: ShotChartDetail failed for {nba_game_id}: {e}")
        return pd.DataFrame()


def fetch_videoevents_for_nba_pbp(nba_game_id: str, nba_pbp: pd.DataFrame, max_events: int = 80) -> pd.DataFrame:
    if videoevents is None or nba_pbp.empty:
        return pd.DataFrame()
    rows = []
    # Don't hammer it for every event by default. Prioritize shot/turnover/block/steal-ish rows.
    cand = nba_pbp.copy()
    if "action_type" in cand.columns:
        mask = cand["action_type"].astype(str).str.lower().isin(["2pt", "3pt", "freethrow", "turnover", "block", "steal", "foul"])
        if mask.any():
            cand = cand[mask]
    cand = cand.head(max_events)
    for _, r in cand.iterrows():
        action_no = r.get("nba_action_number")
        if action_no is None or pd.isna(action_no):
            continue
        try:
            obj = videoevents.VideoEvents(game_id=nba_game_id, game_event_id=int(action_no), headers=NBA_HEADERS, timeout=30)
            payload = obj.nba_response.get_dict()
            rows.append({
                "nba_game_id": nba_game_id,
                "nba_action_number": int(action_no),
                "period": r.get("period"),
                "clock": r.get("clock"),
                "description": r.get("description"),
                "videoevents_payload": json.dumps(payload),
                "videoevents_error": None,
            })
        except Exception as e:
            rows.append({
                "nba_game_id": nba_game_id,
                "nba_action_number": int(action_no),
                "period": r.get("period"),
                "clock": r.get("clock"),
                "description": r.get("description"),
                "videoevents_payload": None,
                "videoevents_error": str(e),
            })
        time.sleep(0.25)
    return pd.DataFrame(rows)


def _bbref_event_kind(e: pd.Series) -> str:
    if is_true(e.get("is_shot")):
        return "shot"
    if is_true(e.get("is_turnover")):
        return "turnover"
    if is_true(e.get("is_rebound")):
        return "rebound"
    if is_true(e.get("is_foul")):
        return "foul"
    if is_true(e.get("is_sub")):
        return "substitution"
    if is_true(e.get("is_timeout")):
        return "timeout"
    if is_true(e.get("is_jumpball")):
        return "jumpball"
    return "other"


def _compatible_nba_actions(nba_period: pd.DataFrame, kind: str) -> pd.DataFrame:
    if nba_period.empty or "action_type" not in nba_period.columns:
        return nba_period
    at = nba_period["action_type"].astype(str).str.lower()
    if kind == "shot":
        mask = at.isin(["2pt", "3pt", "freethrow"])
    elif kind == "turnover":
        mask = at.str.contains("turnover", na=False)
    elif kind == "rebound":
        mask = at.str.contains("rebound", na=False)
    elif kind == "foul":
        mask = at.str.contains("foul", na=False)
    elif kind == "substitution":
        mask = at.str.contains("sub", na=False)
    elif kind == "timeout":
        mask = at.str.contains("timeout", na=False)
    elif kind == "jumpball":
        mask = at.str.contains("jump", na=False)
    else:
        mask = pd.Series(False, index=nba_period.index)
    filt = nba_period[mask].copy()
    return filt if not filt.empty else nba_period


def align_bbref_events_to_nba(events: pd.DataFrame, nba_pbp: pd.DataFrame) -> pd.DataFrame:
    if events.empty or nba_pbp.empty:
        return events.assign(nba_game_id=None, nba_action_number=None, nba_alignment_confidence=0.0, nba_description_aligned=None, nba_alignment_method="unmatched")

    out = events.copy().reset_index(drop=False).rename(columns={"index": "_event_row"})
    out["_period_int"] = pd.to_numeric(out.get("period"), errors="coerce")
    out["_event_elapsed"] = pd.to_numeric(out.get("game_elapsed_seconds"), errors="coerce")
    out["_event_kind"] = out.apply(_bbref_event_kind, axis=1)

    nba = nba_pbp.dropna(subset=["period", "game_elapsed_seconds"]).copy()
    if nba.empty:
        return out.drop(columns=[c for c in out.columns if c.startswith("_")], errors="ignore").assign(nba_game_id=None, nba_action_number=None, nba_alignment_confidence=0.0, nba_description_aligned=None, nba_alignment_method="unmatched")
    nba["_period_int"] = pd.to_numeric(nba["period"], errors="coerce")
    nba["_nba_elapsed"] = pd.to_numeric(nba["game_elapsed_seconds"], errors="coerce")
    nba = nba.dropna(subset=["_period_int", "_nba_elapsed"]).copy()
    nba_game_id = nba["nba_game_id"].dropna().iloc[0] if "nba_game_id" in nba.columns and nba["nba_game_id"].notna().any() else None

    actions: Dict[int, Any] = {}
    confs: Dict[int, float] = {}
    ndesc: Dict[int, Any] = {}
    methods: Dict[int, str] = {}
    tolerance = 6.0

    eligible = out.dropna(subset=["_period_int", "_event_elapsed"]).copy()
    for (period, kind), evg in eligible.groupby(["_period_int", "_event_kind"], sort=False):
        nba_period = nba[nba["_period_int"] == period].copy()
        if nba_period.empty:
            continue
        comp = _compatible_nba_actions(nba_period, kind)
        used_compatible = len(comp) < len(nba_period) and kind != "other"
        ev_sorted = evg.sort_values("_event_elapsed")
        nb_cols = ["nba_action_number", "description", "_nba_elapsed"]
        if "action_type" in comp.columns:
            nb_cols.append("action_type")
        merged = pd.merge_asof(
            ev_sorted,
            comp[nb_cols].sort_values("_nba_elapsed"),
            left_on="_event_elapsed",
            right_on="_nba_elapsed",
            direction="nearest",
            tolerance=tolerance,
        )
        for _, m in merged.iterrows():
            row_id = int(m["_event_row"])
            if pd.isna(m.get("nba_action_number")):
                actions[row_id] = None
                confs[row_id] = 0.0
                ndesc[row_id] = None
                methods[row_id] = "unmatched"
                continue
            dt = abs(float(m["_event_elapsed"]) - float(m["_nba_elapsed"]))
            conf = max(0.0, 1.0 - dt / tolerance)
            actions[row_id] = m.get("nba_action_number")
            confs[row_id] = round(conf, 4)
            ndesc[row_id] = m.get("description")
            methods[row_id] = "merge_asof_nearest_type_filtered" if used_compatible else "merge_asof_nearest_period"

    out["nba_game_id"] = nba_game_id
    out["nba_action_number"] = out["_event_row"].map(actions)
    out["nba_alignment_confidence"] = out["_event_row"].map(confs).fillna(0.0)
    out["nba_description_aligned"] = out["_event_row"].map(ndesc)
    out["nba_alignment_method"] = out["_event_row"].map(methods).fillna("unmatched")
    return out.drop(columns=[c for c in out.columns if c.startswith("_")], errors="ignore")


def fetch_public_tracking_aggregates(season_label: str, season_type: str = "Regular Season") -> pd.DataFrame:
    if leaguedashptstats is None:
        return pd.DataFrame()
    pt_types = [
        "Possessions", "SpeedDistance", "CatchShoot", "PullUpShot", "Defense",
        "Drives", "Passing", "ElbowTouch", "PostTouch", "PaintTouch", "Efficiency", "Rebounding"
    ]
    rows = []
    for pt in pt_types:
        try:
            obj = leaguedashptstats.LeagueDashPtStats(
                season=season_label,
                season_type_all_star=season_type,
                pt_measure_type=pt,
                per_mode_simple="PerGame",
                headers=NBA_HEADERS,
                timeout=60,
            )
            dfs = obj.get_data_frames()
            if dfs:
                df = dfs[0].copy()
                df.insert(0, "pt_measure_type", pt)
                df.insert(0, "season_type", season_type)
                df.insert(0, "season", season_label)
                rows.append(df)
            print(f"tracking aggregate ok: {pt}")
        except Exception as e:
            print(f"WARN: tracking aggregate failed: {pt}: {e}")
        time.sleep(1.0)
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()


# =============================================================================
# Coverage ingestion
# =============================================================================

def run_cmd(cmd: List[str]) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, shell=False)


def parse_vtt_timestamp(ts: str) -> Optional[float]:
    ts = ts.strip().replace(",", ".")
    parts = ts.split(":")
    try:
        if len(parts) == 3:
            h, m, s = parts
            return int(h) * 3600 + int(m) * 60 + float(s)
        if len(parts) == 2:
            m, s = parts
            return int(m) * 60 + float(s)
    except Exception:
        return None
    return None


def parse_vtt_file(path: str, source: CoverageSource) -> List[TranscriptSegment]:
    text = Path(path).read_text(encoding="utf-8", errors="ignore")
    blocks = re.split(r"\n\s*\n", text)
    out: List[TranscriptSegment] = []
    for block in blocks:
        lines = [l.strip() for l in block.splitlines() if l.strip()]
        tl = next((l for l in lines if "-->" in l), None)
        if not tl:
            continue
        left, right = tl.split("-->", 1)
        start = parse_vtt_timestamp(left)
        end = parse_vtt_timestamp(right.split()[0])
        caption_lines = [l for l in lines if "-->" not in l and not l.lower().startswith("webvtt") and not l.isdigit()]
        cap = re.sub(r"<[^>]+>", "", clean_text(" ".join(caption_lines)))
        if cap:
            out.append(TranscriptSegment(source.source_id, source.source_type, start, end, cap, confidence=0.75))
    return out


def download_subtitles(video_url: str, out_dir: Path, source_id: str) -> List[Path]:
    ensure_dir(out_dir)
    output_template = str(out_dir / f"{source_id}.%(ext)s")
    cmd = ["yt-dlp", "--skip-download", "--write-subs", "--write-auto-subs", "--sub-langs", "en.*", "--sub-format", "vtt/srv3/ttml/best", "-o", output_template, video_url]
    res = run_cmd(cmd)
    if res.returncode != 0:
        raise RuntimeError(res.stderr)
    return list(out_dir.glob(f"{source_id}*.vtt"))


def download_audio(video_url: str, out_dir: Path, source_id: str) -> Path:
    ensure_dir(out_dir)
    out_base = str(out_dir / source_id)
    cmd = ["yt-dlp", "-x", "--audio-format", "mp3", video_url, "-o", out_base]
    res = run_cmd(cmd)
    if res.returncode != 0:
        raise RuntimeError(res.stderr)
    matches = list(out_dir.glob(f"{source_id}*.mp3"))
    if not matches:
        raise FileNotFoundError(f"No mp3 created for {source_id}")
    return matches[0]


def transcribe_audio(path: str, source: CoverageSource, model_name: str = "base") -> List[TranscriptSegment]:
    if whisper is None:
        raise RuntimeError("openai-whisper is not installed. pip install openai-whisper")
    model = whisper.load_model(model_name)
    result = model.transcribe(path, word_timestamps=False)
    out = []
    for seg in result.get("segments", []):
        txt = clean_text(seg.get("text", ""))
        if txt:
            out.append(TranscriptSegment(source.source_id, source.source_type, float(seg.get("start", 0)), float(seg.get("end", 0)), txt, confidence=WHISPER_SEGMENT_SOURCE_PRIOR))
    return out


def load_text_segments(path: str, source: CoverageSource) -> List[TranscriptSegment]:
    raw = clean_text(Path(path).read_text(encoding="utf-8", errors="ignore"))
    matches = list(re.finditer(r"\[(\d{1,2}:\d{2}(?::\d{2})?)\]", raw))
    if not matches:
        return [TranscriptSegment(source.source_id, source.source_type, None, None, raw, confidence=0.58)] if raw else []
    out = []
    for i, m in enumerate(matches):
        start = parse_vtt_timestamp(m.group(1))
        end_pos = matches[i + 1].start() if i + 1 < len(matches) else len(raw)
        end = parse_vtt_timestamp(matches[i + 1].group(1)) if i + 1 < len(matches) else None
        txt = clean_text(raw[m.end():end_pos])
        if txt:
            out.append(TranscriptSegment(source.source_id, source.source_type, start, end, txt, confidence=0.66))
    return out


def extract_article_text(url: str, source: CoverageSource, max_chars: int = 20000) -> List[TranscriptSegment]:
    if BeautifulSoup is None:
        raise RuntimeError("beautifulsoup4 is not installed")
    resp = requests.get(url, headers={"User-Agent": NBA_HEADERS["User-Agent"]}, timeout=30)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")
    for tag in soup(["script", "style", "noscript", "svg", "nav", "header", "footer", "aside", "form", "button"]):
        tag.decompose()

    # Prefer the densest article/main body instead of concatenating all wrappers;
    # many sites put nav modules, recirculation links, and ad copy inside <main>.
    blocks = []
    for c in soup.find_all(["article", "main"]):
        paras = [clean_text(p.get_text(" ")) for p in c.find_all(["p", "li", "blockquote"])]
        paras = [x for x in paras if len(x) >= 30]
        text = clean_text(" ".join(paras))
        if text:
            blocks.append(text)
    if blocks:
        text = max(blocks, key=len)
    else:
        paras = [clean_text(p.get_text(" ")) for p in soup.find_all(["p", "li", "blockquote"])]
        paras = [x for x in paras if len(x) >= 30]
        text = " ".join(paras)
    text = clean_text(text)[:max_chars]
    return [TranscriptSegment(source.source_id, source.source_type, None, None, text, confidence=0.55)] if text else []


def ingest_coverage_source(source: CoverageSource, work_dir: Path) -> List[TranscriptSegment]:
    if source.local_path:
        p = Path(source.local_path)
        if not p.exists():
            raise FileNotFoundError(str(p))
        ext = p.suffix.lower()
        if ext == ".vtt":
            return parse_vtt_file(str(p), source)
        if ext in {".txt", ".md", ".srt"}:
            return load_text_segments(str(p), source)
        if ext in {".mp3", ".wav", ".m4a", ".mp4", ".mkv", ".mov"}:
            return transcribe_audio(str(p), source)
    if source.url:
        parsed = urlparse(source.url)
        looks_video = any(host in parsed.netloc for host in ["youtube.com", "youtu.be", "nba.com", "twitch.tv"])
        if source.source_type in {SOURCE_WRITTEN_COVERAGE, SOURCE_FILM_BREAKDOWN} and not looks_video:
            return extract_article_text(source.url, source)
        # captions first, audio fallback
        try:
            vtts = download_subtitles(source.url, work_dir, source.source_id)
            segs: List[TranscriptSegment] = []
            for v in vtts:
                segs.extend(parse_vtt_file(str(v), source))
            if segs:
                return segs
        except Exception as e:
            print(f"WARN: subtitle ingest failed for {source.source_id}: {e}")
        audio = download_audio(source.url, work_dir, source.source_id)
        return transcribe_audio(str(audio), source)
    return []


def source_weight(source_type: str) -> float:
    return {
        SOURCE_ALT_BROADCAST: 1.08,
        SOURCE_CLOSED_CAPTIONS: 1.00,
        SOURCE_BROADCAST_TRANSCRIPT: 0.92,
        SOURCE_WRITTEN_COVERAGE: 0.78,
        SOURCE_FILM_BREAKDOWN: 1.15,
        SOURCE_PBP_DESCRIPTION: 0.75,
    }.get(source_type, 0.85)


def extract_tactical_labels_from_text(text: str, sw: float = 1.0) -> List[Dict[str, Any]]:
    text_l = clean_text(text).lower()
    labels = []
    for label, cfg in TACTICAL_PATTERNS.items():
        pos = any(re.search(p, text_l) for p in cfg["positive"])
        neg = any(re.search(n, text_l) for n in cfg.get("negative", []))
        if pos and not neg:
            labels.append({"label_family": cfg["family"], "label_value": label, "confidence": round(min(0.98, cfg["base_confidence"] * sw), 4)})
        elif pos and neg:
            labels.append({"label_family": cfg["family"], "label_value": label, "confidence": round(min(0.40, cfg["base_confidence"] * 0.45 * sw), 4)})
    return labels


def _event_priority_for_label(e: pd.Series, lab: Dict[str, Any]) -> int:
    family = str(lab.get("label_family", ""))
    value = str(lab.get("label_value", ""))

    if is_true(e.get("is_sub")) or is_true(e.get("is_timeout")):
        return -5
    if family == "rebounding" or value in {"tip_out", "box_out"}:
        if is_true(e.get("is_rebound")):
            return 10
        if is_true(e.get("is_shot")):
            return 5
    if family in {"rim_pressure", "closeout", "deception", "advantage_conversion"}:
        if is_true(e.get("is_shot")):
            return 10
        if is_true(e.get("is_foul")) or is_true(e.get("is_turnover")):
            return 7
    if family in {"pass_type", "set_action", "advantage_creation", "attention", "coverage", "help"}:
        if is_true(e.get("is_shot")) or is_true(e.get("is_turnover")):
            return 8
        if is_true(e.get("is_foul")) or is_true(e.get("is_rebound")):
            return 5
    if is_true(e.get("is_shot")) or is_true(e.get("is_turnover")):
        return 4
    if is_true(e.get("is_foul")) or is_true(e.get("is_rebound")):
        return 3
    return 1


def _nearest_compatible_event(near: pd.DataFrame, lab: Dict[str, Any]) -> Optional[pd.Series]:
    if near.empty:
        return None
    cand = near.copy()
    cand["_label_priority"] = cand.apply(lambda e: _event_priority_for_label(e, lab), axis=1)
    usable = cand[cand["_label_priority"] >= 0].copy()
    if usable.empty:
        usable = cand.copy()
    usable = usable.sort_values(["_label_priority", "_dt"], ascending=[False, True])
    return usable.iloc[0]


def align_segments_to_events(
    bbref_game_id: str,
    nba_game_id: Optional[str],
    events: pd.DataFrame,
    segments: List[TranscriptSegment],
    source: CoverageSource,
    window_seconds: float = 8.0,
) -> List[TacticalLabel]:
    out: List[TacticalLabel] = []
    sw = source_weight(source.source_type)
    timed = [s for s in segments if s.start_seconds is not None or s.end_seconds is not None]
    untimed = [s for s in segments if s.start_seconds is None and s.end_seconds is None]

    event_pool = events.copy()
    if "game_elapsed_seconds" in event_pool.columns:
        event_pool = event_pool[pd.notna(event_pool["game_elapsed_seconds"])].copy()
    else:
        event_pool = pd.DataFrame()

    for seg in timed:
        mid = seg.start_seconds if seg.end_seconds is None else ((seg.start_seconds or seg.end_seconds or 0) + seg.end_seconds) / 2
        target_elapsed = float(mid or 0) - float(source.broadcast_offset_seconds or 0)
        if not event_pool.empty:
            near = event_pool.copy()
            near["_dt"] = (near["game_elapsed_seconds"].astype(float) - target_elapsed).abs()
            near = near[near["_dt"] <= window_seconds].sort_values("_dt")
        else:
            near = pd.DataFrame()

        labs = extract_tactical_labels_from_text(seg.text, sw * seg.confidence)
        for lab in labs:
            e = _nearest_compatible_event(near, lab)
            if e is None:
                continue
            dt = float(e.get("_dt", 0.0) or 0.0)
            distance_weight = max(0.70, 1.0 - min(dt, window_seconds) / max(window_seconds, 1.0) * 0.30)
            out.append(TacticalLabel(
                bbref_game_id=bbref_game_id,
                nba_game_id=nba_game_id,
                event_id=e.get("event_id"),
                event_index=maybe_int(e.get("event_index")),
                true_possession_id=e.get("true_possession_id"),
                period=maybe_int(e.get("period")),
                clock=e.get("clock"),
                source_id=seg.source_id,
                source_type=seg.source_type,
                label_family=lab["label_family"],
                label_value=lab["label_value"],
                confidence=round(float(lab["confidence"]) * distance_weight, 4),
                evidence_text=seg.text[:500],
                evidence_start_seconds=seg.start_seconds,
                evidence_end_seconds=seg.end_seconds,
            ))

    for seg in untimed:
        labs = extract_tactical_labels_from_text(seg.text, sw * seg.confidence)
        for lab in labs:
            out.append(TacticalLabel(
                bbref_game_id=bbref_game_id,
                nba_game_id=nba_game_id,
                event_id=None,
                event_index=None,
                true_possession_id=None,
                period=None,
                clock=None,
                source_id=seg.source_id,
                source_type=seg.source_type,
                label_family=lab["label_family"],
                label_value=lab["label_value"],
                confidence=lab["confidence"],
                evidence_text=seg.text[:500],
            ))
    return out


def pbp_description_labels(bbref_game_id: str, nba_game_id: Optional[str], events: pd.DataFrame) -> List[TacticalLabel]:
    out = []
    if events.empty:
        return out
    for _, e in events.iterrows():
        labs = extract_tactical_labels_from_text(e.get("event_text", ""), source_weight(SOURCE_PBP_DESCRIPTION))
        for lab in labs:
            out.append(TacticalLabel(
                bbref_game_id=bbref_game_id,
                nba_game_id=nba_game_id,
                event_id=e.get("event_id"),
                event_index=maybe_int(e.get("event_index")),
                true_possession_id=e.get("true_possession_id"),
                period=maybe_int(e.get("period")),
                clock=e.get("clock"),
                source_id="bbref_pbp_description",
                source_type=SOURCE_PBP_DESCRIPTION,
                label_family=lab["label_family"],
                label_value=lab["label_value"],
                confidence=lab["confidence"],
                evidence_text=str(e.get("event_text", ""))[:500],
            ))
    return out


def load_sources_json(path: Optional[str]) -> List[CoverageSource]:
    if not path:
        return []
    p = Path(path)
    if not p.exists():
        return []
    data = json.loads(p.read_text(encoding="utf-8"))
    raw_sources = data.get("sources", data if isinstance(data, list) else [])
    return [CoverageSource(**s) for s in raw_sources]


# =============================================================================
# Game-level pipeline
# =============================================================================

def process_game(
    bbref_game_id: str,
    bbref_data_dir: str | Path,
    out_dir: str | Path,
    season_label: str = "2025-26",
    sources: Optional[List[CoverageSource]] = None,
    include_nba: bool = True,
    include_videoevents: bool = False,
    work_dir: Optional[str | Path] = None,
) -> Dict[str, Any]:
    out_dir = ensure_dir(Path(out_dir) / bbref_game_id)
    work_dir = ensure_dir(work_dir or (out_dir / "coverage_work"))

    game = load_bbref_game(bbref_data_dir, bbref_game_id)
    raw = game["raw_pbp"]
    tp = game["true_possessions"]
    lineups = game["lineups"]

    if raw.empty:
        raise RuntimeError(f"Missing BBRef raw PBP for {bbref_game_id}. Run with --scrape-bbref first.")

    events = normalize_clean_game_events(raw)
    possessions = normalize_possession_frames(tp, raw)
    events = attach_possession_ids_to_events(events, possessions)
    event_lineups = build_event_lineups(events, lineups)
    possession_lineups = build_possession_lineups(possessions, lineups)
    touches = build_observed_touch_chain(events)

    # NBA ID crosswalk and sidecars
    home = str(raw["home_team"].iloc[0]) if "home_team" in raw.columns and not raw.empty else bbref_game_id[-3:]
    away = str(raw["away_team"].iloc[0]) if "away_team" in raw.columns and not raw.empty else None
    nba_game_id = None
    nba_pbp = pd.DataFrame()
    shotchart = pd.DataFrame()
    video_df = pd.DataFrame()

    if include_nba:
        nba_game_id = resolve_nba_game_id_from_scoreboard(
            bbref_game_id,
            home_team_bbref=home,
            away_team_bbref=away,
            log_path=Path(out_dir).parent / "nba_game_id_failures.csv",
        )
        if nba_game_id:
            nba_pbp = fetch_nba_pbp_v3(nba_game_id)
            shotchart = fetch_nba_shotchart(nba_game_id, season_label=season_label)
            if not nba_pbp.empty:
                events = align_bbref_events_to_nba(events, nba_pbp)
            if include_videoevents and not nba_pbp.empty:
                video_df = fetch_videoevents_for_nba_pbp(nba_game_id, nba_pbp)
        else:
            print(f"WARN: no NBA game ID resolved for {bbref_game_id}; NBA sidecars skipped.")

    # Coverage labels
    sources = sources or []
    # Filter sources for this game if game ids are supplied.
    sources_for_game = []
    for s in sources:
        if s.bbref_game_id and s.bbref_game_id != bbref_game_id:
            continue
        if s.nba_game_id and nba_game_id and s.nba_game_id != nba_game_id:
            continue
        sources_for_game.append(s)

    segments: List[TranscriptSegment] = []
    labels: List[TacticalLabel] = pbp_description_labels(bbref_game_id, nba_game_id, events)
    for s in sources_for_game:
        try:
            segs = ingest_coverage_source(s, work_dir=work_dir)
            segments.extend(segs)
            labels.extend(align_segments_to_events(bbref_game_id, nba_game_id, events, segs, s))
        except Exception as e:
            print(f"WARN: coverage source failed {s.source_id}: {e}")

    tactical_labels = pd.DataFrame([asdict(l) for l in labels]) if labels else pd.DataFrame()
    transcript_segments = pd.DataFrame([asdict(s) for s in segments]) if segments else pd.DataFrame()

    # Possession proxy labels from event/source labels.
    possession_proxy = build_possession_proxy_labels(tactical_labels)

    # Write outputs
    write_csv(events, out_dir / "clean_game_events.csv")
    write_csv(possessions, out_dir / "possession_frames.csv")
    write_csv(event_lineups, out_dir / "event_lineups.csv")
    write_csv(possession_lineups, out_dir / "possession_lineups.csv")
    write_csv(touches, out_dir / "observed_touch_chain.csv")
    write_csv(tactical_labels, out_dir / "tactical_labels.csv")
    write_csv(transcript_segments, out_dir / "transcript_segments.csv")
    write_csv(possession_proxy, out_dir / "possession_proxy_labels.csv")
    if not nba_pbp.empty: write_csv(nba_pbp, out_dir / "nba_playbyplayv3_sidecar.csv")
    if not shotchart.empty: write_csv(shotchart, out_dir / "nba_shotchartdetail_sidecar.csv")
    if not video_df.empty: write_csv(video_df, out_dir / "nba_videoevents_sidecar.csv")

    report = {
        "bbref_game_id": bbref_game_id,
        "nba_game_id": nba_game_id,
        "raw_events": int(len(raw)),
        "clean_events": int(len(events)),
        "true_possessions": int(len(possessions)),
        "lineup_stints": int(len(lineups)),
        "event_lineups": int(len(event_lineups)),
        "possession_lineups": int(len(possession_lineups)),
        "observed_touch_rows": int(len(touches)),
        "tactical_labels": int(len(tactical_labels)),
        "transcript_segments": int(len(transcript_segments)),
        "nba_pbp_rows": int(len(nba_pbp)),
        "shotchart_rows": int(len(shotchart)),
        "videoevents_rows": int(len(video_df)),
        "coverage_sources_used": [asdict(s) for s in sources_for_game],
        "bbref_meta": game.get("meta", {}),
    }
    (out_dir / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


def build_possession_proxy_labels(labels: pd.DataFrame) -> pd.DataFrame:
    if labels.empty or "true_possession_id" not in labels.columns:
        return pd.DataFrame()
    rows = []
    sub = labels[pd.notna(labels["true_possession_id"])]
    if sub.empty:
        return pd.DataFrame()
    for (gid, pid), g in sub.groupby(["bbref_game_id", "true_possession_id"]):
        rec = {"bbref_game_id": gid, "possession_id": pid, "label_sources": json.dumps(g[["source_id", "source_type", "label_family", "label_value", "confidence"]].to_dict(orient="records"))}
        for label_value, gg in g.groupby("label_value"):
            col = f"p_{label_value}"
            # Noisy evidence combiner: max confidence, capped.
            rec[col] = round(min(0.98, float(gg["confidence"].max())), 4)
        rec["max_label_confidence"] = round(float(g["confidence"].max()), 4)
        rec["label_count"] = int(len(g))
        rows.append(rec)
    return pd.DataFrame(rows)


# =============================================================================
# Season-level orchestration
# =============================================================================

def process_available_games(
    bbref_data_dir: str | Path,
    out_dir: str | Path,
    season_label: str,
    sources: List[CoverageSource],
    include_nba: bool,
    include_videoevents: bool,
    game: Optional[str] = None,
    limit: Optional[int] = None,
) -> Dict[str, Any]:
    games = [game] if game else available_bbref_games(bbref_data_dir)
    if limit is not None:
        games = games[:limit]
    reports = []
    failures = []
    for i, gid in enumerate(games, 1):
        try:
            print(f"[{i}/{len(games)}] processing {gid}")
            rep = process_game(
                bbref_game_id=gid,
                bbref_data_dir=bbref_data_dir,
                out_dir=out_dir,
                season_label=season_label,
                sources=sources,
                include_nba=include_nba,
                include_videoevents=include_videoevents,
            )
            reports.append(rep)
        except Exception as e:
            print(f"FAIL {gid}: {e}")
            failures.append({"bbref_game_id": gid, "error": str(e)})
    summary = {"processed": len(reports), "failures": len(failures), "failure_rows": failures, "reports": reports}
    ensure_dir(out_dir)
    Path(out_dir, "season_report.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    if reports:
        write_csv(pd.DataFrame(reports), Path(out_dir) / "season_report.csv")
    if failures:
        write_csv(pd.DataFrame(failures), Path(out_dir) / "season_failures.csv")
    return summary


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--season-year", type=int, default=2026, help="BBRef season year; 2026 == 2025-26")
    ap.add_argument("--season-label", default="2025-26", help="NBA API season label")
    ap.add_argument("--bbref-data-dir", default="./data_2025_26_bbref")
    ap.add_argument("--out", default="./data_2025_26_master")
    ap.add_argument("--sources", default=None, help="JSON file with coverage sources")
    ap.add_argument("--game", default=None, help="Single BBRef game id, e.g. 202510220LAL")
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--scrape-bbref", action="store_true")
    ap.add_argument("--enrich", action="store_true")
    ap.add_argument("--enrich-only", action="store_true")
    ap.add_argument("--no-nba-api", action="store_true")
    ap.add_argument("--videoevents", action="store_true", help="Try NBA VideoEvents sidecar. Slower.")
    ap.add_argument("--fetch-tracking", action="store_true", help="Pull LeagueDashPtStats public tracking aggregates once.")
    ap.add_argument("--delay", type=float, default=3.5)
    ap.add_argument("--jitter", type=float, default=1.5)
    ap.add_argument("--no-save-html", action="store_true")
    args = ap.parse_args()

    if args.season_year != 2026:
        print("WARN: this combined runner is tuned for 2025-26. Proceeding anyway.")

    scrape_report = None
    if args.scrape_bbref and not args.enrich_only:
        scrape_report = scrape_bbref_2025_26(
            data_dir=args.bbref_data_dir,
            game=args.game,
            limit=args.limit,
            delay=args.delay,
            jitter=args.jitter,
            save_html=not args.no_save_html,
        )
        print(json.dumps(scrape_report, indent=2))

    sources = load_sources_json(args.sources)

    summary = None
    if args.enrich or args.enrich_only or not args.scrape_bbref:
        summary = process_available_games(
            bbref_data_dir=args.bbref_data_dir,
            out_dir=args.out,
            season_label=args.season_label,
            sources=sources,
            include_nba=not args.no_nba_api,
            include_videoevents=args.videoevents,
            game=args.game,
            limit=args.limit,
        )
        print(json.dumps({"processed": summary["processed"], "failures": summary["failures"]}, indent=2))

    if args.fetch_tracking:
        tracking = fetch_public_tracking_aggregates(args.season_label)
        if not tracking.empty:
            write_csv(tracking, Path(args.out) / "public_tracking_aggregates_leaguedashptstats.csv")
            print(f"wrote tracking aggregates: {len(tracking)} rows")
        else:
            print("No tracking aggregate rows fetched.")


if __name__ == "__main__":
    main()
