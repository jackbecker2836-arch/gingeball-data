# Gingeball 2025-26 Combined Master Parser

This package combines your existing `pbp_scraper.py` BBRef authority layer with the Gingeball enrichment/parser layer.

## What it does

### Path A — BBRef authority scrape for 2025-26
Uses your existing scraper logic for:

- raw Basketball-Reference PBP
- raw HTML cache
- FT-aware true possessions
- complete lineup stints
- player ids/names
- assist/block/steal actors
- shot distance / BBRef shot-zone approximation
- QC manifests / failures

### Path B — normalized master tables
Builds:

- `clean_game_events.csv`
- `possession_frames.csv`
- `event_lineups.csv`
- `possession_lineups.csv`
- `observed_touch_chain.csv`
- `possession_proxy_labels.csv`

### Path C — modern enrichment sidecars
When NBA game ID can be resolved:

- `nba_playbyplayv3_sidecar.csv`
- `nba_shotchartdetail_sidecar.csv`
- `nba_videoevents_sidecar.csv` if `--videoevents` is used
- `public_tracking_aggregates_leaguedashptstats.csv` if `--fetch-tracking` is used

### Path D — coverage/tactical labels
Optional sources:

- alternate/data broadcasts
- closed captions/subtitles
- broadcast/radio transcripts
- written live blogs/recaps
- postgame film breakdowns

Each label has source, evidence text, confidence, event/possession link when possible.

## Install

```bash
pip install -r requirements.txt
```

You also need `ffmpeg` in PATH for audio/video workflows.

## First safe test

```bash
python gingeball_2025_26_combined_parser.py --scrape-bbref --enrich --limit 5 --bbref-data-dir ./data_2025_26_bbref --out ./data_2025_26_master
```

## Full 2025-26 BBRef scrape

```bash
python gingeball_2025_26_combined_parser.py --scrape-bbref --season-year 2026 --bbref-data-dir ./data_2025_26_bbref
```

This is resume-safe. It will skip games already present in `raw_pbp`, `possessions/*_tp.csv`, and `possessions/*_lineups.csv`.

## Enrich after scrape

```bash
python gingeball_2025_26_combined_parser.py --enrich-only --bbref-data-dir ./data_2025_26_bbref --out ./data_2025_26_master
```

## Use coverage sources

Edit `sources.example.json`, then run:

```bash
python gingeball_2025_26_combined_parser.py --enrich-only --sources sources.example.json --bbref-data-dir ./data_2025_26_bbref --out ./data_2025_26_master
```

## Output layout

Each game writes to:

```text
data_2025_26_master/<bbref_game_id>/
```

Season summary writes to:

```text
data_2025_26_master/season_report.csv
```

## Important caveats

1. BBRef IDs and NBA GameIDs are different. The script tries to resolve NBA GameID automatically by date + home team via NBA ScoreboardV2.
2. NBA event alignment is time-based and confidence-scored. Treat NBA x/y and clip metadata as sidecar enrichment until you manually validate enough games.
3. Coverage/video/audio ingestion should only use content you have rights or authorization to process.
4. Run a five-game test first. Do not launch the full enrichment/video pass blind.
