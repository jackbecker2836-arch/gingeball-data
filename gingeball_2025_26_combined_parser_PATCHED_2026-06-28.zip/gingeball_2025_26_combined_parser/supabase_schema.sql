-- Optional Supabase schema for Gingeball 2025-26 combined parser outputs.
-- The parser writes CSVs locally first. Upload after QC passes.

create table if not exists clean_game_events_202526 (
  bbref_game_id text not null,
  event_id text not null,
  event_index int,
  season int,
  date text,
  is_playoff boolean,
  period int,
  clock text,
  game_elapsed_seconds float,
  away_team text,
  home_team text,
  event_side text,
  event_team text,
  player text,
  player_id_bbref text,
  player2 text,
  player2_id_bbref text,
  assist_id_bbref text,
  block_id_bbref text,
  steal_id_bbref text,
  event_text text,
  points int,
  shot_zone_bbref text,
  shot_dist_bbref float,
  true_possession_id text,
  nba_action_number int,
  nba_alignment_confidence float,
  source text,
  created_at timestamptz default now(),
  primary key (bbref_game_id, event_id)
);

create table if not exists possession_frames_202526 (
  bbref_game_id text not null,
  possession_id text not null,
  season int,
  period int,
  offense_team text,
  defense_team text,
  start_clock text,
  end_clock text,
  start_elapsed float,
  end_elapsed float,
  duration_seconds float,
  points_scored int,
  standard_possessions_inside int,
  advantage_count int,
  end_type text,
  source text,
  created_at timestamptz default now(),
  primary key (bbref_game_id, possession_id)
);

create table if not exists event_lineups_202526 (
  bbref_game_id text not null,
  event_id text not null,
  event_index int,
  period int,
  clock text,
  game_elapsed_seconds float,
  away_team text,
  home_team text,
  away_player_ids_bbref jsonb,
  home_player_ids_bbref jsonb,
  away_player_names jsonb,
  home_player_names jsonb,
  lineup_source text,
  created_at timestamptz default now(),
  primary key (bbref_game_id, event_id)
);

create table if not exists possession_lineups_202526 (
  bbref_game_id text not null,
  possession_id text not null,
  period int,
  start_clock text,
  end_clock text,
  offense_team text,
  defense_team text,
  offense_player_ids_bbref jsonb,
  defense_player_ids_bbref jsonb,
  offense_player_names jsonb,
  defense_player_names jsonb,
  lineup_source text,
  created_at timestamptz default now(),
  primary key (bbref_game_id, possession_id)
);

create table if not exists event_tactical_labels_202526 (
  id bigserial primary key,
  bbref_game_id text not null,
  nba_game_id text,
  event_id text,
  event_index int,
  true_possession_id text,
  period int,
  clock text,
  source_id text,
  source_type text,
  label_family text,
  label_value text,
  confidence float,
  evidence_text text,
  evidence_start_seconds float,
  evidence_end_seconds float,
  label_version text,
  created_at timestamptz default now()
);

create index if not exists event_tactical_labels_202526_gid_event_idx
on event_tactical_labels_202526(bbref_game_id, event_id);

create index if not exists event_tactical_labels_202526_family_idx
on event_tactical_labels_202526(label_family, label_value);
