#!/usr/bin/env python3
"""
Gingeball v2.10 — v2.9 + SPACER OFFENSIVE CONTEXT LAYER (up/down + latent-engine bonus).
================================================================================
Adds two validated spacer-only offensive context adjustments on top of v2.9:

  (A) O up/down  — UNCERTAINTY treatment for spacers. Composite uncertainty U in [0,1]
      (context-dependence magnitude + across-context variance + sample thinness, z within
      role -> percentile). Applied as SHRINK-TOWARD-ROLE-MEAN + DOWNWARD PENALTY:
          shrunk = role_mean + (1 - LAMBDA_MAX*U)*(o_tcv - role_mean)
          o_tcv  = shrunk - GAMMA*U
      Higher uncertainty -> pulled toward typical-spacer AND penalized (never helps).
      LAMBDA_MAX=0.35, GAMMA=0.30 (conservative). Composes cleanly: uncertain star double-down;
      uncertain scrub's unearned shrink-up offset by penalty.

  (B) Latent-engine bonus — UPSIDE for spacers with proven creation when they are the
      SENIOR creator on the floor (no primary/secondary/table-setter). Multi-year pooled,
      garbage-weighted, measured on TEAM stint process metrics (eFG/TS/HVSR/AST%/TO-rate)
      vs the league senior-creator-spacer baseline. PASSED split-half stability r=+0.387.
      Sample-floored (>=300 pooled senior-creator poss), capped at +0.35, zero below median.
      It is OPTIONALITY (untapped creation), so small and additive to o_tcv.

Both are SPACER-ONLY (Stationary Spacer / Movement Shooter). All other roles: neutral.
up/down and latent bonus are SEPARATE and COMPOSE (a spacer can be both uncertain and a
latent engine). Inputs: offensive_context_spacer.json {f"{nba_id}_{season}":{U,latent_bonus}}.

REJECTED context signals (tested, FAILED stability/total-board — do NOT rebuild):
  individual CFP (+0.11), CFP-as-directional-haircut (didn't beat raw), no-engine spacer
  scale-up (single-season noise), spread-tilt (degraded total board), engine context-dependence
  (+0.21), finisher context-dependence (+0.18). LESSON: within-player splits across lineup
  contexts are too noisy at single-player resolution; only the pooled senior-creator process
  lift (latent-engine) survived.

Defensive up/down (D up/down) is DESIGNED but NOT shipped — construction needs position/height
flex detection + higher floors + stability gate (current build produced faulty names).

Emits tcv_<season>_v210.csv. Does NOT write to DB.
"""
import csv, collections, numpy as np, json, sys

CASC="v2_priors_cascade_FINAL.csv"; RPOSS="realposs.json"; REB="reb_signals.json"
MD="matchup_difficulty.json"; FD="penalty_creation.json"; UNIQ="uniqueness_signed.json"
XW="bbref_nba_crosswalk_PARTIAL_932of1001.csv"; SPCTX="offensive_context_spacer.json"
PROOF="v2_player_profiles_full_proof_profiles.csv.xlsx"  # for spacer role tag
W={'IIB':0.957,'PVA':0.416,'SGV':0.493,'MIV':0.662,'COV':0.073,'RPV':0.546,'DSV':0.676,'DPC':0.600}
OFF=['IIB','PVA','SGV','MIV','COV']; DEF=['RPV','DSV','DPC']
OREBW=0.15; DREBW=0.30; MDW=0.30; FDW=0.40; K_OFF,K_DEF=4000,1500
BETA=0.30; LAMBDA_MAX=0.35; GAMMA=0.30
SPACER_ROLES={'Stationary Spacer','Movement Shooter'}

id2bb={}; name={}
for r in csv.DictReader(open(XW)):
    if r['nba_id'] not in ('','None'): id2bb[int(r['nba_id'])]=r['bbref_id']; name[int(r['nba_id'])]=r['player_name']
realposs=json.load(open(RPOSS)); reb=json.load(open(REB)); zo=reb['oreb']; zd=reb['dreb']
zmd=json.load(open(MD)); zfd=json.load(open(FD)); signed=json.load(open(UNIQ)); spctx=json.load(open(SPCTX))
# spacer role membership from proof profiles
is_spacer=set(spctx.get("_spacer_ids",[]))
def pposs(nid,s):
    bb=id2bb.get(nid); return realposs.get(s,{}).get(bb,1000.0) if bb else 1000.0
casc=list(csv.DictReader(open(CASC)))
def build(season):
    post=collections.defaultdict(dict)
    for r in casc:
        if r['season']!=season: continue
        c=r['component']; p=r['posterior']
        if c in W and p not in ('','None','nan') and p==p: post[int(r['nba_id'])][c]=float(p)
    Z={}
    for c in W:
        v={n:post[n][c] for n in post if c in post[n]}; a=np.array(list(v.values()))
        mu=a.mean() if len(a) else 0; sd=(a.std() or 1) if len(a) else 1
        Z[c]={n:(x-mu)/sd for n,x in v.items()}
    raw={}
    for n in post:
        o=sum(W[c]*Z[c].get(n,0) for c in OFF if n in Z[c])+OREBW*zo.get(f"{n}_{season}",0.0)+FDW*zfd.get(f"{n}_{season}",0.0)
        d=sum(W[c]*Z[c].get(n,0) for c in DEF if n in Z[c])+DREBW*zd.get(f"{n}_{season}",0.0)+MDW*zmd.get(f"{n}_{season}",0.0)
        pp=pposs(n,season); o*=pp/(pp+K_OFF); d*=pp/(pp+K_DEF)
        raw[n]=[o,d]
    # spacer role mean of o (pre-adjust) for shrink target
    sp_os=[raw[n][0] for n in raw if n in is_spacer]
    role_mean=float(np.mean(sp_os)) if sp_os else 0.0
    out={}
    for n,(o,d) in raw.items():
        o_adj=o
        if n in is_spacer:
            ctx=spctx.get(f"{n}_{season}",{})
            U=ctx.get('U'); lb=ctx.get('latent_bonus',0.0)
            if U is not None:  # up/down: shrink toward role mean + downward penalty
                o_adj=role_mean+(1-LAMBDA_MAX*U)*(o-role_mean) - GAMMA*U
            o_adj=o_adj+lb   # latent-engine bonus (additive, capped upstream)
        su=signed.get(f"{n}_{season}",0.0)
        traw=o_adj+d; t=traw*(1+BETA*su)
        out[n]=(o_adj,d,traw,su,t,1 if n in is_spacer else 0)
    return out
for season in (sys.argv[1:] or ['2021','2022','2023','2024','2025']):
    b=build(season)
    with open(f"tcv_{season}_v210.csv","w",newline='') as fh:
        w=csv.writer(fh); w.writerow(['nba_id','player','season','o_tcv','d_tcv','tcv_raw','signed_uniqueness','tcv','is_spacer'])
        for n,(o,d,tr,su,t,sp) in sorted(b.items(),key=lambda x:-x[1][4]):
            w.writerow([n,name.get(n,n),season,round(o,4),round(d,4),round(tr,4),round(su,4),round(t,4),sp])
    print(f"wrote tcv_{season}_v210.csv ({len(b)} players)")
